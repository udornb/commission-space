﻿(() => {
 const input=document.getElementById('Media'),preview=document.getElementById('portfolio-preview');let url;
 input.addEventListener('change',()=>{
  if(url)URL.revokeObjectURL(url);preview.replaceChildren();input.setCustomValidity('');
  const file=input.files[0];if(!file)return;
  if(file.size>50*1024*1024){input.setCustomValidity('ไฟล์ต้องไม่เกิน 50 MB');input.reportValidity();return;}
  const media=document.createElement(file.type.startsWith('video/')?'video':'img');url=URL.createObjectURL(file);media.src=url;media.alt='ตัวอย่างผลงาน';if(media.tagName==='VIDEO'){media.controls=true;media.preload='metadata';}preview.append(media);
 });
})();
