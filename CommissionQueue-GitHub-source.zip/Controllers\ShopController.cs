﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using CommissionQueue.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CommissionQueue.Controllers;
[Authorize, Route("Admin/Shop"), ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
public class ShopController(AppDbContext db,ShopImageStore images,ILogger<ShopController> logger):Controller {
    [HttpPost("Credentials"), EnableRateLimiting("forms")]
    public async Task<IActionResult> Credentials(AdminCredentialsForm form) {
        await LoadTipsAsync();
        var shop=await db.ShopProfiles.SingleAsync();
        if(ModelState.IsValid && new PasswordHasher<ShopProfile>().VerifyHashedPassword(shop,shop.PasswordHash,form.CurrentPassword)==PasswordVerificationResult.Failed)
            ModelState.AddModelError(nameof(form.CurrentPassword),"รหัสผ่านปัจจุบันไม่ถูกต้อง");
        if(ModelState.IsValid && await db.ShopProfiles.AnyAsync(s=>s.Id!=shop.Id && s.AdminUsername==form.Username))
            ModelState.AddModelError(nameof(form.Username),"ชื่อผู้ใช้นี้ถูกใช้งานแล้ว");
        if(ModelState.IsValid) {
            var oldHash=shop.PasswordHash;
            var oldUsername=shop.AdminUsername;
            var newHash=string.IsNullOrEmpty(form.NewPassword) ? oldHash : new PasswordHasher<ShopProfile>().HashPassword(shop,form.NewPassword);
            if(form.Username==oldUsername && newHash==oldHash) {
                TempData["Message"]="ยังไม่ได้เปลี่ยนชื่อผู้ใช้หรือรหัสผ่าน";
                return RedirectToAction(nameof(Index));
            }
            var updated=await db.ShopProfiles.Where(s=>s.Id==shop.Id && s.PasswordHash==oldHash && EF.Functions.Collate(s.AdminUsername,"BINARY")==oldUsername)
                .ExecuteUpdateAsync(set=>set.SetProperty(s=>s.AdminUsername,form.Username)
                    .SetProperty(s=>s.PasswordHash,newHash).SetProperty(s=>s.UpdatedDate,DateTime.UtcNow));
            if(updated==1) {
                await HttpContext.SignOutAsync();
                TempData["Message"]="เปลี่ยนข้อมูลเข้าสู่ระบบเรียบร้อยแล้ว กรุณาเข้าสู่ระบบด้วยข้อมูลใหม่";
                return RedirectToAction("Login","Admin");
            }
            ModelState.AddModelError("","บัญชีถูกแก้ไขจากอีกหน้าต่าง กรุณาเข้าสู่ระบบใหม่แล้วลองอีกครั้ง");
        }
        // Render errors in the credentials card; never repopulate password inputs.
        form.CurrentPassword=""; form.NewPassword=null; form.ConfirmPassword=null;
        foreach(var key in new[]{nameof(form.CurrentPassword),nameof(form.NewPassword),nameof(form.ConfirmPassword)})
            if(ModelState.TryGetValue(key,out var entry)) {entry.RawValue=null;entry.AttemptedValue=null;}
        ViewBag.Credentials=form; ViewBag.CredentialError=true;
        ViewBag.WorkTypes=await db.WorkTypes.AsNoTracking().OrderBy(t=>t.Id).ToListAsync();
        ViewBag.ShopCode=shop.ShopCode; ViewBag.AdminUsername=shop.AdminUsername;
        return View("Index",ShopForm.From(shop));
    }
    [HttpGet("")] public async Task<IActionResult> Index() {
        ViewBag.WorkTypes=await db.WorkTypes.AsNoTracking().OrderBy(t=>t.Id).ToListAsync();
        await LoadTipsAsync();
        var shop=await db.ShopProfiles.SingleAsync();
        ViewBag.ShopCode=shop.ShopCode; ViewBag.AdminUsername=shop.AdminUsername;
        return View(ShopForm.From(shop));
    }
    [HttpPost(""), RequestSizeLimit(6*1024*1024), RequestFormLimits(MultipartBodyLengthLimit=6*1024*1024)]
    public async Task<IActionResult> Index(ShopForm form) {
        ViewBag.WorkTypes=await db.WorkTypes.AsNoTracking().OrderBy(t=>t.Id).ToListAsync();
        await LoadTipsAsync();
        var shop=await db.ShopProfiles.SingleAsync();
        ViewBag.ShopCode=shop.ShopCode; ViewBag.AdminUsername=shop.AdminUsername;
        form.ExistingLogoPath=shop.LogoPath; form.ExistingProfileImagePath=shop.ProfileImagePath;
        if(!ModelState.IsValid) return View(form);
        string? logo=null,profile=null;
        var oldLogo=shop.LogoPath; var oldProfile=shop.ProfileImagePath;
        try {
            logo=await images.SaveAsync(form.Logo,HttpContext.RequestAborted);
            profile=await images.SaveAsync(form.ProfileImage,HttpContext.RequestAborted);
            form.ApplyTo(shop); // ShopCode, credentials, Id and CreatedDate are never bound from this form.
            if(logo is not null) shop.LogoPath=logo;
            if(profile is not null) shop.ProfileImagePath=profile;
            await db.SaveChangesAsync();
            if(logo is not null) images.Delete(oldLogo);
            if(profile is not null) images.Delete(oldProfile);
            logo=null; profile=null;
            TempData["Message"]="บันทึกข้อมูลร้านเรียบร้อยแล้ว";
            return RedirectToAction(nameof(Index));
        } catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or DbUpdateException) {
            logger.LogError(ex,"Unable to update shop");
            ModelState.AddModelError("","บันทึกไม่สำเร็จ กรุณาเลือกไฟล์อีกครั้งแล้วลองใหม่");
            return View(form);
        } finally {images.Delete(logo); images.Delete(profile);}
    }
    private async Task LoadTipsAsync() {
        var tip=await db.TipSettings.AsNoTracking().SingleOrDefaultAsync();
        ViewBag.HasTipQr=tip?.QrImage is not null;
        ViewBag.TipForm=new TipForm { IsEnabled=tip?.IsEnabled ?? false, RecipientName=tip?.RecipientName };
    }
    [HttpGet("TipQr")] public async Task<IActionResult> TipQr() {
        var tip=await db.TipSettings.AsNoTracking().SingleOrDefaultAsync();
        return tip?.QrImage is null ? NotFound() : File(tip.QrImage,tip.ContentType ?? "image/png");
    }
    [HttpPost("Tips"), RequestSizeLimit(3*1024*1024), RequestFormLimits(MultipartBodyLengthLimit=3*1024*1024)]
    public async Task<IActionResult> Tips(TipForm form) {
        var tip=await db.TipSettings.SingleOrDefaultAsync();
        if(form.IsEnabled && form.QrImage is null && (tip?.QrImage is null || form.RemoveQr))
            ModelState.AddModelError(nameof(form.QrImage),"กรุณาเพิ่ม QR รับทิปก่อนเปิดกระปุกทิป");
        if(form.QrImage is not null && form.RemoveQr)
            ModelState.AddModelError(nameof(form.QrImage),"กรุณาเลือกอัปโหลด QR ใหม่หรือลบ QR เดิมอย่างใดอย่างหนึ่ง");
        if(!ModelState.IsValid) {
            await LoadTipsAsync();ViewBag.TipForm=form;ViewBag.TipError=true;
            var shop=await db.ShopProfiles.SingleAsync();
            ViewBag.ShopCode=shop.ShopCode;ViewBag.AdminUsername=shop.AdminUsername;
            ViewBag.WorkTypes=await db.WorkTypes.AsNoTracking().OrderBy(t=>t.Id).ToListAsync();
            return View("Index",ShopForm.From(shop));
        }
        if(tip is null) {tip=new TipSettings();db.TipSettings.Add(tip);}
        tip.IsEnabled=form.IsEnabled;tip.RecipientName=form.RecipientName?.Trim();
        if(form.QrImage is not null) (tip.QrImage,tip.ContentType)=await PaymentService.ReadQrAsync(form.QrImage,HttpContext.RequestAborted);
        if(form.RemoveQr) {tip.QrImage=null;tip.ContentType=null;}
        await db.SaveChangesAsync();
        TempData["Message"]="บันทึกกระปุกทิปเรียบร้อยแล้ว";
        return RedirectToAction(nameof(Index),null,null,"tip-settings");
    }
}



