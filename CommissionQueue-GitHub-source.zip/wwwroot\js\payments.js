﻿document.querySelectorAll('[data-qr-preview]').forEach(input=>{
    const preview=document.getElementById(input.dataset.qrPreview);
    let url=null;
    input.addEventListener('change',()=>{
        if(url) URL.revokeObjectURL(url);
        const file=input.files[0];
        if(!file){preview.hidden=true;return;}
        url=URL.createObjectURL(file);preview.src=url;preview.hidden=false;
    });
});
const paymentEditor=document.querySelector('[data-payment-editor]');
const priceField=document.querySelector('#FinalPrice');
if(paymentEditor && priceField){
    const update=()=>paymentEditor.hidden=!(Number(priceField.value)>0 || paymentEditor.dataset.hasQr==='true');
    priceField.addEventListener('input',update);update();
}
const tipDialog=document.querySelector('#tip-dialog');
document.querySelector('[data-open-tip]')?.addEventListener('click',()=>tipDialog.showModal());
document.querySelectorAll('[data-close-tip]').forEach(button=>button.addEventListener('click',()=>tipDialog.close()));
tipDialog?.addEventListener('click',event=>{if(event.target===tipDialog) tipDialog.close();});

