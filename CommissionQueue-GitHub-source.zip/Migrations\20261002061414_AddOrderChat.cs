﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CommissionQueue.Migrations
{
    /// <inheritdoc />
    public partial class AddOrderChat : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OrderMessages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    CommissionOrderId = table.Column<int>(type: "INTEGER", nullable: false),
                    FromAdmin = table.Column<bool>(type: "INTEGER", nullable: false),
                    Text = table.Column<string>(type: "TEXT", maxLength: 4000, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "TEXT", nullable: false),
                    FileName = table.Column<string>(type: "TEXT", maxLength: 180, nullable: true),
                    ContentType = table.Column<string>(type: "TEXT", maxLength: 80, nullable: true),
                    FileContent = table.Column<byte[]>(type: "BLOB", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderMessages", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderMessages_CommissionOrder_CommissionOrderId",
                        column: x => x.CommissionOrderId,
                        principalTable: "CommissionOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OrderMessages_CommissionOrderId_Id",
                table: "OrderMessages",
                columns: new[] { "CommissionOrderId", "Id" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrderMessages");
        }
    }
}
