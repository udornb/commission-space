﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Models;

public class AdminCredentialsForm {
    [Required(ErrorMessage="กรุณากรอกชื่อผู้ใช้"), StringLength(50, MinimumLength=3, ErrorMessage="ชื่อผู้ใช้ต้องมี 3–50 ตัวอักษร"),
     RegularExpression("^[a-zA-Z0-9._-]+$", ErrorMessage="ใช้ตัวอักษรอังกฤษ ตัวเลข จุด - หรือ _"), Display(Name="ชื่อผู้ใช้สำหรับเข้าสู่ระบบ")]
    public string Username { get; set; } = "";
    [Required(ErrorMessage="กรุณากรอกรหัสผ่านปัจจุบัน"), StringLength(200), DataType(DataType.Password), Display(Name="รหัสผ่านปัจจุบัน")]
    public string CurrentPassword { get; set; } = "";
    [StringLength(128, MinimumLength=8, ErrorMessage="รหัสผ่านใหม่ต้องมี 8–128 ตัวอักษร"), DataType(DataType.Password), Display(Name="รหัสผ่านใหม่")]
    public string? NewPassword { get; set; }
    [Compare(nameof(NewPassword), ErrorMessage="ยืนยันรหัสผ่านใหม่ไม่ตรงกัน"), DataType(DataType.Password), Display(Name="ยืนยันรหัสผ่านใหม่")]
    public string? ConfirmPassword { get; set; }
}

