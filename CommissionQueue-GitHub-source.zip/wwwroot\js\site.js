﻿document.querySelector('.menu-toggle')?.addEventListener('click', function () {
 const open = this.getAttribute('aria-expanded') !== 'true';
 this.setAttribute('aria-expanded', String(open));
 document.querySelector('#navigation').classList.toggle('is-open', open);
});
document.querySelectorAll('form[data-confirm]').forEach(form => form.addEventListener('submit', event => {
 if (!window.confirm(form.dataset.confirm)) event.preventDefault();
}));
document.querySelector('[data-copy]')?.addEventListener('click', async function () {
 const message = document.querySelector('#copy-status');
 try { await navigator.clipboard.writeText(this.dataset.copy); message.textContent = 'คัดลอกแล้ว ✓'; }
 catch { message.textContent = 'กรุณาเลือกเลข Order ด้านบนแล้วคัดลอก'; }
});
document.querySelector('#order-search')?.addEventListener('input', function () {
 const query = this.value.trim().toLocaleLowerCase();
 const rows = [...document.querySelectorAll('#order-rows tr')];
 rows.forEach(row => row.hidden = !row.textContent.toLocaleLowerCase().includes(query));
 document.querySelector('#search-empty').hidden = rows.some(row => !row.hidden);
});

