﻿using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;

static class ChatTests {
 public static async Task Run(string url,string path) {
  var checks=0;
  void Check(bool ok,string label){if(!ok)throw new Exception("FAIL: "+label);Console.WriteLine("PASS: "+label);checks++;}
  HttpClient Client()=>new(new HttpClientHandler{AllowAutoRedirect=false,CookieContainer=new CookieContainer()}){BaseAddress=new Uri(url)};
  using var admin=Client();using var customer=Client();using var stranger=Client();
  async Task<string> Page(HttpClient c,string route){var r=await c.GetAsync(route);r.EnsureSuccessStatusCode();return WebUtility.HtmlDecode(await r.Content.ReadAsStringAsync());}
  async Task<string> Token(HttpClient c,string route)=>Regex.Match(await Page(c,route),"name=\"__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
  async Task<HttpResponseMessage> Post(HttpClient c,string route,Dictionary<string,string> fields,string token,byte[]? file=null,string name="image.png") {
   using var body=new MultipartFormDataContent(); foreach(var f in fields)body.Add(new StringContent(f.Value),f.Key);
   body.Add(new StringContent(token),"__RequestVerificationToken");if(file is not null)body.Add(new ByteArrayContent(file),"Attachment",name);return await c.PostAsync(route,body);
  }
  async Task<string> Sql(string sql){await using var db=new SqliteConnection($"Data Source={path}");await db.OpenAsync();await using var cmd=db.CreateCommand();cmd.CommandText=sql;return Convert.ToString(await cmd.ExecuteScalarAsync())!;}
  var setup=new Dictionary<string,string>{["ShopCode"]="CHAT-TEST",["OwnerName"]="Test Owner",["ShopName"]="Chat Studio",["AdminUsername"]="admin",["Password"]="Mellow@12345",["ConfirmPassword"]="Mellow@12345",["Email"]="owner@example.test",["Phone"]="0812345678",["IsOpen"]="true"};
  Check((await Post(admin,"/Setup",setup,await Token(admin,"/Setup"))).StatusCode==HttpStatusCode.Redirect,"Shop created");
  Check(await Sql("SELECT COUNT(*) FROM __EFMigrationsHistory")=="6","Chat migration applied");
  var order=new Dictionary<string,string>{["CustomerName"]="Chat Customer",["Contact"]="private@example.test",["WorkType"]="รูปตัวละคร",["Description"]="Chat work",["Budget"]="1800",["DueDate"]=DateTime.UtcNow.AddDays(30).ToString("yyyy-MM-dd")};
  var ct=await Token(customer,"/Commission/Create");
  var created=await Post(customer,"/Commission/Create",order,ct); if(created.StatusCode!=HttpStatusCode.Redirect) Console.WriteLine(WebUtility.HtmlDecode(await created.Content.ReadAsStringAsync())); Check(created.StatusCode==HttpStatusCode.Redirect,"Request needs no image");
  Check((await Page(customer,"/Commission/Success")).Contains("/Chat"),"Success links to chat");
  var at=await Token(admin,"/Admin/Edit/4");
  var edit=new Dictionary<string,string>(order){["Id"]="4",["Status"]="2"};
  Check((await Post(admin,"/Admin/Edit/4",edit,at)).StatusCode==HttpStatusCode.Redirect,"Edit saves without any image or QR");
  Check((await Page(admin,"/Admin/Details/4")).Contains("คุยงาน"),"Order details has chat button");
  const string route="/Chat?orderCode=COM-0004";const string send="/Chat/Send?orderCode=COM-0004";
  Check((await Page(customer,route)).Contains("ช่องทางติดต่อที่กรอกตอนสั่งงาน"),"Customer verifies contact first");
  Check((await customer.GetAsync("/Chat/Messages?orderCode=COM-0004")).StatusCode==HttpStatusCode.Forbidden,"Messages are private");
  Check((await Post(customer,send,new(){["Text"]="intrusion"},ct)).StatusCode==HttpStatusCode.Forbidden,"Unverified sender blocked");
  Check((await Post(customer,"/Chat/Access",new(){["orderCode"]="COM-0004",["contact"]="wrong"},ct)).StatusCode==HttpStatusCode.OK,"Wrong contact rejected");
  Check((await Post(customer,"/Chat/Access",new(){["orderCode"]="COM-0004",["contact"]=order["Contact"]},ct)).StatusCode==HttpStatusCode.Redirect,"Correct contact opens chat");
  Check((await Page(customer,route)).Contains("chat-compose"),"Customer has composer");
  Check((await Page(admin,route)).Contains("chat-compose"),"Owner opens chat directly");
  Check((await customer.PostAsync(send,new FormUrlEncodedContent(new Dictionary<string,string>{["Text"]="no csrf"}))).StatusCode==HttpStatusCode.BadRequest,"CSRF protected");
  Check((await Post(customer,send,new(){["Text"]="  "},ct)).StatusCode==HttpStatusCode.OK && await Sql("SELECT COUNT(*) FROM OrderMessages")=="0","Empty message rejected");
  Check((await Post(customer,send,new(){["Text"]="<script>alert(1)</script>",["FromAdmin"]="true"},ct)).StatusCode==HttpStatusCode.Redirect,"Customer sends text");
  Check(await Sql("SELECT FromAdmin FROM OrderMessages LIMIT 1")=="0","Cannot impersonate owner");
  var rendered=await (await admin.GetAsync("/Chat/Messages?orderCode=COM-0004")).Content.ReadAsStringAsync();
  Check(rendered.Contains("&lt;script&gt;")&&!rendered.Contains("<script>alert"),"Chat text safely encoded");
  var png=Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII=");
  Check((await Post(admin,send,new(){["Text"]="draft ready"},at,png)).StatusCode==HttpStatusCode.Redirect,"Owner sends image and text");
  var id=await Sql("SELECT MAX(Id) FROM OrderMessages");
  Check((await customer.GetByteArrayAsync("/Chat/Attachment/"+id)).SequenceEqual(png),"Customer receives original image");
  Check((await stranger.GetAsync("/Chat/Attachment/"+id)).StatusCode==HttpStatusCode.Forbidden,"Stranger cannot fetch attachment");
  Check((await customer.GetAsync("/Chat/Messages?orderCode=COM-0001")).StatusCode==HttpStatusCode.Forbidden,"Access scoped to one order");
  var zip=new byte[]{80,75,5,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  Check((await Post(admin,send,new(),at,zip,"final-work.zip")).StatusCode==HttpStatusCode.Redirect,"File-only delivery supported");
  id=await Sql("SELECT MAX(Id) FROM OrderMessages");
  var download=await customer.GetAsync("/Chat/Attachment/"+id);
  Check(download.Content.Headers.ContentDisposition?.DispositionType=="attachment" && (await download.Content.ReadAsByteArrayAsync()).SequenceEqual(zip),"Delivered work downloads intact");
  Check((await Post(customer,send,new(),ct,Encoding.UTF8.GetBytes("fake"))).StatusCode==HttpStatusCode.OK && await Sql("SELECT COUNT(*) FROM OrderMessages")=="3","Fake image rejected");
  Check((await Post(customer,send,new(),ct,new byte[20*1024*1024+1])).StatusCode==HttpStatusCode.OK && await Sql("SELECT COUNT(*) FROM OrderMessages")=="3","Oversized attachment rejected");
  Check((await Post(customer,send,new(){["Text"]=new string('a',4001)},ct)).StatusCode==HttpStatusCode.OK && await Sql("SELECT COUNT(*) FROM OrderMessages")=="3","Message length validated");
  Check((await Page(customer,"/Chat/Messages?orderCode=COM-0004")).Contains("final-work.zip"),"Refresh includes delivered work");
  Check((await admin.GetAsync("/Chat?orderCode=COM-9999")).StatusCode==HttpStatusCode.NotFound,"Unknown order handled");
  var customerMessages=await Page(customer,"/Chat/Messages?orderCode=COM-0004&view=customer");
  Check(Regex.IsMatch(customerMessages,"(?s)chat-bubble mine.*?Chat Customer.*?\\(คุณ\\)"),"Customer name and own right bubble");
  Check(Regex.IsMatch(customerMessages,"(?s)chat-bubble theirs.*?Chat Studio"),"Shop messages on opposite side");
  Check((await Page(admin,route+"&view=customer")).Contains("ช่องทางติดต่อที่กรอกตอนสั่งงาน"),"Owner browser customer entry requires customer verification");
  Check((await Post(admin,"/Chat/Access?view=customer",new(){["orderCode"]="COM-0004",["contact"]=order["Contact"]},at)).StatusCode==HttpStatusCode.Redirect,"Owner browser can verify customer perspective");
  Check((await Post(admin,send+"&view=customer",new(){["Text"]="Customer perspective"},at)).StatusCode==HttpStatusCode.Redirect,"Send from customer perspective");
  Check(await Sql("SELECT FromAdmin FROM OrderMessages ORDER BY Id DESC LIMIT 1")=="0","Owner cookie does not override customer sender");
  Check((await Page(admin,route+"&view=customer")).Contains("view=customer"),"Customer perspective retained on forms and refresh");
  Check(Regex.IsMatch(await Page(admin,"/Chat/Messages?orderCode=COM-0004"),"(?s)chat-bubble mine.*?Chat Studio.*?\\(คุณ\\)"),"Admin entry retains owner perspective");
  Console.WriteLine($"SUCCESS: {checks} chat checks passed.");
 }
}





