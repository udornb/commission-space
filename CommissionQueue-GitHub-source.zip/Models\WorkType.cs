﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Models;

public class WorkType {
    public int Id { get; set; }
    [MaxLength(80)] public string Name { get; set; } = "";
    [MaxLength(160)] public string NormalizedName { get; set; } = "";
    public bool IsActive { get; set; } = true;
}
public class WorkTypeForm {
    [Required(ErrorMessage="กรุณากรอกชื่อประเภทงาน"), StringLength(80, ErrorMessage="ชื่อประเภทงานยาวได้ไม่เกิน 80 ตัวอักษร")]
    public string Name { get; set; } = "";
    public bool IsActive { get; set; } = true;
}

