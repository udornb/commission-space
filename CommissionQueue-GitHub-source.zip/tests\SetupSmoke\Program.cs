﻿using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;
using Microsoft.AspNetCore.Identity;
using CommissionQueue.Models;

if(args.Length>0 && args[0]=="--legacy") { await LegacyTests.Run(args.Length>1?args[1]:"commissions.db"); return; }
if(args.Length>0 && args[0]=="--attachments") { await AttachmentTests.Run(args.Length>1?args[1]:"http://localhost:5081",args.Length>2?args[2]:"artifacts/attachments-test.db"); return; }
if(args.Length>0 && args[0]=="--feature-upgrade") { await FeatureUpgradeTests.Run(args.Length>1?args[1]:"commissions.db"); return; }
if(args.Length>0 && args[0]=="--credentials") { await CredentialTests.Run(args.Length>1?args[1]:"http://localhost:5081",args.Length>2?args[2]:"artifacts/credentials-test.db"); return; }
if(args.Length>0 && args[0]=="--payments") { await PaymentTests.Run(args.Length>1?args[1]:"http://localhost:5081",args.Length>2?args[2]:"artifacts/payment-tests.db"); return; }
if(args.Length>0 && args[0]=="--chat") { await ChatTests.Run(args.Length>1?args[1]:"http://localhost:5081",args.Length>2?args[2]:"artifacts/chat-tests.db"); return; }
if(args.Length>0 && args[0]=="--portfolio") { await PortfolioTests.Run(args.Length>1?args[1]:"http://localhost:5081"); return; }
var baseUrl=args.Length>0?args[0]:"http://localhost:5081";
var dbPath=args.Length>1?args[1]:Path.GetFullPath("artifacts/setup-fresh.db");
var checks=0;
void Check(bool valid,string message) {if(!valid) throw new Exception("FAIL: "+message); Console.WriteLine("PASS: "+message); checks++;}
HttpClient Client() => new(new HttpClientHandler {AllowAutoRedirect=false, CookieContainer=new CookieContainer()}) {BaseAddress=new Uri(baseUrl)};
using var client=Client();
async Task<string> Page(HttpClient c,string path) {
    var r=await c.GetAsync(path); r.EnsureSuccessStatusCode();
    return WebUtility.HtmlDecode(await r.Content.ReadAsStringAsync());
}
async Task<string> Token(HttpClient c,string path) {
    var html=await Page(c,path);
    var value=Regex.Match(html,"name=\"__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
    if(value.Length==0) throw new Exception("Missing CSRF token: "+path);
    return value;
}
async Task<HttpResponseMessage> Post(HttpClient c,string path,Dictionary<string,string> values,string token,byte[]? image=null,string fileName="logo.png",bool profile=false) {
    using var content=new MultipartFormDataContent();
    foreach(var entry in values) content.Add(new StringContent(entry.Value),entry.Key);
    content.Add(new StringContent(token),"__RequestVerificationToken");
    if(image is not null) {
        var bytes=new ByteArrayContent(image); bytes.Headers.ContentType=new MediaTypeHeaderValue("image/png");
        content.Add(bytes,"Logo",fileName);
        if(profile) {var b=new ByteArrayContent(image); b.Headers.ContentType=new MediaTypeHeaderValue("image/png");content.Add(b,"ProfileImage","profile.png");}
    }
    return await c.PostAsync(path,content);
}
async Task<object?> Sql(string sql) {
    await using var connection=new SqliteConnection($"Data Source={dbPath}"); await connection.OpenAsync();
    await using var command=connection.CreateCommand();command.CommandText=sql; return await command.ExecuteScalarAsync();
}
var valid=new Dictionary<string,string> {
    ["ShopCode"]="mellow-test",["OwnerName"]="Test Owner",["ShopName"]="Mellow Studio",["AdminUsername"]="admin",
    ["Password"]="Mellow@12345",["ConfirmPassword"]="Mellow@12345",["Email"]="owner@example.test",["Phone"]="0812345678",
    ["Description"]="A lovely test studio",["LineContact"]="@mellow",["FacebookContact"]="mellow.page",["InstagramContact"]="mellow.ig",["IsOpen"]="true"
};
foreach(var path in new[]{"/","/Admin","/Admin/Login","/Admin/Shop","/Commission/Create","/Home/Queue"}) {
    var r=await client.GetAsync(path);
    Check(r.StatusCode==HttpStatusCode.Redirect && r.Headers.Location?.ToString()=="/Setup","First-run gate: "+path);
}
Check(Convert.ToInt32(await Sql("SELECT COUNT(*) FROM ShopProfile"))==0,"No automatic shop/admin seed");
Check(Convert.ToInt32(await Sql("SELECT COUNT(*) FROM __EFMigrationsHistory"))==6,"All migrations applied");
var token=await Token(client,"/Setup");
var noCsrf=await client.PostAsync("/Setup",new FormUrlEncodedContent(valid));
Check(noCsrf.StatusCode==HttpStatusCode.BadRequest,"Setup requires antiforgery token");
var empty=await Post(client,"/Setup",new(),token);
Check(empty.StatusCode==HttpStatusCode.OK && (await empty.Content.ReadAsStringAsync()).Contains("validation-summary-errors"),"Empty required fields rejected without crashing");
var mismatch=new Dictionary<string,string>(valid){["ConfirmPassword"]="not-the-same"};
Check((await (await Post(client,"/Setup",mismatch,token)).Content.ReadAsStringAsync()).Contains("validation-summary-errors"),"Password mismatch rejected");
var bad=new Dictionary<string,string>(valid){["Email"]="invalid",["Phone"]="abc",["ShopCode"]="space code",["Password"]="short",["ConfirmPassword"]="short"};
Check((await (await Post(client,"/Setup",bad,token)).Content.ReadAsStringAsync()).Contains("validation-summary-errors"),"Email phone code and short password validated");
var fake=await Post(client,"/Setup",valid,token,Encoding.UTF8.GetBytes("<script>alert(1)</script>"));
Check(fake.StatusCode==HttpStatusCode.OK && (await fake.Content.ReadAsStringAsync()).Contains("validation-summary-errors"),"Spoofed image content rejected");
var oversize=await Post(client,"/Setup",valid,token,new byte[2*1024*1024+1]);
Check(oversize.StatusCode==HttpStatusCode.OK && (await oversize.Content.ReadAsStringAsync()).Contains("validation-summary-errors"),"Images above 2 MB rejected");
var png=Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII=");
var extension=await Post(client,"/Setup",valid,token,png,"logo.svg");
Check(extension.StatusCode==HttpStatusCode.OK && (await extension.Content.ReadAsStringAsync()).Contains("validation-summary-errors"),"SVG extension rejected");
Check(Convert.ToInt32(await Sql("SELECT COUNT(*) FROM ShopProfile"))==0,"Invalid setup never persists shop");
var created=await Post(client,"/Setup",valid,token,png,profile:true);
Check(created.StatusCode==HttpStatusCode.Redirect && created.Headers.Location?.ToString()=="/Setup/Success","Setup redirects to confirmation");
var success=await Page(client,"/Setup/Success");
Check(success.Contains("ตั้งค่าร้านเรียบร้อยแล้ว 🎉") && success.Contains("เข้าสู่ Dashboard"),"Success message and dashboard button");
Check((await client.GetAsync("/Admin")).StatusCode==HttpStatusCode.OK,"Setup signs in administrator");
var hash=Convert.ToString(await Sql("SELECT PasswordHash FROM ShopProfile"))!;
Check(hash!=valid["Password"] && new PasswordHasher<ShopProfile>().VerifyHashedPassword(new ShopProfile(),hash,valid["Password"])!=PasswordVerificationResult.Failed,"Password persisted as verifiable hash");
Check((string)(await Sql("SELECT ShopCode FROM ShopProfile"))! =="MELLOW-TEST","Shop code normalized");
Check(Convert.ToInt32(await Sql("SELECT COUNT(*) FROM CommissionOrder"))==3,"Three sample orders created with setup");
var logo=(string)(await Sql("SELECT LogoPath FROM ShopProfile"))!;
var profilePath=(string)(await Sql("SELECT ProfileImagePath FROM ShopProfile"))!;
Check(logo!=profilePath && (await client.GetAsync(logo)).IsSuccessStatusCode && (await client.GetAsync(profilePath)).IsSuccessStatusCode,"Both images stored and served");
var home=await Page(client,"/");
Check(home.Contains("A lovely test studio") && home.Contains(logo) && home.Contains(profilePath),"Shop description and images shown on Home");
Check((await client.GetAsync("/Setup")).Headers.Location?.ToString()=="/Admin","Configured setup redirects authenticated user");
using var anon=Client();
Check((await anon.GetAsync("/Setup")).Headers.Location?.ToString()=="/Admin/Login","Configured setup redirects anonymous user to Login");
Check((await anon.GetAsync("/Admin/Shop")).StatusCode==HttpStatusCode.Redirect,"Settings require authentication");
var duplicate=await Post(client,"/Setup",valid,await Token(client,"/Admin/Shop"),png);
Check(duplicate.StatusCode==HttpStatusCode.Redirect && Convert.ToInt32(await Sql("SELECT COUNT(*) FROM ShopProfile"))==1,"Second setup cannot overwrite shop");
var edit=new Dictionary<string,string>(valid) {["ShopCode"]="HACKED-CODE",["AdminUsername"]="attacker",["PasswordHash"]="plaintext",["OwnerName"]="Updated Owner",["ShopName"]="Updated Studio",["IsOpen"]="false"};
var saved=await Post(client,"/Admin/Shop",edit,await Token(client,"/Admin/Shop"),png);
Check(saved.StatusCode==HttpStatusCode.Redirect,"Settings saved");
Check((string)(await Sql("SELECT ShopCode FROM ShopProfile"))! =="MELLOW-TEST" && (string)(await Sql("SELECT AdminUsername FROM ShopProfile"))! =="admin" && (string)(await Sql("SELECT PasswordHash FROM ShopProfile"))! == hash,"Code and credentials immutable through settings");
Check((string)(await Sql("SELECT OwnerName FROM ShopProfile"))! =="Updated Owner" && Convert.ToInt32(await Sql("SELECT IsOpen FROM ShopProfile"))==0,"Profile fields and closed status persisted");
var newLogo=(string)(await Sql("SELECT LogoPath FROM ShopProfile"))!;
Check(newLogo!=logo && (await client.GetAsync(newLogo)).IsSuccessStatusCode && (await client.GetAsync(logo)).StatusCode==HttpStatusCode.NotFound,"Replacement image served and old image removed");
Check((string)(await Sql("SELECT ProfileImagePath FROM ShopProfile"))! == profilePath,"Unchanged profile image retained");
var invalidEdit=new Dictionary<string,string>(edit){["Email"]="bad"};
Check((await (await Post(client,"/Admin/Shop",invalidEdit,await Token(client,"/Admin/Shop"))).Content.ReadAsStringAsync()).Contains("validation-summary-errors"),"Settings server validation");
var setupAgain=await Post(anon,"/Setup",valid,await Token(anon,"/Admin/Login"));
Check(setupAgain.StatusCode==HttpStatusCode.Redirect && setupAgain.Headers.Location?.ToString()=="/Admin/Login","Anonymous POST cannot repeat setup");
var login=await Post(anon,"/Admin/Login",new(){["Username"]="ADMIN",["Password"]=valid["Password"]},await Token(anon,"/Admin/Login"));
Check(login.StatusCode==HttpStatusCode.Redirect && (await anon.GetAsync("/Admin")).IsSuccessStatusCode,"New account login works case-insensitively");
var restored=await Post(client,"/Admin/Shop",valid,await Token(client,"/Admin/Shop"));
Check(restored.StatusCode==HttpStatusCode.Redirect,"Restore test shop settings for order regression");
Console.WriteLine($"SUCCESS: {checks} setup checks passed.");












