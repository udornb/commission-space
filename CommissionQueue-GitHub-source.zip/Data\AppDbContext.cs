﻿using CommissionQueue.Models;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options):DbContext(options) {
    public DbSet<CommissionOrder> CommissionOrders=>Set<CommissionOrder>();
    public DbSet<ShopProfile> ShopProfiles=>Set<ShopProfile>();
    public DbSet<WorkType> WorkTypes=>Set<WorkType>();
    public DbSet<OrderImage> OrderImages=>Set<OrderImage>();
    public DbSet<OrderPayment> OrderPayments=>Set<OrderPayment>();
    public DbSet<TipSettings> TipSettings=>Set<TipSettings>();
    public DbSet<PortfolioSetting> PortfolioSettings=>Set<PortfolioSetting>();
    public DbSet<PortfolioItem> PortfolioItems=>Set<PortfolioItem>();
    public DbSet<OrderMessage> OrderMessages=>Set<OrderMessage>();
    protected override void OnModelCreating(ModelBuilder b) {
        b.Entity<CommissionOrder>().ToTable("CommissionOrder");
        b.Entity<OrderMessage>().HasOne(m=>m.CommissionOrder).WithMany().HasForeignKey(m=>m.CommissionOrderId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<OrderMessage>().HasIndex(m=>new {m.CommissionOrderId,m.Id});
        b.Entity<OrderPayment>().HasKey(p=>p.CommissionOrderId);
        b.Entity<OrderPayment>().HasOne(p=>p.CommissionOrder).WithOne(o=>o.Payment).HasForeignKey<OrderPayment>(p=>p.CommissionOrderId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<OrderPayment>().Property(p=>p.Revision).IsConcurrencyToken();
        b.Entity<TipSettings>().Property(t=>t.Id).ValueGeneratedNever();
        b.Entity<TipSettings>().HasOne(t=>t.ShopProfile).WithOne().HasForeignKey<TipSettings>(t=>t.Id).OnDelete(DeleteBehavior.Cascade);
        b.Entity<CommissionOrder>().HasIndex(x=>x.OrderCode).IsUnique();
        b.Entity<WorkType>().HasIndex(x=>x.NormalizedName).IsUnique();
        b.Entity<OrderImage>().HasOne(x=>x.CommissionOrder).WithMany().HasForeignKey(x=>x.CommissionOrderId).OnDelete(DeleteBehavior.Cascade);
        var shop=b.Entity<ShopProfile>();
        shop.ToTable("ShopProfile",t=>t.HasCheckConstraint("CK_ShopProfile_SingleShop","Id = 1"));
        shop.Property(x=>x.Id).ValueGeneratedNever();
        shop.Property(x=>x.ShopCode).UseCollation("NOCASE");
        shop.HasIndex(x=>x.ShopCode).IsUnique();
        shop.Property(x=>x.AdminUsername).UseCollation("NOCASE");
        shop.HasIndex(x=>x.AdminUsername).IsUnique();
    }
}


