﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Models;
public enum OrderStatus {
 [Display(Name="รออนุมัติ")] Pending, [Display(Name="รอคิว")] Queued,
 [Display(Name="กำลังทำ")] InProgress, [Display(Name="รอแก้ไข")] Revision,
 [Display(Name="รอชำระเงิน")] AwaitingPayment, [Display(Name="เสร็จแล้ว")] Completed, [Display(Name="ยกเลิก")] Cancelled
}
public static class OrderLabels {
 public static string Thai(this OrderStatus s) => s switch { OrderStatus.Pending=>"รออนุมัติ", OrderStatus.Queued=>"รอคิว", OrderStatus.InProgress=>"กำลังทำ", OrderStatus.Revision=>"รอแก้ไข", OrderStatus.AwaitingPayment=>"รอชำระเงิน", OrderStatus.Completed=>"เสร็จแล้ว", _=>"ยกเลิก" };
 public static bool Active(this OrderStatus s) => s is not (OrderStatus.Completed or OrderStatus.Cancelled);
}
public class CommissionOrder {
 public OrderPayment? Payment {get;set;}
 public int Id {get;set;}
 public string OrderCode {get;set;}="";
 public string CustomerName {get;set;}="";
 public string Contact {get;set;}="";
 public string WorkType {get;set;}="";
 public string Description {get;set;}="";
 public decimal Budget {get;set;}
 public decimal? FinalPrice {get;set;}
 public DateTime DueDate {get;set;}
 public string? ReferenceUrl {get;set;}
 public string? CustomerNote {get;set;}
 public string? AdminNote {get;set;}
 public OrderStatus Status {get;set;}
 public DateTime CreatedDate {get;set;}=DateTime.UtcNow;
 public DateTime? EstimatedFinishDate {get;set;}
 public DateTime? CompletedDate {get;set;}
}

