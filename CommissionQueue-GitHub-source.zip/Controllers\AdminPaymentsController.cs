﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Controllers;

[Authorize, Route("Admin/Payments")]
public class AdminPaymentsController(AppDbContext db):Controller {
    [HttpGet("Qr/{id:int}"), ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
    public async Task<IActionResult> Qr(int id) {
        var payment=await db.OrderPayments.AsNoTracking().SingleOrDefaultAsync(p=>p.CommissionOrderId==id);
        return payment is null ? NotFound() : File(payment.QrImage,payment.ContentType);
    }
    [HttpPost("Confirm/{id:int}")] public async Task<IActionResult> Confirm(int id,string revision) {
        await using var transaction=await db.Database.BeginTransactionAsync();
        var nextRevision=Guid.NewGuid().ToString("N");
        var updated=await db.OrderPayments.Where(p=>p.CommissionOrderId==id && p.Revision==revision && p.ReportedAt!=null && p.ConfirmedAt==null
            && p.CommissionOrder.FinalPrice>0 && p.CommissionOrder.Status!=OrderStatus.Cancelled)
            .ExecuteUpdateAsync(set=>set.SetProperty(p=>p.ConfirmedAt,DateTime.UtcNow).SetProperty(p=>p.Revision,nextRevision));
        if(updated==1) await db.CommissionOrders.Where(o=>o.Id==id && o.Status==OrderStatus.AwaitingPayment)
            .ExecuteUpdateAsync(set=>set.SetProperty(o=>o.Status,OrderStatus.Queued));
        await transaction.CommitAsync();
        TempData["Message"]=updated==1 ? "ยืนยันรับเงินแล้ว" : "ข้อมูลการชำระเงินเปลี่ยนไป กรุณาตรวจสอบอีกครั้ง";
        return RedirectToAction("Details","Admin",new {id});
    }
    [HttpPost("Reject/{id:int}")] public async Task<IActionResult> Reject(int id,string revision) {
        var nextRevision=Guid.NewGuid().ToString("N");
        var updated=await db.OrderPayments.Where(p=>p.CommissionOrderId==id && p.Revision==revision && p.ReportedAt!=null && p.ConfirmedAt==null)
            .ExecuteUpdateAsync(set=>set.SetProperty(p=>p.ReportedAt,(DateTime?)null).SetProperty(p=>p.Revision,nextRevision));
        TempData["Message"]=updated==1 ? "ยังไม่ยืนยันยอด เปิดให้ลูกค้าแจ้งชำระใหม่แล้ว" : "ข้อมูลการชำระเงินเปลี่ยนไป กรุณาตรวจสอบอีกครั้ง";
        return RedirectToAction("Details","Admin",new {id});
    }
}


