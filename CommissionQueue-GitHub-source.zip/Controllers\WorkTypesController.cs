﻿using System.Text;
using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Controllers;

[Authorize, Route("Admin/WorkTypes")]
public class WorkTypesController(AppDbContext db):Controller {
    [HttpPost("Create")] public async Task<IActionResult> Create(WorkTypeForm form) => await SaveAsync(null,form);
    [HttpPost("Update/{id:int}")] public async Task<IActionResult> Update(int id,WorkTypeForm form) => await SaveAsync(id,form);

    private async Task<IActionResult> SaveAsync(int? id,WorkTypeForm form) {
        var type=id is int key ? await db.WorkTypes.FindAsync(key) : new WorkType();
        if(type is null) return NotFound();
        var name=(form.Name??"").Trim().Normalize(NormalizationForm.FormKC);
        var normalized=name.ToUpperInvariant();
        if(name.Length==0 || name.Length>80) ModelState.AddModelError(nameof(form.Name),"กรุณากรอกชื่อประเภทงาน 1–80 ตัวอักษร");
        if(await db.WorkTypes.AnyAsync(t=>t.NormalizedName==normalized && t.Id!=type.Id))
            ModelState.AddModelError(nameof(form.Name),"มีประเภทงานชื่อนี้แล้ว รวมถึงรายการที่ปิดใช้งาน");
        if(!ModelState.IsValid) {
            TempData["WorkTypeError"]=string.Join(" ",ModelState.Values.SelectMany(v=>v.Errors).Select(e=>e.ErrorMessage));
            return RedirectToAction("Index","Shop",null,"work-types");
        }
        type.Name=name;type.NormalizedName=normalized;type.IsActive=form.IsActive;
        if(id is null) db.WorkTypes.Add(type);
        try {
            await db.SaveChangesAsync();
            TempData["Message"]="บันทึกประเภทงานแล้ว รายการใหม่จะแสดงให้ลูกค้าเลือกทันที";
        } catch(DbUpdateException) {TempData["WorkTypeError"]="ชื่อประเภทงานซ้ำ กรุณาใช้ชื่ออื่น";}
        return RedirectToAction("Index","Shop",null,"work-types");
    }
}

