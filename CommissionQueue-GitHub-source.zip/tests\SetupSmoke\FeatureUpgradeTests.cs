﻿using CommissionQueue.Data;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

static class FeatureUpgradeTests {
    public static async Task Run(string sourcePath) {
        var target=Path.GetFullPath("artifacts/features-upgrade-"+Guid.NewGuid().ToString("N")+".db");
        await using(var source=new SqliteConnection($"Data Source={sourcePath}")) {
            await source.OpenAsync();
            await using var copy=new SqliteConnection($"Data Source={target}");
            await copy.OpenAsync();source.BackupDatabase(copy);
        }
        async Task<string> Scalar(string sql) {
            await using var connection=new SqliteConnection($"Data Source={target}");await connection.OpenAsync();
            await using var command=connection.CreateCommand();command.CommandText=sql;
            return Convert.ToString(await command.ExecuteScalarAsync())!;
        }
        var count=0;
        void Check(bool ok,string label){if(!ok)throw new Exception("FAIL: "+label);Console.WriteLine("PASS: "+label);count++;}
        var orders=await Scalar("SELECT group_concat(Id || ':' || OrderCode || ':' || WorkType,'|') FROM CommissionOrder ORDER BY Id");
        var password=await Scalar("SELECT PasswordHash FROM ShopProfile");
        var types=await Scalar("SELECT group_concat(Id || ':' || Name || ':' || IsActive,'|') FROM WorkTypes ORDER BY Id");
        var images=await Scalar("SELECT COUNT(*) FROM OrderImages");
        var services=new ServiceCollection().AddDbContext<AppDbContext>(o=>o.UseSqlite($"Data Source={target}")).BuildServiceProvider();
        using var scope=services.CreateScope();
        await DbInitializer.InitializeAsync(scope.ServiceProvider);
        Check(await Scalar("SELECT group_concat(Id || ':' || OrderCode || ':' || WorkType,'|') FROM CommissionOrder ORDER BY Id")==orders,"Upgrade preserves orders and category snapshots");
        Check(await Scalar("SELECT PasswordHash FROM ShopProfile")==password,"Upgrade preserves administrator credentials");
        Check(await Scalar("SELECT group_concat(Id || ':' || Name || ':' || IsActive,'|') FROM WorkTypes ORDER BY Id")==types,"Upgrade preserves configured work types");
        Check(await Scalar("SELECT COUNT(*) FROM OrderImages")==images,"Upgrade preserves attachment count");
        Check(await Scalar("SELECT COUNT(*) FROM OrderPayments")=="0","Upgrade adds no artificial payment records");
        Check(await Scalar("SELECT COUNT(*) FROM TipSettings")=="0","Upgrade does not invent a tip QR");
        await DbInitializer.InitializeAsync(scope.ServiceProvider);
        Check(await Scalar("SELECT group_concat(Id || ':' || Name || ':' || IsActive,'|') FROM WorkTypes ORDER BY Id")==types,"Restart does not change categories");
        Check(await Scalar("SELECT COUNT(*) FROM __EFMigrationsHistory")=="6","Migration history up to date");
        Console.WriteLine($"SUCCESS: {count} existing-database upgrade checks passed.");
    }
}





