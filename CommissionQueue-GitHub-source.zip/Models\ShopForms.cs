﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using CommissionQueue.Services;
namespace CommissionQueue.Models;

public class ShopForm {
    [Required(ErrorMessage="กรุณากรอกชื่อเจ้าของร้าน"), StringLength(100, ErrorMessage="ชื่อเจ้าของยาวได้ไม่เกิน 100 ตัวอักษร"), Display(Name="ชื่อเจ้าของร้าน")]
    public string OwnerName { get; set; } = "";
    [Required(ErrorMessage="กรุณากรอกชื่อร้าน"), StringLength(80, ErrorMessage="ชื่อร้านยาวได้ไม่เกิน 80 ตัวอักษร"), Display(Name="ชื่อร้าน")]
    public string ShopName { get; set; } = "";
    [Required(ErrorMessage="กรุณากรอกอีเมล"), EmailAddress(ErrorMessage="รูปแบบอีเมลไม่ถูกต้อง"), StringLength(254), Display(Name="อีเมล")]
    public string Email { get; set; } = "";
    [Required(ErrorMessage="กรุณากรอกเบอร์โทรศัพท์"), RegularExpression(@"\+?[0-9][0-9 ()-]{7,28}", ErrorMessage="กรุณาระบุเบอร์โทรศัพท์ 8–30 ตัว เช่น 0812345678"), Display(Name="เบอร์โทรศัพท์")]
    public string Phone { get; set; } = "";
    [StringLength(200), Display(Name="LINE ID / ลิงก์ LINE")] public string? LineContact { get; set; }
    [StringLength(500), Display(Name="Facebook / ลิงก์เพจ")] public string? FacebookContact { get; set; }
    [StringLength(200), Display(Name="Instagram")] public string? InstagramContact { get; set; }
    [StringLength(500, ErrorMessage="คำอธิบายยาวได้ไม่เกิน 500 ตัวอักษร"), Display(Name="คำอธิบายร้านสั้น ๆ")] public string? Description { get; set; }
    [Display(Name="สถานะร้าน")] public bool IsOpen { get; set; } = true;
    [ShopImage, Display(Name="โลโก้ร้าน")] public IFormFile? Logo { get; set; }
    [ShopImage, Display(Name="รูปโปรไฟล์ร้าน")] public IFormFile? ProfileImage { get; set; }
    [BindNever] public string? ExistingLogoPath { get; set; }
    [BindNever] public string? ExistingProfileImagePath { get; set; }

    public void ApplyTo(ShopProfile shop) {
        shop.OwnerName=OwnerName.Trim(); shop.ShopName=ShopName.Trim();
        shop.Email=Email.Trim(); shop.Phone=Phone.Trim();
        shop.LineContact=LineContact?.Trim(); shop.FacebookContact=FacebookContact?.Trim();
        shop.InstagramContact=InstagramContact?.Trim(); shop.Description=Description?.Trim();
        shop.IsOpen=IsOpen; shop.UpdatedDate=DateTime.UtcNow;
    }
    public static ShopForm From(ShopProfile s) => new() {
        OwnerName=s.OwnerName, ShopName=s.ShopName, Email=s.Email, Phone=s.Phone,
        LineContact=s.LineContact, FacebookContact=s.FacebookContact, InstagramContact=s.InstagramContact,
        Description=s.Description, IsOpen=s.IsOpen, ExistingLogoPath=s.LogoPath, ExistingProfileImagePath=s.ProfileImagePath
    };
}
public class SetupForm : ShopForm {
    [Required(ErrorMessage="กรุณากรอกรหัสร้าน"), StringLength(30, MinimumLength=3, ErrorMessage="รหัสร้านต้องมี 3–30 ตัวอักษร"),
     RegularExpression("^[a-zA-Z0-9][a-zA-Z0-9_-]*$", ErrorMessage="ใช้ตัวอักษรอังกฤษ ตัวเลข - หรือ _ และขึ้นต้นด้วยตัวอักษรหรือตัวเลข"), Display(Name="รหัสร้าน")]
    public string ShopCode { get; set; } = "";
    [Required(ErrorMessage="กรุณากรอก Username"), StringLength(50, MinimumLength=3, ErrorMessage="Username ต้องมี 3–50 ตัวอักษร"),
     RegularExpression("^[a-zA-Z0-9._-]+$", ErrorMessage="ใช้ตัวอักษรอังกฤษ ตัวเลข จุด - หรือ _"), Display(Name="Username สำหรับ Admin")]
    public string AdminUsername { get; set; } = "";
    [Required(ErrorMessage="กรุณากรอก Password"), StringLength(128, MinimumLength=8, ErrorMessage="Password ต้องมี 8–128 ตัวอักษร"), DataType(DataType.Password), Display(Name="Password")]
    public string Password { get; set; } = "";
    [Required(ErrorMessage="กรุณายืนยัน Password"), Compare(nameof(Password), ErrorMessage="Password และยืนยัน Password ต้องตรงกัน"), DataType(DataType.Password), Display(Name="ยืนยัน Password")]
    public string ConfirmPassword { get; set; } = "";
}

