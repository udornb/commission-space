﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using CommissionQueue.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Controllers;
[EnableRateLimiting("forms"), ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
public class CommissionController(AppDbContext db, OrderFormService forms):Controller {
 public async Task<IActionResult> Create(string? workType) {ViewBag.IsOpen=(await db.ShopProfiles.SingleAsync()).IsOpen; var form=new RequestForm(); await forms.PrepareAsync(form); if(form.AvailableWorkTypes.Any(t=>t.Value==workType)) form.WorkType=workType!; return View(form);}
 [HttpPost, RequestSizeLimit(12*1024*1024), RequestFormLimits(MultipartBodyLengthLimit=12*1024*1024)] public async Task<IActionResult> Create(RequestForm f) {
  ViewBag.IsOpen=(await db.ShopProfiles.SingleAsync()).IsOpen;
  if(!(bool)ViewBag.IsOpen) ModelState.AddModelError("","ขณะนี้ร้านปิดรับคิว กรุณากลับมาใหม่ภายหลัง");
  await forms.PrepareAsync(f); forms.Validate(f,ModelState);
  if(!ModelState.IsValid) return View(f);
  await using var transaction=await db.Database.BeginTransactionAsync();
  var o=new CommissionOrder {OrderCode=Guid.NewGuid().ToString(),CustomerName=f.CustomerName.Trim(),Contact=f.Contact.Trim(),WorkType=f.WorkType.Trim(),Description=f.Description.Trim(),Budget=f.Budget!.Value,DueDate=f.DueDate!.Value,ReferenceUrl=f.ReferenceUrl,CustomerNote=f.CustomerNote,Status=OrderStatus.Pending};
  db.CommissionOrders.Add(o); await forms.AddImagesAsync(o,f.Images,HttpContext.RequestAborted); await db.SaveChangesAsync();
  o.OrderCode=$"COM-{o.Id:D4}"; await db.SaveChangesAsync(); await transaction.CommitAsync();
  TempData["OrderCode"]=o.OrderCode; return RedirectToAction(nameof(Success));
 }
 public IActionResult Success()=>TempData["OrderCode"] is string code ? View(model:code):RedirectToAction(nameof(Create));
 public IActionResult Track()=>View();
 [HttpPost] public async Task<IActionResult> Track(string? orderCode) {
  var code=orderCode?.Trim().ToUpperInvariant();
  if(string.IsNullOrWhiteSpace(code)||code.Length>30) ModelState.AddModelError("","กรุณากรอกเลข Order เช่น COM-0001");
  if(!ModelState.IsValid) return View();
  var o=await db.CommissionOrders.AsNoTracking().SingleOrDefaultAsync(x=>x.OrderCode==code);
  if(o is null) ModelState.AddModelError("","ไม่พบเลข Order นี้ กรุณาตรวจสอบแล้วลองใหม่");
  ViewBag.OrderCode=code; return View(o);
 }
}


