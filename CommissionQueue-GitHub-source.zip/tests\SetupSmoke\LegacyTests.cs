﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

static class LegacyTests {
    public static async Task Run(string sourcePath) {
        var target=Path.GetFullPath("artifacts/legacy-"+Guid.NewGuid().ToString("N")+".db");
        await using(var source=new SqliteConnection($"Data Source={sourcePath}")) {
            await source.OpenAsync();
            await using var copy=new SqliteConnection($"Data Source={target}");
            await copy.OpenAsync(); source.BackupDatabase(copy);
        }
        var count=0;
        void Check(bool ok,string message) {if(!ok)throw new Exception("FAIL: "+message);Console.WriteLine("PASS: "+message);count++;}
        async Task<string> Scalar(string sql) {
            await using var connection=new SqliteConnection($"Data Source={target}");await connection.OpenAsync();
            await using var command=connection.CreateCommand();command.CommandText=sql;
            return Convert.ToString(await command.ExecuteScalarAsync())!;
        }
        var previousCount=await Scalar("SELECT COUNT(*) FROM CommissionOrder");
        var previousHash=await Scalar("SELECT PasswordHash FROM AdminUsers LIMIT 1");
        var previousName=await Scalar("SELECT ShopName FROM ShopSettings LIMIT 1");
        var services=new ServiceCollection().AddDbContext<AppDbContext>(o=>o.UseSqlite($"Data Source={target}")).BuildServiceProvider();
        using var scope=services.CreateScope();
        await DbInitializer.InitializeAsync(scope.ServiceProvider);
        var db=scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var shop=await db.ShopProfiles.SingleAsync();
        Check(shop.ShopName==previousName,"Legacy shop name preserved");
        Check(shop.PasswordHash==previousHash,"Existing password hash preserved");
        Check(new PasswordHasher<ShopProfile>().VerifyHashedPassword(shop,shop.PasswordHash,"Mellow@12345")!=PasswordVerificationResult.Failed,"Legacy admin password still verifies");
        Check(await Scalar("SELECT COUNT(*) FROM CommissionOrder")==previousCount,"Legacy orders preserved");
        Check(shop.ShopCode=="LEGACY-0001","Legacy shop assigned a stable unique code");
        Check(Directory.GetFiles(Path.GetDirectoryName(target)!,Path.GetFileName(target)+".pre-setup-*.db").Length==1,"Legacy backup created before migration");
        Check(await Scalar("SELECT COUNT(*) FROM __EFMigrationsHistory")=="6","Legacy baseline and new migration recorded");
        await DbInitializer.InitializeAsync(scope.ServiceProvider);
        Check(await db.ShopProfiles.CountAsync()==1 && await Scalar("SELECT COUNT(*) FROM CommissionOrder")==previousCount,"Restart does not duplicate shop or orders");
        Check(Directory.GetFiles(Path.GetDirectoryName(target)!,Path.GetFileName(target)+".pre-setup-*.db").Length==1,"Restart does not repeat baseline adoption");
        Check(await Scalar("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('AdminUsers','ShopSettings')")=="0","Old credential tables replaced by ShopProfile");
        // Database constraints remain effective even when bypassing MVC validation.
        try {
            await db.Database.ExecuteSqlRawAsync("""
                INSERT INTO ShopProfile (Id,ShopCode,OwnerName,ShopName,AdminUsername,PasswordHash,Email,Phone,IsOpen,CreatedDate,UpdatedDate)
                VALUES (2,'LEGACY-0001','x','x','x','x','x','x',1,datetime('now'),datetime('now'));
                """);
            throw new Exception("Second shop was accepted");
        } catch(SqliteException ex) {Check(ex.SqliteErrorCode==19,"Database rejects second shop / duplicate code");}
        Console.WriteLine($"SUCCESS: {count} legacy migration checks passed. Test copy: {target}");
    }
}





