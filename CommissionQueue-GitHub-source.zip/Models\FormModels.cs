﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Models;
using CommissionQueue.Services;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;
public class RequestForm : IValidatableObject {
 [OrderImages, Display(Name="ภาพประกอบรายละเอียดงาน")] public List<IFormFile> Images {get;set;}=[];
 [BindNever, ValidateNever] public List<SelectListItem> AvailableWorkTypes {get;set;}=[];
 [BindNever, ValidateNever] public List<OrderImageInfo> ExistingImages {get;set;}=[];
 [Required(ErrorMessage="กรุณากรอกชื่อลูกค้า"), StringLength(100), Display(Name="ชื่อลูกค้า")] public string CustomerName {get;set;}="";
 [Required(ErrorMessage="กรุณากรอกช่องทางติดต่อ"), StringLength(200), Display(Name="ช่องทางติดต่อ")] public string Contact {get;set;}="";
 [Required(ErrorMessage="กรุณาเลือกประเภทงาน"), StringLength(80), Display(Name="ประเภทงาน")] public string WorkType {get;set;}="";
 [Required(ErrorMessage="กรุณากรอกรายละเอียดงาน"), StringLength(4000), Display(Name="รายละเอียดงาน")] public string Description {get;set;}="";
 [Required(ErrorMessage="กรุณากรอกงบประมาณ"), Range(typeof(decimal),"1","10000000"), Display(Name="งบประมาณ (บาท)")] public decimal? Budget {get;set;}
 [Required(ErrorMessage="กรุณาเลือกวันที่ต้องการงาน"), DataType(DataType.Date), Display(Name="วันที่ต้องการงาน")] public DateTime? DueDate {get;set;}
 [StringLength(2000), Display(Name="ลิงก์ Reference")] public string? ReferenceUrl {get;set;}
 [StringLength(2000), Display(Name="หมายเหตุเพิ่มเติม")] public string? CustomerNote {get;set;}
 public IEnumerable<ValidationResult> Validate(ValidationContext context) {
  if(ReferenceUrl is not null && (!Uri.TryCreate(ReferenceUrl,UriKind.Absolute,out var uri) || (uri.Scheme!="https" && uri.Scheme!="http"))) yield return new ValidationResult("กรุณาระบุลิงก์ http:// หรือ https://", [nameof(ReferenceUrl)]);
  if(this is not EditForm && DueDate?.Date < DateTime.UtcNow.AddHours(7).Date) yield return new ValidationResult("วันที่ต้องการงานต้องไม่เป็นวันที่ผ่านมาแล้ว", [nameof(DueDate)]);
 }
}
public class EditForm : RequestForm {
 [ShopImage, Display(Name="QR Code ชำระเงิน")] public IFormFile? PaymentQr {get;set;}
 [StringLength(100), Display(Name="ชื่อผู้รับเงิน (ไม่บังคับ)")] public string? PaymentRecipientName {get;set;}
 public bool RemovePaymentQr {get;set;}
 [StringLength(32)] public string? PaymentRevision {get;set;}
 [BindNever, ValidateNever] public bool HasPaymentQr {get;set;}
 public List<int> RemoveImageIds {get;set;}=[];
 public int Id {get;set;}
 [EnumDataType(typeof(OrderStatus)), Display(Name="สถานะงาน")] public OrderStatus Status {get;set;}
 [Range(typeof(decimal),"0","10000000"), Display(Name="ราคาจริง (บาท)")] public decimal? FinalPrice {get;set;}
 [DataType(DataType.Date), Display(Name="วันที่คาดว่าจะเสร็จ")] public DateTime? EstimatedFinishDate {get;set;}
 [StringLength(2000), Display(Name="หมายเหตุจากผู้รับงาน (ลูกค้าเห็นได้)")] public string? AdminNote {get;set;}
}
public class LoginForm {
 [Required(ErrorMessage="กรุณากรอกชื่อผู้ใช้"), StringLength(100), Display(Name="ชื่อผู้ใช้")] public string Username {get;set;}="";
 [Required(ErrorMessage="กรุณากรอกรหัสผ่าน"), StringLength(200), DataType(DataType.Password), Display(Name="รหัสผ่าน")] public string Password {get;set;}="";
}
public record HomeModel(ShopProfile Shop,int ActiveCount,int InProgressCount,int CompletedCount,List<CommissionOrder> Queue);
public record DashboardModel(ShopProfile Shop,List<CommissionOrder> Orders);

