﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CommissionQueue.Migrations
{
    /// <inheritdoc />
    public partial class AddOrderPaymentsAndTipJar : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OrderPayments",
                columns: table => new
                {
                    CommissionOrderId = table.Column<int>(type: "INTEGER", nullable: false),
                    QrImage = table.Column<byte[]>(type: "BLOB", nullable: false),
                    ContentType = table.Column<string>(type: "TEXT", maxLength: 30, nullable: false),
                    RecipientName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: true),
                    Revision = table.Column<string>(type: "TEXT", maxLength: 32, nullable: false),
                    ReportedAt = table.Column<DateTime>(type: "TEXT", nullable: true),
                    ConfirmedAt = table.Column<DateTime>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderPayments", x => x.CommissionOrderId);
                    table.ForeignKey(
                        name: "FK_OrderPayments_CommissionOrder_CommissionOrderId",
                        column: x => x.CommissionOrderId,
                        principalTable: "CommissionOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TipSettings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false),
                    IsEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    QrImage = table.Column<byte[]>(type: "BLOB", nullable: true),
                    ContentType = table.Column<string>(type: "TEXT", maxLength: 30, nullable: true),
                    RecipientName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TipSettings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TipSettings_ShopProfile_Id",
                        column: x => x.Id,
                        principalTable: "ShopProfile",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrderPayments");

            migrationBuilder.DropTable(
                name: "TipSettings");
        }
    }
}
