﻿using System.ComponentModel.DataAnnotations;
using CommissionQueue.Services;
namespace CommissionQueue.Models;

public class OrderPayment {
    public int CommissionOrderId { get; set; }
    public CommissionOrder CommissionOrder { get; set; } = null!;
    public byte[] QrImage { get; set; } = [];
    [MaxLength(30)] public string ContentType { get; set; } = "image/png";
    [MaxLength(100)] public string? RecipientName { get; set; }
    [MaxLength(32)] public string Revision { get; set; } = Guid.NewGuid().ToString("N");
    public DateTime? ReportedAt { get; set; }
    public DateTime? ConfirmedAt { get; set; }
}
public class TipSettings {
    public int Id { get; set; } = 1;
    public ShopProfile ShopProfile { get; set; } = null!;
    public bool IsEnabled { get; set; }
    public byte[]? QrImage { get; set; }
    [MaxLength(30)] public string? ContentType { get; set; }
    [MaxLength(100)] public string? RecipientName { get; set; }
}
public class TipForm {
    public bool IsEnabled { get; set; }
    [ShopImage, Display(Name="QR Code รับทิป")] public IFormFile? QrImage { get; set; }
    [StringLength(100), Display(Name="ชื่อผู้รับเงิน (ไม่บังคับ)")] public string? RecipientName { get; set; }
    public bool RemoveQr { get; set; }
}
public record PaymentPageModel(string OrderCode, decimal? FinalPrice, OrderStatus Status, OrderPayment? Payment);
public record PaymentNotice(int OrderId, string OrderCode);

