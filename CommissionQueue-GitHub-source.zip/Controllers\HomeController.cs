﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Controllers;
public class HomeController(AppDbContext db):Controller {
 public async Task<IActionResult> Index() {
  ViewBag.WorkTypes=await db.WorkTypes.AsNoTracking().Where(t=>t.IsActive).OrderBy(t=>t.Id).ToListAsync();
  ViewBag.Tips=await db.TipSettings.AsNoTracking().SingleOrDefaultAsync(t=>t.IsEnabled && t.QrImage!=null);
  var orders=await db.CommissionOrders.AsNoTracking().OrderBy(x=>x.Id).ToListAsync();
  return View(new HomeModel(await db.ShopProfiles.SingleAsync(),orders.Count(x=>x.Status.Active()),orders.Count(x=>x.Status==OrderStatus.InProgress),orders.Count(x=>x.Status==OrderStatus.Completed),orders.Where(x=>x.Status.Active()).Take(3).ToList()));
 }
 public async Task<IActionResult> Queue()=>View(await db.CommissionOrders.AsNoTracking().Where(x=>x.Status!=OrderStatus.Completed && x.Status!=OrderStatus.Cancelled).OrderBy(x=>x.Id).ToListAsync());
 [ResponseCache(Duration=0,Location=ResponseCacheLocation.None,NoStore=true)]
 public IActionResult Error(int? statusCode) {ViewBag.StatusCode=statusCode??500; return View();}
 [HttpGet, ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
 public async Task<IActionResult> TipQr() {
  var tip=await db.TipSettings.AsNoTracking().SingleOrDefaultAsync(t=>t.IsEnabled && t.QrImage!=null);
  return tip?.QrImage is null ? NotFound() : File(tip.QrImage,tip.ContentType ?? "image/png");
 }
}



