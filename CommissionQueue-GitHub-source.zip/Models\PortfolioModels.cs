﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Models;
public class PortfolioSetting {
 public int Id {get;set;}=1;
 [StringLength(6000)] public string Rates {get;set;}="";
}
public class PortfolioItem {
 public int Id {get;set;}
 [Required,StringLength(120)] public string Title {get;set;}="";
 [StringLength(2000)] public string? Description {get;set;}
 public byte[] Content {get;set;}=[];
 public string ContentType {get;set;}="";
 public DateTime CreatedDate {get;set;}=DateTime.UtcNow;
}
public class PortfolioUpload {
 [Required(ErrorMessage="กรุณาใส่ชื่อผลงาน"),StringLength(120)] public string Title {get;set;}="";
 [StringLength(2000)] public string? Description {get;set;}
 [Required(ErrorMessage="กรุณาเลือกภาพหรือวิดีโอ")] public IFormFile? Media {get;set;}
}
public record PortfolioCard(int Id,string Title,string? Description,string ContentType);
public record PortfolioPage(string Rates,List<PortfolioCard> Items);
