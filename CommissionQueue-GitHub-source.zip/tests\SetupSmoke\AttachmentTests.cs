﻿using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;

static class AttachmentTests {
    public static async Task Run(string baseUrl,string dbPath) {
        var count=0;
        void Check(bool ok,string label) {if(!ok)throw new Exception("FAIL: "+label);Console.WriteLine("PASS: "+label);count++;}
        HttpClient Client()=>new(new HttpClientHandler{AllowAutoRedirect=false,CookieContainer=new CookieContainer()}){BaseAddress=new Uri(baseUrl)};
        using var admin=Client();using var customer=Client();
        async Task<string> Page(HttpClient c,string path) {
            var response=await c.GetAsync(path);response.EnsureSuccessStatusCode();return WebUtility.HtmlDecode(await response.Content.ReadAsStringAsync());
        }
        async Task<string> Token(HttpClient c,string path)=>Regex.Match(await Page(c,path),"name=\"__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
        async Task<HttpResponseMessage> Post(HttpClient c,string path,Dictionary<string,string> fields,string token,List<byte[]>? files=null,string fileName="reference.png") {
            using var body=new MultipartFormDataContent();
            foreach(var field in fields)body.Add(new StringContent(field.Value),field.Key);
            body.Add(new StringContent(token),"__RequestVerificationToken");
            foreach(var bytes in files??[])body.Add(new ByteArrayContent(bytes),"Images",fileName);
            return await c.PostAsync(path,body);
        }
        async Task<string> Sql(string sql) {
            await using var db=new SqliteConnection($"Data Source={dbPath}");await db.OpenAsync();
            await using var command=db.CreateCommand();command.CommandText=sql;
            return Convert.ToString(await command.ExecuteScalarAsync())!;
        }
        async Task<bool> Invalid(HttpResponseMessage response)=>response.StatusCode==HttpStatusCode.OK && (await response.Content.ReadAsStringAsync()).Contains("validation-summary-errors");
        var setup=new Dictionary<string,string>{["ShopCode"]="IMAGE-TEST",["OwnerName"]="Test Owner",["ShopName"]="Mellow Studio",["AdminUsername"]="admin",["Password"]="Mellow@12345",["ConfirmPassword"]="Mellow@12345",["Email"]="owner@example.test",["Phone"]="0812345678",["IsOpen"]="true"};
        Check((await Post(admin,"/Setup",setup,await Token(admin,"/Setup"))).StatusCode==HttpStatusCode.Redirect,"Configure isolated test shop");
        Check(await Sql("SELECT COUNT(*) FROM __EFMigrationsHistory")=="6","New migration applied");
        Check(await Sql("SELECT COUNT(*) FROM WorkTypes")=="3","Editable defaults seeded once");
        var adminToken=await Token(admin,"/Admin/Shop");
        Check((await customer.PostAsync("/Admin/WorkTypes/Create",new FormUrlEncodedContent(new Dictionary<string,string>{{"Name","unauthorized"}}))).StatusCode==HttpStatusCode.Redirect,"Work types require admin login");
        var noCsrf=await admin.PostAsync("/Admin/WorkTypes/Create",new FormUrlEncodedContent(new Dictionary<string,string>{{"Name","unsafe"}}));
        Check(noCsrf.StatusCode==HttpStatusCode.BadRequest,"Work type writes require CSRF");
        await Post(admin,"/Admin/WorkTypes/Create",new(){["Name"]="ภาพลูป",["IsActive"]="true"},adminToken);
        Check(await Sql("SELECT COUNT(*) FROM WorkTypes")=="4","Admin adds a work type");
        await Post(admin,"/Admin/WorkTypes/Create",new(){["Name"]=" ภาพลูป ",["IsActive"]="true"},adminToken);
        Check(await Sql("SELECT COUNT(*) FROM WorkTypes")=="4" && (await Page(admin,"/Admin/Shop")).Contains("มีประเภทงานชื่อนี้แล้ว"),"Duplicate normalized names rejected");
        await Post(admin,"/Admin/WorkTypes/Create",new(){["Name"]="   ",["IsActive"]="true"},adminToken);
        Check(await Sql("SELECT COUNT(*) FROM WorkTypes")=="4","Blank work type rejected");
        var form=await Page(customer,"/Commission/Create");
        Check(form.Contains("<select") && form.Contains("ภาพลูป"),"New category appears in customer dropdown");
        Check((await Page(customer,"/")).Contains("ภาพลูป"),"Home uses editable categories");
        var customerToken=await Token(customer,"/Commission/Create");
        var order=new Dictionary<string,string>{["CustomerName"]="Image Customer",["Contact"]="private@example.test",["WorkType"]="ภาพลูป",["Description"]="Image reference brief",["Budget"]="1500",["DueDate"]=DateTime.UtcNow.AddDays(30).ToString("yyyy-MM-dd")};
        var png=Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII=");
        var unknown=new Dictionary<string,string>(order){["WorkType"]="unknown"};
        Check(await Invalid(await Post(customer,"/Commission/Create",unknown,customerToken)),"Unknown category rejected server-side");
        Check(await Invalid(await Post(customer,"/Commission/Create",order,customerToken,[Encoding.UTF8.GetBytes("<script>fake image</script>")])),"Spoofed image rejected");
        Check(await Invalid(await Post(customer,"/Commission/Create",order,customerToken,[new byte[2*1024*1024+1]])),"Oversized image rejected");
        Check(await Invalid(await Post(customer,"/Commission/Create",order,customerToken,[png],"reference.svg")),"SVG rejected");
        Check(await Invalid(await Post(customer,"/Commission/Create",order,customerToken,Enumerable.Repeat(png,6).ToList())),"More than five uploads rejected");
        Check(await Sql("SELECT COUNT(*) FROM CommissionOrder")=="3" && await Sql("SELECT COUNT(*) FROM OrderImages")=="0","Failed requests leave no order or attachment");
        var created=await Post(customer,"/Commission/Create",order,customerToken,[png,png]);
        Check(created.StatusCode==HttpStatusCode.Redirect,"Order with multiple images saved");
        Check(await Sql("SELECT COUNT(*) FROM OrderImages WHERE CommissionOrderId=4")=="2","Two images linked to order");
        var imageId=await Sql("SELECT MIN(Id) FROM OrderImages WHERE CommissionOrderId=4");
        Check((await customer.GetAsync("/Admin/OrderImage/"+imageId)).StatusCode==HttpStatusCode.Redirect,"Customer cannot fetch private admin image endpoint");
        var image=await admin.GetAsync("/Admin/OrderImage/"+imageId);
        Check(image.IsSuccessStatusCode && image.Content.Headers.ContentType?.MediaType=="image/png" && (await image.Content.ReadAsByteArrayAsync()).SequenceEqual(png),"Admin sees actual image content");
        Check((await Page(admin,"/Admin/Details/4")).Contains("/Admin/OrderImage/"+imageId),"Admin detail page renders attachments");
        await Post(admin,"/Admin/WorkTypes/Update/4",new(){["Name"]="อนิเมชั่น",["IsActive"]="true"},adminToken);
        Check(await Sql("SELECT WorkType FROM CommissionOrder WHERE Id=4")=="ภาพลูป","Renaming category preserves order history");
        await Post(admin,"/Admin/WorkTypes/Update/4",new(){["Name"]="อนิเมชั่น",["IsActive"]="false"},adminToken);
        Check(!(await Page(customer,"/Commission/Create")).Contains("อนิเมชั่น"),"Disabled type hidden from new requests");
        var inactive=new Dictionary<string,string>(order){["WorkType"]="อนิเมชั่น"};
        Check(await Invalid(await Post(customer,"/Commission/Create",inactive,customerToken)),"Disabled category rejected server-side");
        Check((await Page(admin,"/Admin/Edit/4")).Contains("ภาพลูป (ประเภทเดิม)"),"Old category remains selectable when editing");
        var edit=new Dictionary<string,string>(order){["Id"]="4",["Status"]="2"};
        Check((await Post(admin,"/Admin/Edit/4",edit,adminToken)).StatusCode==HttpStatusCode.Redirect,"Existing order editable after category rename and disable");
        Check(await Invalid(await Post(admin,"/Admin/Edit/4",edit,adminToken,[png,png,png,png])),"Combined existing and new image limit enforced");
        var other=new Dictionary<string,string>(order){["WorkType"]="รูปตัวละคร"};
        Check((await Post(customer,"/Commission/Create",other,customerToken,[png])).StatusCode==HttpStatusCode.Redirect,"Second order with separate image saved");
        var otherImage=await Sql("SELECT Id FROM OrderImages WHERE CommissionOrderId=5 LIMIT 1");
        var foreignRemoval=new Dictionary<string,string>(edit){["RemoveImageIds"]=otherImage};
        Check(await Invalid(await Post(admin,"/Admin/Edit/4",foreignRemoval,adminToken)),"Cannot remove another order's image");
        var removal=new Dictionary<string,string>(edit){["RemoveImageIds"]=imageId};
        Check((await Post(admin,"/Admin/Edit/4",removal,adminToken,[png])).StatusCode==HttpStatusCode.Redirect,"Admin can replace an attachment");
        Check(await Sql("SELECT COUNT(*) FROM OrderImages WHERE CommissionOrderId=4")=="2" && (await admin.GetAsync("/Admin/OrderImage/"+imageId)).StatusCode==HttpStatusCode.NotFound,"Removed image no longer accessible");
        var names=new[]{"รูปตัวละคร","โปรไฟล์ & อวาตาร์","จิบิ & สติกเกอร์"};
        for(var i=0;i<3;i++)await Post(admin,$"/Admin/WorkTypes/Update/{i+1}",new(){["Name"]=names[i],["IsActive"]="false"},adminToken);
        Check((await Page(customer,"/Commission/Create")).Contains("ร้านยังไม่ได้เปิดรับประเภทงาน"),"No active types shows a readable empty state");
        Check(await Invalid(await Post(customer,"/Commission/Create",other,customerToken)),"No-active-category requests rejected");
        for(var i=0;i<3;i++)await Post(admin,$"/Admin/WorkTypes/Update/{i+1}",new(){["Name"]=names[i],["IsActive"]="true"},adminToken);
        await Post(admin,"/Admin/WorkTypes/Update/4",new(){["Name"]="อนิเมชั่น",["IsActive"]="true"},adminToken);
        await Post(admin,"/Admin/Delete/4",new(),adminToken);
        Check(await Sql("SELECT COUNT(*) FROM OrderImages WHERE CommissionOrderId=4")=="0","Deleting order cascades attachments");
        Check(await Sql("SELECT COUNT(*) FROM OrderImages WHERE CommissionOrderId=5")=="1","Other order images remain intact");
        Console.WriteLine($"SUCCESS: {count} attachment/category checks passed.");
    }
}




