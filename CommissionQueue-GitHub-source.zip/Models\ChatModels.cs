﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Models;

public class OrderMessage {
 public int Id {get;set;}
 public int CommissionOrderId {get;set;}
 public CommissionOrder CommissionOrder {get;set;}=null!;
 public bool FromAdmin {get;set;}
 [StringLength(4000)] public string? Text {get;set;}
 public DateTime CreatedDate {get;set;}=DateTime.UtcNow;
 [StringLength(180)] public string? FileName {get;set;}
 [StringLength(80)] public string? ContentType {get;set;}
 public byte[]? FileContent {get;set;}
}
public class ChatForm {
 [StringLength(4000,ErrorMessage="ข้อความยาวได้ไม่เกิน 4,000 ตัวอักษร")] public string? Text {get;set;}
 public IFormFile? Attachment {get;set;}
}
public record ChatMessageInfo(int Id,bool FromAdmin,string? Text,DateTime CreatedDate,string? FileName,string? ContentType);
public record ChatPage(string OrderCode,bool IsAdmin,List<ChatMessageInfo> Messages,string CustomerName,string ShopName,int? Before=null) { public string? ViewMode=>IsAdmin ? null : "customer"; }

