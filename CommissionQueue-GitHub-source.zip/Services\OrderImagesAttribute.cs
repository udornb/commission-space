﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Services;

public sealed class OrderImagesAttribute : ValidationAttribute {
    public const int MaxCount=5;
    protected override ValidationResult? IsValid(object? value, ValidationContext context) {
        if(value is not List<IFormFile> files) return ValidationResult.Success;
        if(files.Count>MaxCount) return new("แนบรูปได้ไม่เกิน 5 รูปต่อออเดอร์");
        var validator=new ShopImageAttribute();
        foreach(var file in files) {
            var error=validator.GetValidationResult(file,context);
            if(error is not null) return error;
        }
        return ValidationResult.Success;
    }
}

