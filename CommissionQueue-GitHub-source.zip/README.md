﻿# CommissionQueue — ระบบคิวคอมมิชชั่นและตั้งค่าร้านครั้งแรก

ASP.NET Core MVC / .NET 10 / Entity Framework Core / SQLite พร้อม HTML, CSS, JavaScript และ UI ภาษาไทย

## เพิ่มภาพในรายละเอียดงานและตั้งประเภทงานเอง

### ภาพประกอบรายละเอียดงาน
- ที่หน้าส่งคำขอ ใต้ “รายละเอียดงาน” เลือกรูป PNG/JPG ได้รวมไม่เกิน 5 รูป รูปละไม่เกิน 2 MB
- เห็น preview ก่อนส่ง และกด “นำรูปออก” เพื่อแก้รายการที่เลือกได้
- เจ้าของร้านดูรูปใน Admin > ดูรายละเอียด Order และคลิกรูปเพื่อเปิดขนาดเต็ม
- ที่หน้าแก้ไข Order สามารถแนบรูปเพิ่มหรือเลือก “ลบรูปนี้เมื่อบันทึก”
- การลบรูปและเพิ่มรูปมีผลเมื่อบันทึกสำเร็จ รวมรูปเก่าและใหม่ต้องไม่เกิน 5 รูป
- Server ตรวจจำนวน ขนาด นามสกุล และลายเซ็นไฟล์; รูปเก็บเป็น BLOB ในตาราง OrderImages
- รูปของงานอ่านผ่าน endpoint แอดมินเท่านั้น ไม่เผยแพร่เป็น static files และไม่แสดงบน Queue/หน้าติดตามสาธารณะ
- ลบ Order แล้วระบบลบแถวภาพของ Order นั้นด้วย SQLite cascade
- หาก validation ไม่ผ่าน ให้เลือกไฟล์ใหม่ก่อนส่งซ้ำ

### ประเภทงานที่รับ
- เปิด Admin > ตั้งค่าร้าน แล้วเลื่อนไปการ์ด “ประเภทงานที่รับ” (/Admin/Shop#work-types)
- เพิ่มชื่อใหม่ เช่น “ภาพลูป” หรือ “อนิเมชั่น” แล้วกด “เพิ่มประเภทงาน”
- แก้ชื่อในรายการเดิมแล้วกด “บันทึก” หรือเอาเครื่องหมาย “เปิดรับ” ออกเพื่อซ่อนจากคำขอใหม่
- Home และ dropdown ในหน้าส่งคำขอใช้ข้อมูลจากตาราง WorkTypes ทันที
- ไม่รับชื่อว่าง/ชื่อซ้ำ ชื่อยาวได้ไม่เกิน 80 ตัวอักษร
- ถ้าปิดทุกประเภท ลูกค้าจะเห็นข้อความว่ายังไม่เปิดรับประเภทงาน และส่งคำขอใหม่ไม่ได้
- ประเภทใน Order เก่าเก็บเป็นข้อความ ณ เวลารับงาน จึงไม่เปลี่ยนตามชื่อในตั้งค่าร้าน
- หน้าแก้ไข Order ยังเลือกประเภทเดิมที่เปลี่ยนชื่อหรือปิดรับไปแล้วได้ เพื่อรักษาประวัติ
- ค่าเริ่มต้น: รูปตัวละคร, โปรไฟล์ & อวาตาร์, จิบิ & สติกเกอร์ เจ้าของร้านปรับได้เอง

Migration ใหม่ AddWorkTypesAndOrderImages เพิ่มเฉพาะตาราง WorkTypes และ OrderImages
อัปเกรดอัตโนมัติเมื่อรัน ไม่ลบข้อมูลร้าน บัญชี หรือ Order เดิม
การสำรอง commissions.db จะรวมรูปแนบงานด้วย ส่วนโลโก้/โปรไฟล์ร้านยังสำรอง wwwroot/uploads/shops ตามเดิม

ทดสอบฟีเจอร์นี้:
- 35 integration checks สำหรับแนบรูปและจัดการประเภทงาน
- 23 regression checks สำหรับฟีเจอร์คิวเดิม
- 6 checks สำหรับอัปเกรดสำเนาฐานข้อมูลเดิมและ restart
- Browser ตรวจ preview หลายรูป การนำรูปออก การปฏิเสธไฟล์ผิดประเภท และ dropdown
- ตรวจหน้าลูกค้า ตั้งค่าร้าน และแก้ไข Order ที่ความกว้าง 390px

ใช้ server ฐานข้อมูลใหม่แยกที่ port 5081 แล้วรัน:

~~~powershell
dotnet run --project tests/SetupSmoke/SetupSmoke.csproj -c Release -- --attachments http://localhost:5081 artifacts/attachments-test.db
~~~

ชื่อไฟล์ฐานข้อมูลในคำสั่งต้องตรงกับ DatabasePath ของ server และต้องยังไม่มีร้าน
สคริปต์สร้างบัญชีทดสอบ admin / Mellow@12345 ไม่ใช้กับข้อมูลจริง
ทดสอบ migration กับสำเนาฐานข้อมูลที่มี ShopProfile แต่ยังไม่มี WorkTypes:

~~~powershell
dotnet run --project tests/SetupSmoke/SetupSmoke.csproj -c Release -- --feature-upgrade commissions.db
~~~

## เปลี่ยนชื่อผู้ใช้และรหัสผ่าน Admin

เปิด /Admin/Shop#admin-account หรือกด “เปลี่ยนชื่อผู้ใช้ / รหัสผ่าน” ใต้บัญชีผู้ดูแลในตั้งค่าร้าน

1. กรอกชื่อผู้ใช้ที่ต้องการ (3–50 ตัวอักษรอังกฤษ/ตัวเลข/จุด/-/_)
2. ยืนยันรหัสผ่านปัจจุบัน
3. ถ้าต้องการเปลี่ยนรหัสผ่าน ให้กรอกรหัสผ่านใหม่ 8–128 ตัวอักษรและยืนยันให้ตรงกัน
4. หากเปลี่ยนเฉพาะชื่อผู้ใช้ ให้เว้นรหัสผ่านใหม่และช่องยืนยันว่าง
5. กด “บันทึกบัญชีเข้าสู่ระบบ” แล้ว Login ด้วยข้อมูลใหม่

รหัสผ่านเก็บด้วย PasswordHasher เท่านั้น การบันทึกสำเร็จจะยกเลิก session เดิมทุกอุปกรณ์
รหัสร้าน ข้อมูลร้าน และ Orders ไม่เปลี่ยนตามบัญชีเข้าสู่ระบบ
ใช้ฟอร์มบัญชีแยกจากฟอร์มโปรไฟล์ร้าน จึงไม่ต้องกรอกข้อมูลโปรไฟล์อื่นใหม่
หลังอัปเดตเวอร์ชันนี้ ผู้ใช้ที่เคย Login อยู่ต้อง Login ใหม่หนึ่งครั้งเพื่อออก cookie รุ่นที่ตรวจการเปลี่ยนรหัสผ่าน
ไม่ต้องเพิ่ม migration เพราะใช้ฟิลด์ AdminUsername / PasswordHash เดิม

ทดสอบ 25 checks: Validation, รหัสผ่านปัจจุบัน, ยืนยันรหัสผ่านใหม่, เปลี่ยนชื่ออย่างเดียว,
เปลี่ยนรหัสผ่านอย่างเดียว, เปลี่ยนทั้งคู่, รหัสเดิมใช้ไม่ได้, session อุปกรณ์อื่นหมดผล,
CSRF, password hash และข้อมูลร้าน/Orders ไม่เปลี่ยน

ทดสอบกับฐานข้อมูลใหม่แยกจากข้อมูลจริงบน port 5081:

~~~powershell
dotnet run --project tests/SetupSmoke/SetupSmoke.csproj -c Release -- --credentials http://localhost:5081 artifacts/credentials-test.db
~~~

## เปิดและรัน

1. เปิด CommissionQueue.sln ใน Visual Studio 2026 ที่รองรับ .NET 10 พร้อม workload ASP.NET and web development
2. รอ NuGet Restore เลือกโปรไฟล์ http แล้วกด Ctrl+F5
3. เปิด http://localhost:5080/ — ถ้ายังไม่มีร้าน ระบบจะพาไป /Setup อัตโนมัติ
4. ตั้งค่าร้านและบัญชี Admin ของคุณ เมื่อเสร็จจะเข้าสู่ระบบให้ทันที แสดงข้อความสำเร็จและปุ่มเข้าสู่ Dashboard

หรือรันจาก PowerShell ที่โฟลเดอร์โปรเจกต์:

~~~powershell
dotnet restore CommissionQueue.csproj
dotnet build CommissionQueue.sln
dotnet run --project CommissionQueue.csproj --launch-profile http
~~~

ไม่ต้องติดตั้ง SQLite Server และไม่ต้องสั่ง migration เองก่อนรัน
แอปเรียก Database.MigrateAsync อัตโนมัติ
หยุดด้วย Ctrl+C ก่อนรันอีกครั้งบน port เดียวกัน

## URL

| หน้า | URL |
|---|---|
| Home | http://localhost:5080/ |
| ตั้งค่าร้านครั้งแรก | http://localhost:5080/Setup |
| Login | http://localhost:5080/Admin/Login |
| Dashboard | http://localhost:5080/Admin |
| ตั้งค่าร้านใน Admin | http://localhost:5080/Admin/Shop |
| ส่งคำขอ | http://localhost:5080/Commission/Create |
| ติดตามงาน | http://localhost:5080/Commission/Track |
| คิวสาธารณะ | http://localhost:5080/Home/Queue |

ฐานข้อมูลใหม่ **ไม่มี Username/Password เริ่มต้น** ให้ตั้งเองใน Setup
ค่าตัวอย่าง admin / Mellow@12345 ใช้เฉพาะฐานข้อมูลเก่าหรือสคริปต์ทดสอบ
ตัวแปร Admin__Username / Admin__Password จากเวอร์ชันเก่าไม่ใช้สร้างบัญชีอัตโนมัติอีกต่อไป

## Setup แบบ 2 ขั้นตอน

**ขั้นตอน 1: ข้อมูลร้าน**
- รหัสร้าน (3–30 ตัวอักษรอังกฤษ/ตัวเลข/-/_ และขึ้นต้นด้วยตัวอักษรหรือตัวเลข)
- ชื่อเจ้าของร้าน ชื่อร้าน
- โลโก้ รูปโปรไฟล์ คำอธิบายร้าน
- สถานะเปิดหรือปิดรับคิว

**ขั้นตอน 2: บัญชีผู้ดูแล**
- Username (3–50 ตัวอักษรอังกฤษ/ตัวเลข/จุด/-/_)
- Password 8–128 ตัวอักษร และ Confirm Password ที่ตรงกัน
- อีเมล เบอร์โทร และช่องทาง LINE / Facebook / Instagram

ช่องจำเป็นมีเครื่องหมาย * รูปภาพ คำอธิบาย และ Social ไม่บังคับ
รูปภาพรองรับ PNG/JPG ขนาดไม่เกิน 2 MB ต่อไฟล์ มี preview ทันที
Server ตรวจขนาด นามสกุล และลายเซ็นไฟล์ ไม่อาศัย MIME ที่ browser ส่งมาอย่างเดียว
ชื่อไฟล์จัดเก็บสร้างใหม่ด้วย GUID ที่ wwwroot/uploads/shops
หากฟอร์มไม่ผ่าน validation ให้เลือกไฟล์ใหม่ก่อนส่งอีกครั้ง

เมื่อบันทึก:
- บันทึก ShopProfile พร้อม PasswordHash ด้วย ASP.NET Core PasswordHasher ไม่มี plaintext password
- บันทึกรหัสร้านเป็นตัวพิมพ์ใหญ่ และมี unique index แบบไม่แยกตัวพิมพ์
- ป้องกันหลายร้านด้วย primary key และ CHECK Id = 1 รวมถึงล็อกการส่ง Setup พร้อมกันในแอป
- สร้างข้อมูลตัวอย่าง 3 Orders เมื่อสร้างร้านครั้งแรกและไม่มี Orders เดิม
- เข้าสู่ระบบให้ แล้วแสดง “ตั้งค่าร้านเรียบร้อยแล้ว 🎉” พร้อมปุ่ม “เข้าสู่ Dashboard”

ถ้าร้านยังไม่ถูกสร้าง จะเข้าหน้า Dashboard / Login / ส่งคำขอ / Queue ไม่ได้
เมื่อมีร้านแล้ว GET หรือ POST /Setup จะ redirect ไป Login หรือ Dashboard ตามสถานะผู้ใช้
การเปิดเว็บครั้งต่อไปไม่ต้องตั้งค่าใหม่

## แก้ไขข้อมูลร้านภายหลัง

ใช้เมนู “ตั้งค่าร้าน” หรือ /Admin/Shop หลัง Login
แก้ชื่อเจ้าของ ชื่อร้าน รูปภาพ อีเมล เบอร์โทร Social คำอธิบาย และสถานะรับคิวได้
รหัสร้านเปลี่ยนไม่ได้ ส่วนบัญชีผู้ดูแลเปลี่ยนได้ผ่านฟอร์มบัญชีแยกด้านล่าง
การส่ง ShopCode, AdminUsername หรือ PasswordHash แอบเข้ามาในฟอร์มโปรไฟล์ร้านไม่เปลี่ยนค่าเหล่านี้
ไม่เลือกรูปใหม่จะคงรูปเดิม เปลี่ยนรูปสำเร็จแล้วจึงลบไฟล์รูปเดิม
โลโก้แสดงในหัวเว็บ รูปโปรไฟล์และคำอธิบายแสดงบน Home

## Migration และฐานข้อมูลเวอร์ชันเดิม

ตารางปัจจุบัน:
- CommissionOrder: โครงสร้างงานเดิมทั้งหมด
- ShopProfile: Id, ShopCode, OwnerName, ShopName, AdminUsername, PasswordHash,
  Email, Phone, LineContact, FacebookContact, InstagramContact, Description,
  LogoPath, ProfileImagePath, IsOpen, CreatedDate, UpdatedDate
- WorkTypes: Id, Name, NormalizedName, IsActive
- OrderImages: Id, CommissionOrderId, FileName, ContentType, Content
- __EFMigrationsHistory และตารางล็อก migration ของ EF Core

Migrations:
1. InitialLegacySchema — schema เดิม เพื่อให้สร้างฐานข้อมูลใหม่และรองรับ baseline เดิม
2. AddShopProfileSetup — สร้าง ShopProfile ย้ายร้าน/บัญชีเก่า แล้วแทนที่ตาราง ShopSettings และ AdminUsers
3. AddWorkTypesAndOrderImages — เพิ่มประเภทงานที่แก้ไขได้ และภาพประกอบ Order

สำหรับ commissions.db เดิมที่ใช้ EnsureCreated:
- ตรวจว่า schema ตรงกับเวอร์ชันเดิมก่อนเปลี่ยนแปลง
- สำรองด้วย SQLite Backup API เป็นไฟล์ .pre-setup-วันที่เวลา.db รวมข้อมูลที่ commit ใน WAL
- บันทึก baseline แล้วใช้ migration ตามปกติ โดยคง Orders และ password hash เดิม
- ร้านเดิมได้รับรหัส LEGACY-0001; ชื่อเจ้าของเริ่มจากชื่อร้านและสามารถแก้ไขได้
- อีเมล/เบอร์โทรที่เวอร์ชันเก่าไม่มีจะเว้นว่าง ให้เติมเมื่อแก้ไขตั้งค่าร้านครั้งถัดไป
- ร้านเดิมถือว่าตั้งค่าแล้ว จึงไม่แสดง Setup และยังใช้บัญชีเดิมได้
- Cookie เดิมหมดผลเมื่อเปลี่ยนเวอร์ชันนี้ ให้ Login ใหม่
- หากพบ schema ที่ไม่รู้จัก หรือหลายร้าน/หลายแอดมิน ระบบหยุดแทนการเดาหรือลบข้อมูล

**ไม่ต้องลบฐานข้อมูลเดิมเพื่ออัปเกรด**

ทดลองหน้า Setup ใหม่โดยแยกฐานข้อมูลจากของเดิม:

~~~powershell
$env:DatabasePath = "my-new-shop.db"
dotnet run --project CommissionQueue.csproj --launch-profile http --urls http://localhost:5083
~~~

เปิด http://localhost:5083/Setup
กลับไปใช้ฐานข้อมูลปกติ: หยุดแอป แล้ว Remove-Item Env:DatabasePath จากนั้นรันใหม่

ใช้ EF tooling เมื่อต้องเพิ่ม schema ต่อ:

~~~powershell
dotnet tool restore
dotnet ef migrations add YourMigrationName --project CommissionQueue.csproj --startup-project CommissionQueue.csproj
~~~

AppDbContextFactory ใช้สำหรับ tooling โดยไม่เรียก startup หรือ seed
ให้รันแอปครั้งแรกเพื่ออัปเกรด EnsureCreated database เดิม ก่อนใช้คำสั่ง EF database update กับฐานนั้น

## ฟีเจอร์คิวเดิม

ลูกค้าส่งคำขอ รับเลข COM-0001 เป็นต้นไป ติดตามสถานะและหมายเหตุร้านได้
แอดมินดู/แก้ไข/ลบงาน เปลี่ยนสถานะ 7 แบบ กำหนดราคาและวันคาดว่าจะเสร็จได้
Queue เรียงตาม Id ไม่เปิดเผยข้อมูลส่วนตัว และไม่นับงานเสร็จแล้ว/ยกเลิก
รายได้รวมคือ FinalPrice ของงานเสร็จแล้ว ไม่ใช่ระบบรับชำระเงินจริง
วันที่รับคำขอใช้ CreatedDate และเวลาที่สร้างอัตโนมัติแสดงเป็นเวลาไทย UTC+7
เลขติดตามเรียงลำดับตามโจทย์ ไม่ใช่รหัสลับ

## ตรวจสอบที่ทำแล้ว

- Debug / Release build: 0 errors, 0 warnings
- Setup และตั้งค่าร้าน: 37 integration checks
- ฟีเจอร์คิวเดิมพร้อม Setup: 23 HTTP checks
- Migration ฐานข้อมูลเดิมและ restart: 11 checks
- Browser Wizard: 5 checks (ช่องจำเป็น, next/back, preview, ยืนยันรหัสผ่าน, คงข้อมูลเมื่อย้อนกลับ)
- ตรวจ Setup และหน้า Admin settings ที่ความกว้าง 390px ไม่มี horizontal overflow

สคริปต์ทดสอบใช้ฐานข้อมูลแยกเท่านั้น ห้ามรันกับข้อมูลจริง
เลือกชื่อ DatabasePath ใหม่ทุกครั้งสำหรับชุดที่ต้องเริ่มจากร้านว่าง

~~~powershell
New-Item -ItemType Directory -Force artifacts
$env:DatabasePath = "artifacts/setup-check-new.db"
dotnet run --project CommissionQueue.csproj --launch-profile http --urls http://localhost:5081
~~~

ใน Terminal อีกหน้าหนึ่ง:

~~~powershell
dotnet run --project tests/SetupSmoke/SetupSmoke.csproj -c Release -- http://localhost:5081 artifacts/setup-check-new.db
~~~

ทดสอบคิวด้วยฐานข้อมูลใหม่อีกไฟล์และ port 5082:

~~~powershell
powershell -NoProfile -ExecutionPolicy Bypass -File tests/Smoke.ps1 -BaseUrl http://localhost:5082
~~~

ทดสอบ migration กับสำเนาฐานข้อมูลเวอร์ชันเดิม (ต้นฉบับไม่ถูกแก้):

~~~powershell
dotnet run --project tests/SetupSmoke/SetupSmoke.csproj -c Release -- --legacy commissions.db
~~~

Browser checks ต้องมี Chrome ใน path มาตรฐานของ Windows และ server ที่ port 5081:
- ก่อน Setup: tests/Preview.ps1 -Path /Setup -WizardCheck
- หลัง Setup โดยใช้บัญชีทดสอบ: tests/Preview.ps1 -AdminCheck
- ภาพ preview เก็บใน artifacts/

## โครงสร้างไฟล์

รายการครบทุกไฟล์อยู่ใน FILES.txt
ส่วนหลักที่เพิ่ม:

~~~text
Controllers/SetupController.cs
Controllers/ShopController.cs
Models/ShopProfile.cs
Models/ShopForms.cs
Middleware/SetupRequiredMiddleware.cs
Services/AdminSession.cs
Services/ShopImageAttribute.cs
Services/ShopImageStore.cs
Data/AppDbContextFactory.cs
Migrations/*InitialLegacySchema.cs + Designer.cs
Migrations/*AddShopProfileSetup.cs + Designer.cs
Migrations/AppDbContextModelSnapshot.cs
Views/Setup/Index.cshtml
Views/Setup/Success.cshtml
Views/Shop/Index.cshtml
Views/Shared/_ShopIdentityFields.cshtml
Views/Shared/_ShopContactFields.cshtml
wwwroot/js/shop.js
dotnet-tools.json
tests/SetupSmoke/SetupSmoke.csproj
tests/SetupSmoke/Program.cs
tests/SetupSmoke/LegacyTests.cs
~~~

ZIP ไม่รวมฐานข้อมูล รหัสผ่านจริง รูปที่อัปโหลด bin/ obj/ artifacts/ และไฟล์ Unity ที่ไม่เกี่ยวข้อง
สำรองฐานข้อมูลและ wwwroot/uploads/shops คู่กัน หากย้ายร้านไปเครื่องอื่น

อ้างอิง:
- [EF Core migrations](https://learn.microsoft.com/en-us/ef/core/managing-schemas/migrations/)
- [ASP.NET Core file uploads](https://learn.microsoft.com/en-us/aspnet/core/mvc/models/file-uploads)




## QR ชำระเงินตามออเดอร์และกระปุกทิป

### เจ้าของร้าน
- เปิด Admin > รายการ Order > แก้ไข ใส่ราคาจริง แล้วอัปโหลด QR ชำระเงิน (PNG/JPG ไม่เกิน 2 MB) และชื่อผู้รับเงิน
- เฉพาะเจ้าของที่เข้าสู่ระบบเท่านั้นสามารถแก้ราคาและ QR ได้
- หาก QR ฝังยอดเงินไว้ ให้เปลี่ยน QR เมื่อเปลี่ยนราคา เพื่อให้ยอดตรงกัน
- Dashboard แจ้งรายการที่ลูกค้าแจ้งชำระแล้ว เปิดรายละเอียดเพื่อตรวจยอดในบัญชีธนาคาร แล้วกดยืนยันรับเงินหรือให้ลูกค้าแจ้งใหม่
- เมื่อยืนยัน งานที่อยู่สถานะรอชำระเงินจะเปลี่ยนเป็นรอคิว ส่วนสถานะงานอื่นคงเดิม
- การเปลี่ยนราคา QR หรือชื่อผู้รับ จะล้างการแจ้งชำระและการยืนยันเดิม และป้องกันการส่งแบบฟอร์มชำระเงินเวอร์ชันเก่า

### ลูกค้า
- หลังส่งคำขอ หรือค้นหาเลข Order ในหน้าเช็กสถานะ กด “ดูยอดและชำระเงิน”
- URL: /Payment?orderCode=COM-0001 ระบบแสดงยอดจริงและ QR เมื่อเจ้าของตั้งค่าแล้ว
- สแกนหรือดาวน์โหลด QR เพื่อจ่ายในแอปธนาคาร แล้วกลับมากด “ชำระเงินแล้ว · แจ้งร้านและกลับหน้าหลัก”
- ปุ่มนี้เป็นการแจ้งชำระให้ร้านตรวจสอบ ไม่ใช่การตรวจสอบธุรกรรมธนาคารอัตโนมัติ และไม่มีการเปลี่ยนหน้าจากแอปธนาคารโดยอัตโนมัติ

### กระปุกทิปหน้าแรก
- ตั้งค่าที่ Admin > ตั้งค่าร้าน > กระปุกทิป (/Admin/Shop#tip-settings)
- อัปโหลด QR รับทิปแยกจากออเดอร์ แนะนำ QR ที่ไม่กำหนดยอด เพื่อให้ลูกค้าเลือกจำนวนเอง แล้วเปิดใช้งาน
- หน้าแรกจะแสดงกระปุกทิป กดเพื่อเปิด QR ในหน้าต่าง พร้อมปุ่มดาวน์โหลดและกลับหน้าหลัก
- ยังไม่แสดงกระปุกเมื่อไม่มี QR หรือปิดใช้งาน ไม่มี QR ธนาคารสมมติในระบบ
- ระบบไม่ได้ติดตามยอดทิปอัตโนมัติ และไม่รวมทิปในรายได้ Dashboard

Migration AddOrderPaymentsAndTipJar เพิ่มตาราง OrderPayments และ TipSettings โดยเก็บ QR เป็น BLOB ใน SQLite การสำรองฐานข้อมูลจึงรวม QR ด้วย
รันครั้งแรกจะอัปเกรดอัตโนมัติ มี migration รวม 4 รายการ และคงข้อมูลร้าน บัญชี ออเดอร์ ประเภทงาน และรูปเดิมไว้

ผลตรวจฟีเจอร์นี้: Release build 0 warnings / 0 errors, payment/tip integration 43 checks, regression 23 checks, อัปเกรดสำเนาฐานข้อมูล 8 checks และ browser interaction 7 checks พร้อมตรวจหน้า Payment ที่หน้าจอ 390px ไม่มีแนวนอนล้น

ใช้ฐานข้อมูลทดสอบใหม่และ server แยกที่ port 5081 (ห้ามใช้ข้อมูลจริง):

~~~powershell
$env:DatabasePath = "artifacts/payment-check-new.db"
dotnet run --project CommissionQueue.csproj -c Release --launch-profile http --urls http://localhost:5081
~~~

จากอีก Terminal:

~~~powershell
dotnet run --project tests/SetupSmoke/SetupSmoke.csproj -c Release -- --payments http://localhost:5081 artifacts/payment-check-new.db
~~~

ไฟล์ทดสอบใช้รูปจำลองเท่านั้น ไม่ได้สร้างการโอนเงินจริง รายการไฟล์ทั้งหมดอยู่ใน FILES.txt

## คุยงานและส่งไฟล์ในออเดอร์

- หน้าแก้ไข Order บันทึกได้โดยไม่ต้องแนบรูป ช่องภาพประกอบเดิมอยู่ในส่วนพับเก็บ และแก้ client validation ที่เคยตีความว่ารูปเป็นช่องจำเป็นแล้ว
- เจ้าของ: Admin > ดูรายละเอียดออเดอร์ > เลื่อนล่างสุด > คุยงาน
- ลูกค้า: หน้าส่งคำขอสำเร็จ หรือเช็กสถานะด้วยเลข Order > คุยงาน / รับไฟล์งาน
- ลูกค้ายืนยันช่องทางติดต่อให้ตรงกับที่กรอกตอนส่งคำขอ ก่อนอ่านหรือส่งข้อความและดาวน์โหลดไฟล์ เป็นการเทียบข้อมูลเดิม ไม่ได้ส่ง OTP
- สิทธิ์ลูกค้าจำเฉพาะออเดอร์นั้นด้วย cookie ที่เข้ารหัสและลงลายเซ็น อายุ 7 วัน เมื่อแก้ช่องทางติดต่อ สิทธิ์เดิมจะใช้ไม่ได้
- ห้องคุย URL /Chat?orderCode=COM-0001; เจ้าของที่เข้าสู่ระบบเปิดได้ทันที
- ส่งข้อความอย่างเดียว รูปอย่างเดียว ไฟล์อย่างเดียว หรือข้อความพร้อมไฟล์ได้ ข้อความไม่เกิน 4,000 ตัวอักษร
- แนบครั้งละ 1 ไฟล์ สูงสุด 20 MB รองรับ PNG, JPG, GIF, WebP, PDF, ZIP และ MP4; ไฟล์ต้นฉบับ PSD/AI รวม ZIP ก่อนส่ง
- รูปแสดงในบทสนทนา คลิกเปิดภาพหรือดาวน์โหลดต้นฉบับได้ ไฟล์อื่นส่งเป็นไฟล์ดาวน์โหลด
- มี preview รูปก่อนส่งและอัปเดตข้อความทุก 5 วินาที โดยไม่ล้างข้อความที่กำลังพิมพ์ แสดงครั้งละ 100 ข้อความ พร้อมลิงก์ดูข้อความเก่า
- เจ้าของและลูกค้าเห็นบทสนทนาเดียวกัน ป้ายผู้ส่งถูกกำหนดจากสิทธิ์ฝั่งเซิร์ฟเวอร์ ลูกค้าไม่สามารถปลอมป้ายเจ้าของได้
- Migration AddOrderChat เพิ่มตาราง OrderMessages รวมข้อความและไฟล์ BLOB ใน SQLite (migration รวม 5 รายการ) รันแล้วอัปเกรดอัตโนมัติ ไม่เปลี่ยนข้อมูลออเดอร์เดิม
- สำรอง commissions.db เพื่อเก็บประวัติแชตและไฟล์ด้วย การลบ Order จะลบข้อความและไฟล์ในออเดอร์นั้นด้วย

ตรวจสอบเวอร์ชันนี้: Release build 0 warnings / 0 errors, integration แชต 29 checks, อัปเกรดสำเนาฐานข้อมูลเดิม 8 checks, browser 6 checks รวมยืนยันว่าฟอร์มไม่บังคับรูปและข้อความอัปเดตอัตโนมัติ พร้อมตรวจหน้าจอ 390px ไม่มีแนวนอนล้น

รันทดสอบด้วยฐานข้อมูลใหม่แยกจากข้อมูลจริง:

~~~powershell
$env:DatabasePath = "artifacts/chat-check-new.db"
dotnet run --project CommissionQueue.csproj -c Release --launch-profile http --urls http://localhost:5081
~~~

อีก Terminal:

~~~powershell
dotnet run --project tests/SetupSmoke/SetupSmoke.csproj -c Release -- --chat http://localhost:5081 artifacts/chat-check-new.db
powershell -File tests/Preview.ps1 -AdminCheck -Path '/Chat?orderCode=COM-0004' -ChatCheck -Output chat-mobile
powershell -File tests/Preview.ps1 -AdminCheck -Path /Admin/Edit/4 -OptionalImageCheck -Output edit-optional-mobile
~~~

### ชื่อและฝั่งของผู้ส่งในแชต
- แชตแสดงชื่อลูกค้าจากออเดอร์และชื่อร้าน โดยมี (คุณ) กำกับข้อความของตนเอง
- ข้อความตนเองอยู่ขวา อีกฝ่ายอยู่ซ้าย ทั้งมุมมองลูกค้าและเจ้าของ
- ทางเข้าจากเช็กสถานะ/ส่งคำขอสำเร็จใช้ view=customer และต้องยืนยันช่องทางติดต่อ แม้เบราว์เซอร์นั้นล็อกอิน Admin อยู่
- ทางเข้าจากรายละเอียดใน Admin ใช้มุมมองเจ้าของตามเดิม ฝั่งผู้ส่งถูกกำหนดบนเซิร์ฟเวอร์และลูกค้ายังไม่สามารถปลอมเป็นเจ้าของร้านได้
- ตรวจ Release build ผ่าน และชุดทดสอบแชตเพิ่มกรณีเปลี่ยนมุมมองในเบราว์เซอร์เดียวกัน

## แกลเลอรีผลงานและเรทราคา

- หน้าแรกมีปุ่ม “ดูผลงานและเรทราคา” เปิด /Portfolio สำหรับลูกค้าทุกคน
- ด้านบนเป็นข้อความเรทราคาและเงื่อนไข ด้านล่างเป็นแกลเลอรีผลงาน มีปุ่มส่งคำขอคอมมิชชั่น
- เจ้าของเข้าสู่ระบบ แล้วกด “จัดการผลงาน” ในเมนู หรือปุ่มจัดการในหน้าแกลเลอรี (/Portfolio/Manage)
- มีเทมเพลตข้อความ หัว / ครึ่งตัว / เต็มตัว ให้เติมราคา เพิ่มประเภทและเงื่อนไขได้ ไม่กำหนดราคาจริงแทนเจ้าของ และไม่แสดงเทมเพลตที่ยังไม่ได้บันทึกให้ลูกค้า
- เพิ่มชื่อผลงาน รายละเอียด และรูปหรือวิดีโอ ครั้งละ 1 ไฟล์ สูงสุด 50 MB มีตัวอย่างก่อนส่ง และปุ่มลบผลงาน
- รองรับ PNG/JPG/GIF/WebP และ MP4/WebM วิดีโอใช้ปุ่มเล่นในหน้า ไม่เล่นอัตโนมัติ รองรับ byte ranges สำหรับการเลื่อนตำแหน่งวิดีโอ
- แนะนำ MP4 ที่เข้ารหัส H.264 หรือ WebM ที่เบราว์เซอร์รองรับ ระบบเก็บไฟล์เดิม ไม่แปลง codec
- ผลงานเป็นสาธารณะทันทีที่เพิ่ม เจ้าของเท่านั้นแก้เรทราคา เพิ่มหรือลบผลงานได้
- Migration AddPortfolio เพิ่ม PortfolioSettings และ PortfolioItems รวมเป็น 6 migrations โดยอัปเกรดอัตโนมัติ เก็บสื่อเป็น BLOB ใน SQLite จึงสำรองไปกับฐานข้อมูล
- ตรวจ Release build 0 warnings / 0 errors, integration 20 checks, browser 5 checks รวมเล่นวิดีโอ WebM จริง และหน้า 390px ไม่มีแนวนอนล้น
- ทดสอบบนฐานข้อมูลทดสอบที่ตั้งค่าร้านแล้ว ด้วยบัญชีทดสอบ admin / Mellow@12345 เท่านั้น: dotnet run --project tests/SetupSmoke/SetupSmoke.csproj -c Release -- --portfolio http://localhost:5081
