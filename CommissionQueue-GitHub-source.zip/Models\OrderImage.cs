﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Models;

// Stored in SQLite, outside the public static-file directory.
public class OrderImage {
    public int Id { get; set; }
    public int CommissionOrderId { get; set; }
    public CommissionOrder CommissionOrder { get; set; } = null!;
    [MaxLength(200)] public string FileName { get; set; } = "";
    [MaxLength(30)] public string ContentType { get; set; } = "";
    public byte[] Content { get; set; } = [];
}
public record OrderImageInfo(int Id, string FileName);

