﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Controllers;

[ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
public class ChatController(AppDbContext db,IDataProtectionProvider protection):Controller {
 private bool IsOwner=>User.Identity?.IsAuthenticated==true && Request.Query["view"]!="customer";
 private bool CanRead(CommissionOrder order) {
  if(IsOwner) return true;
  try {
   var value=Request.Cookies[$".CommissionQueue.Chat.{order.Id}"];
   return value is not null && protection.CreateProtector("OrderChat",order.Id.ToString(),order.Contact).ToTimeLimitedDataProtector().Unprotect(value)=="customer";
  } catch(System.Security.Cryptography.CryptographicException) {return false;}
 }
 private Task<CommissionOrder?> Find(string? orderCode)=>db.CommissionOrders.AsNoTracking().SingleOrDefaultAsync(o=>o.OrderCode==(orderCode??"").Trim().ToUpper());
 private async Task<ChatPage> Page(CommissionOrder order,int? before=null) {
  var messages=await db.OrderMessages.AsNoTracking().Where(m=>m.CommissionOrderId==order.Id && (!before.HasValue || m.Id<before.Value))
   .OrderByDescending(m=>m.Id).Take(100).Select(m=>new ChatMessageInfo(m.Id,m.FromAdmin,m.Text,m.CreatedDate,m.FileName,m.ContentType)).ToListAsync();
  messages.Reverse(); var shopName=await db.ShopProfiles.Select(s=>s.ShopName).SingleAsync(); return new(order.OrderCode,IsOwner,messages,order.CustomerName,shopName,before);
 }
 [HttpGet] public async Task<IActionResult> Index(string? orderCode,int? before) {
  var order=await Find(orderCode); if(order is null) return NotFound();
  if(!CanRead(order)) {ViewBag.OrderCode=order.OrderCode; return View("Access");}
  return View(await Page(order,before));
 }
 [HttpPost,EnableRateLimiting("forms")] public async Task<IActionResult> Access(string? orderCode,string? contact) {
  var order=await Find(orderCode);
  if(order is null || string.IsNullOrWhiteSpace(contact) || !string.Equals(order.Contact.Trim(),contact.Trim(),StringComparison.OrdinalIgnoreCase)) {
   ModelState.AddModelError("","เลขออเดอร์หรือช่องทางติดต่อไม่ตรงกับคำขอ กรุณาตรวจสอบอีกครั้ง");
   ViewBag.OrderCode=orderCode; return View("Access");
  }
  var ticket=protection.CreateProtector("OrderChat",order.Id.ToString(),order.Contact).ToTimeLimitedDataProtector().Protect("customer",TimeSpan.FromDays(7));
  Response.Cookies.Append($".CommissionQueue.Chat.{order.Id}",ticket,new CookieOptions {HttpOnly=true,Secure=Request.IsHttps,SameSite=SameSiteMode.Lax,MaxAge=TimeSpan.FromDays(7),IsEssential=true});
  return RedirectToAction(nameof(Index),new {orderCode=order.OrderCode,view="customer"});
 }
 [HttpGet] public async Task<IActionResult> Messages(string? orderCode,int? before) {
  var order=await Find(orderCode); if(order is null) return NotFound(); if(!CanRead(order)) return StatusCode(403);
  return PartialView("_Messages",await Page(order,before));
 }
 [HttpPost,EnableRateLimiting("forms"),RequestSizeLimit(22*1024*1024),RequestFormLimits(MultipartBodyLengthLimit=22*1024*1024)]
 public async Task<IActionResult> Send(string? orderCode,ChatForm form) {
  var order=await Find(orderCode); if(order is null) return NotFound(); if(!CanRead(order)) return StatusCode(403);
  if(string.IsNullOrWhiteSpace(form.Text) && form.Attachment is null) ModelState.AddModelError("","กรุณาพิมพ์ข้อความหรือเลือกไฟล์ก่อนส่ง");
  byte[]? bytes=null; string? mime=null; string? name=null;
  if(form.Attachment is {} file) {
   if(file.Length==0 || file.Length>20*1024*1024) ModelState.AddModelError("","ไฟล์ต้องมีข้อมูลและขนาดไม่เกิน 20 MB");
   else {
    using var stream=new MemoryStream(); await file.CopyToAsync(stream,Request.HttpContext.RequestAborted); bytes=stream.ToArray();
    name=Path.GetFileName(file.FileName.Replace('\\','/')); if(name.Length>180) name=name[^180..];
    mime=FileType(Path.GetExtension(name).ToLowerInvariant(),bytes);
    if(mime is null) ModelState.AddModelError("","รองรับ PNG, JPG, GIF, WebP, PDF, ZIP และ MP4 ที่มีชนิดไฟล์ถูกต้องเท่านั้น");
   }
  }
  if(!ModelState.IsValid) {ViewBag.Draft=form.Text; return View("Index",await Page(order));}
  db.OrderMessages.Add(new OrderMessage {CommissionOrderId=order.Id,FromAdmin=IsOwner,Text=form.Text?.Trim(),FileName=name,ContentType=mime,FileContent=bytes});
  await db.SaveChangesAsync(); return RedirectToAction(nameof(Index),new {orderCode=order.OrderCode,view=IsOwner ? null : "customer"});
 }
 [HttpGet] public async Task<IActionResult> Attachment(int id,bool download=false) {
  var info=await db.OrderMessages.AsNoTracking().Where(m=>m.Id==id).Select(m=>new {m.CommissionOrderId,m.FileName}).SingleOrDefaultAsync();
  if(info?.FileName is null) return NotFound();
  var order=await db.CommissionOrders.AsNoTracking().SingleAsync(o=>o.Id==info.CommissionOrderId); if(!CanRead(order)) return StatusCode(403);
  var message=await db.OrderMessages.AsNoTracking().SingleAsync(m=>m.Id==id);
  if(message.FileContent is null) return NotFound();
  return !download && message.ContentType?.StartsWith("image/")==true ? File(message.FileContent,message.ContentType) : File(message.FileContent,message.ContentType??"application/octet-stream",message.FileName);
 }
 private static string? FileType(string ext,byte[] b) {
  bool Starts(params byte[] prefix)=>b.AsSpan().StartsWith(prefix);
  return ext switch {
   ".png" when Starts(137,80,78,71,13,10,26,10)=>"image/png",
   ".jpg" or ".jpeg" when Starts(255,216,255)=>"image/jpeg",
   ".gif" when Starts(71,73,70,56,55,97)||Starts(71,73,70,56,57,97)=>"image/gif",
   ".webp" when b.Length>=12 && Starts(82,73,70,70) && b.AsSpan(8,4).SequenceEqual("WEBP"u8)=>"image/webp",
   ".pdf" when Starts(37,80,68,70,45)=>"application/pdf",
   ".zip" when Starts(80,75,3,4)||Starts(80,75,5,6)=>"application/zip",
   ".mp4" when b.Length>=12 && b.AsSpan(4,4).SequenceEqual("ftyp"u8)=>"video/mp4",
   _=>null
  };
 }
}

