﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
namespace CommissionQueue.Data;

// EF tooling must not run HTTP startup or seed/upgrade a live database.
public class AppDbContextFactory : IDesignTimeDbContextFactory<AppDbContext> {
    public AppDbContext CreateDbContext(string[] args) {
        var path=Environment.GetEnvironmentVariable("DatabasePath") ?? "commissions.db";
        return new AppDbContext(new DbContextOptionsBuilder<AppDbContext>().UseSqlite($"Data Source={path}").Options);
    }
}

