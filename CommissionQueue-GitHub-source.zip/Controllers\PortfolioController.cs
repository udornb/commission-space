﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Controllers;
public class PortfolioController(AppDbContext db):Controller {
 private const string Template="หัว / Headshot: ___ บาท\nครึ่งตัว / Half body: ___ บาท\nเต็มตัว / Full body: ___ บาท\n\nรายละเอียดเพิ่มเติม / เงื่อนไขงาน:\n___";
 private async Task<PortfolioPage> Page(bool edit=false)=>new(await db.PortfolioSettings.Select(p=>p.Rates).SingleOrDefaultAsync() ?? (edit?Template:""),await db.PortfolioItems.AsNoTracking().OrderByDescending(p=>p.Id).Select(p=>new PortfolioCard(p.Id,p.Title,p.Description,p.ContentType)).ToListAsync());
 public async Task<IActionResult> Index()=>View(await Page());
 [Authorize,HttpGet] public async Task<IActionResult> Manage()=>View(await Page(true));
 [Authorize,HttpPost] public async Task<IActionResult> Rates(string? rates) {
  if(string.IsNullOrWhiteSpace(rates)||rates.Length>6000) {ModelState.AddModelError("","กรุณากรอกเรทราคาไม่เกิน 6,000 ตัวอักษร");ViewBag.RatesDraft=rates;return View("Manage",await Page(true));}
  var setting=await db.PortfolioSettings.SingleOrDefaultAsync();if(setting is null){setting=new();db.PortfolioSettings.Add(setting);}setting.Rates=rates.Trim();await db.SaveChangesAsync();TempData["Message"]="บันทึกเรทราคาแล้ว";return RedirectToAction(nameof(Manage));
 }
 [Authorize,HttpPost,RequestSizeLimit(52*1024*1024),RequestFormLimits(MultipartBodyLengthLimit=52*1024*1024)]
 public async Task<IActionResult> Upload(PortfolioUpload form) {
  byte[] bytes=[];string? mime=null;
  if(form.Media is {} file) {
   if(file.Length==0||file.Length>50*1024*1024) ModelState.AddModelError("","ไฟล์ต้องมีข้อมูลและไม่เกิน 50 MB");
   else {
    using var stream=new MemoryStream();await file.CopyToAsync(stream,Request.HttpContext.RequestAborted);bytes=stream.ToArray();
    var ext=Path.GetExtension(file.FileName).ToLowerInvariant();
    mime=ext switch {
     ".png" when bytes.AsSpan().StartsWith(new byte[]{137,80,78,71,13,10,26,10})=>"image/png",
     ".jpg" or ".jpeg" when bytes.AsSpan().StartsWith(new byte[]{255,216,255})=>"image/jpeg",
     ".gif" when bytes.AsSpan().StartsWith("GIF87a"u8)||bytes.AsSpan().StartsWith("GIF89a"u8)=>"image/gif",
     ".webp" when bytes.Length>12 && bytes.AsSpan(0,4).SequenceEqual("RIFF"u8) && bytes.AsSpan(8,4).SequenceEqual("WEBP"u8)=>"image/webp",
     ".mp4" when bytes.Length>12 && bytes.AsSpan(4,4).SequenceEqual("ftyp"u8)=>"video/mp4",
     ".webm" when bytes.AsSpan().StartsWith(new byte[]{26,69,223,163})=>"video/webm",
     _=>null
    };
    if(mime is null)ModelState.AddModelError("","รองรับภาพ PNG/JPG/GIF/WebP หรือวิดีโอ MP4/WebM ที่มีชนิดไฟล์ตรงกันเท่านั้น");
   }
  }
  if(!ModelState.IsValid){ViewBag.Upload=form;return View("Manage",await Page(true));}
  db.PortfolioItems.Add(new(){Title=form.Title.Trim(),Description=form.Description?.Trim(),Content=bytes,ContentType=mime!});await db.SaveChangesAsync();TempData["Message"]="เพิ่มผลงานแล้ว";return RedirectToAction(nameof(Manage));
 }
 [Authorize,HttpPost] public async Task<IActionResult> Delete(int id) {
  var item=await db.PortfolioItems.FindAsync(id);if(item is null)return NotFound();db.PortfolioItems.Remove(item);await db.SaveChangesAsync();TempData["Message"]="ลบผลงานแล้ว";return RedirectToAction(nameof(Manage));
 }
 [HttpGet] public async Task<IActionResult> Media(int id) {
  var item=await db.PortfolioItems.AsNoTracking().SingleOrDefaultAsync(p=>p.Id==id);if(item is null)return NotFound();return File(item.Content,item.ContentType,enableRangeProcessing:true);
 }
}
