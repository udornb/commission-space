﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Services;

public class PaymentService(AppDbContext db) {
    public void Validate(EditForm form,OrderPayment? current,ModelStateDictionary state) {
        if(form.PaymentQr is not null && !(form.FinalPrice>0))
            state.AddModelError(nameof(form.PaymentQr),"กรุณาตั้งราคาจริงมากกว่า 0 บาทก่อนเพิ่ม QR ชำระเงิน");
        if(form.PaymentQr is not null && form.RemovePaymentQr)
            state.AddModelError(nameof(form.PaymentQr),"กรุณาเลือกอัปโหลด QR ใหม่หรือลบ QR เดิมอย่างใดอย่างหนึ่ง");
        if((current?.Revision ?? "")!=(form.PaymentRevision ?? ""))
            state.AddModelError("","ข้อมูลชำระเงินเปลี่ยนไปแล้ว กรุณาเปิดหน้าแก้ไขใหม่");
    }
    public async Task ApplyAsync(CommissionOrder order,OrderPayment? payment,EditForm form,decimal? oldPrice,CancellationToken token) {
        if(form.RemovePaymentQr) {
            if(payment is not null) db.OrderPayments.Remove(payment);
            return;
        }
        if(payment is null && form.PaymentQr is null) return;
        bool changed=oldPrice!=form.FinalPrice || form.PaymentQr is not null || payment?.RecipientName!=form.PaymentRecipientName?.Trim();
        if(payment is null) {
            payment=new OrderPayment { CommissionOrder=order };
            db.OrderPayments.Add(payment);
        }
        payment.RecipientName=form.PaymentRecipientName?.Trim();
        if(form.PaymentQr is not null) {
            (payment.QrImage,payment.ContentType)=await ReadQrAsync(form.PaymentQr,token);
        }
        if(changed) {
            payment.ReportedAt=null; payment.ConfirmedAt=null;
            payment.Revision=Guid.NewGuid().ToString("N");
        }
    }
    public static async Task<(byte[] Content,string ContentType)> ReadQrAsync(IFormFile file,CancellationToken token) {
        await using var stream=new MemoryStream();
        await file.CopyToAsync(stream,token);
        return (stream.ToArray(),Path.GetExtension(file.FileName).Equals(".png",StringComparison.OrdinalIgnoreCase) ? "image/png" : "image/jpeg");
    }
}


