﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Services;

public class OrderFormService(AppDbContext db) {
    public async Task PrepareAsync(RequestForm form, string? originalWorkType=null, int? orderId=null) {
        var types=await db.WorkTypes.AsNoTracking().Where(t=>t.IsActive).OrderBy(t=>t.Id).ToListAsync();
        form.AvailableWorkTypes=types.Select(t=>new SelectListItem(t.Name,t.Name)).ToList();
        if(originalWorkType is not null && !types.Any(t=>t.Name==originalWorkType))
            form.AvailableWorkTypes.Add(new SelectListItem(originalWorkType+" (ประเภทเดิม)",originalWorkType));
        form.ExistingImages=orderId is int id
            ? await db.OrderImages.Where(i=>i.CommissionOrderId==id).OrderBy(i=>i.Id).Select(i=>new OrderImageInfo(i.Id,i.FileName)).ToListAsync()
            : [];
    }
    public void Validate(RequestForm form,ModelStateDictionary state,string? originalWorkType=null) {
        if(!form.AvailableWorkTypes.Any(t=>t.Value==form.WorkType) && form.WorkType!=originalWorkType)
            state.AddModelError(nameof(form.WorkType),"กรุณาเลือกประเภทงานที่ร้านเปิดรับ");
        var removed=form is EditForm edit ? edit.RemoveImageIds.Distinct().ToList() : [];
        if(removed.Any(id=>!form.ExistingImages.Any(i=>i.Id==id)))
            state.AddModelError("","ไม่พบรูปที่ต้องการลบในออเดอร์นี้");
        if(form.ExistingImages.Count-removed.Count+form.Images.Count>OrderImagesAttribute.MaxCount)
            state.AddModelError(nameof(form.Images),"แนบรูปได้รวมไม่เกิน 5 รูป กรุณาลบรูปเดิมบางรูปก่อนเพิ่ม");
    }
    public async Task AddImagesAsync(CommissionOrder order,List<IFormFile> files,CancellationToken token) {
        foreach(var file in files) {
            await using var buffer=new MemoryStream();
            await file.CopyToAsync(buffer,token);
            var name=Path.GetFileName(file.FileName.Replace('\\','/'));
            db.OrderImages.Add(new OrderImage {
                CommissionOrder=order, FileName=name.Length>200 ? name[..200] : name,
                ContentType=Path.GetExtension(name).Equals(".png",StringComparison.OrdinalIgnoreCase) ? "image/png" : "image/jpeg",
                Content=buffer.ToArray()
            });
        }
    }
}

