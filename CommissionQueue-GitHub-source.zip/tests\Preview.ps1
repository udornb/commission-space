﻿param([int]$Width=390,[int]$Height=844,[string]$Output="mobile", [string]$Path="/", [switch]$WizardCheck, [switch]$AdminCheck, [switch]$ImageCheck, [switch]$TipCheck, [switch]$PaymentEditorCheck, [switch]$ChatCheck, [switch]$OptionalImageCheck, [switch]$PortfolioCheck)
$ErrorActionPreference="Stop"
$profile=Join-Path (Resolve-Path artifacts) "chrome-cdp"
$proc=Start-Process -FilePath 'C:\Program Files\Google\Chrome\Application\chrome.exe' -ArgumentList @('--headless=new','--disable-gpu','--no-first-run',"--user-data-dir=$profile",'--remote-debugging-port=9223','about:blank') -WindowStyle Hidden -PassThru
try {
 $tabs=$null
 for($i=0;$i -lt 30;$i++) {try {$tabs=Invoke-RestMethod http://localhost:9223/json;break} catch {Start-Sleep -Milliseconds 200}}
 $tab=$tabs | Where-Object type -eq 'page' | Select-Object -First 1
 $ws=New-Object System.Net.WebSockets.ClientWebSocket
 $ct=[Threading.CancellationToken]::None
 $ws.ConnectAsync([Uri]$tab.webSocketDebuggerUrl,$ct).GetAwaiter().GetResult()
 $script:msgId=0
 function Cdp($method,$parameters) {
  $script:msgId++
  $json=@{id=$script:msgId;method=$method;params=$parameters}|ConvertTo-Json -Depth 20 -Compress
  $bytes=[Text.Encoding]::UTF8.GetBytes($json)
  $segment=[ArraySegment[byte]]::new($bytes)
  $ws.SendAsync($segment,[Net.WebSockets.WebSocketMessageType]::Text,$true,$ct).GetAwaiter().GetResult()
  do {
   $stream=New-Object IO.MemoryStream
   do {
    $buffer=New-Object byte[] 65536
    $received=$ws.ReceiveAsync([ArraySegment[byte]]::new($buffer),$ct).GetAwaiter().GetResult()
    $stream.Write($buffer,0,$received.Count)
   } while(!$received.EndOfMessage)
   $reply=[Text.Encoding]::UTF8.GetString($stream.ToArray())|ConvertFrom-Json
   $stream.Dispose()
  } while($reply.id -ne $script:msgId)
  if($reply.error){throw ($reply.error|ConvertTo-Json)}
  return $reply.result
 }
 Cdp 'Emulation.setDeviceMetricsOverride' @{width=$Width;height=$Height;deviceScaleFactor=1;mobile=$true} | Out-Null
 Cdp 'Page.navigate' @{url="http://localhost:5081$Path"} | Out-Null
 Start-Sleep -Milliseconds 800
 if($AdminCheck) {
  Cdp 'Page.navigate' @{url='http://localhost:5081/Admin/Login'} | Out-Null
  Start-Sleep -Milliseconds 500
  $login=Cdp 'Runtime.evaluate' @{expression="fetch('/Admin/Login',{method:'POST',body:new URLSearchParams({Username:'admin',Password:'Mellow@12345',__RequestVerificationToken:document.querySelector('input[name=__RequestVerificationToken]').value})}).then(r=>r.url)";awaitPromise=$true;returnByValue=$true}
  if($login.result.value -notmatch '/Admin$'){throw 'Browser login failed'}
  Cdp 'Page.navigate' @{url=if($Path -eq '/'){ 'http://localhost:5081/Admin/Shop' } else { "http://localhost:5081$Path" }} | Out-Null
  Start-Sleep -Milliseconds 500
 }
 if($ImageCheck) {
  $expression=@"
(() => {
 const checks={};
 const input=document.querySelector('[data-order-images]');
 const canvas=document.createElement('canvas');canvas.width=180;canvas.height=140;
 const ctx=canvas.getContext('2d');ctx.fillStyle='#efe9fa';ctx.fillRect(0,0,180,140);ctx.fillStyle='#a991ca';ctx.beginPath();ctx.arc(90,68,42,0,Math.PI*2);ctx.fill();ctx.fillStyle='white';ctx.font='36px sans-serif';ctx.fillText('♡',73,81);
 const data=canvas.toDataURL('image/png').split(',')[1];
 const png=Uint8Array.from(atob(data),c=>c.charCodeAt(0));
 const transfer=new DataTransfer();
 transfer.items.add(new File([png],'reference-1.png',{type:'image/png'}));
 transfer.items.add(new File([png],'reference-2.png',{type:'image/png'}));
 input.files=transfer.files;input.dispatchEvent(new Event('change'));
 checks.multiplePreviews=document.querySelectorAll('.image-selection-preview img').length===2 && input.files.length===2;
 document.querySelector('.image-selection-preview button').click();
 checks.removePreview=document.querySelectorAll('.image-selection-preview img').length===1 && input.files.length===1;
 const invalid=new DataTransfer();invalid.items.add(new File(['<svg/>'],'unsafe.svg',{type:'image/svg+xml'}));
 input.files=invalid.files;input.dispatchEvent(new Event('change'));
 checks.invalidFileRejected=input.files.length===1 && document.querySelector('.image-selection-message').textContent.includes('PNG');
 checks.categoryOptions=[...document.querySelector('#WorkType').options].some(o=>o.text==='อนิเมชั่น');
 return JSON.stringify(checks);
})()
"@
  $result=Cdp 'Runtime.evaluate' @{expression=$expression;returnByValue=$true}
  if($result.exceptionDetails){Write-Output ($result | ConvertTo-Json -Depth 12)}
  Write-Output $result.result.value
  $checks=$result.result.value|ConvertFrom-Json
  if(!$checks -or @($checks.PSObject.Properties | Where-Object {$_.Value -ne $true}).Count -gt 0){throw 'Image browser check failed'}
 }
 if($TipCheck) {
  $result=Cdp 'Runtime.evaluate' @{expression="(() => {const d=document.querySelector('#tip-dialog');document.querySelector('[data-open-tip]').click();const opened=d.open;const hasQr=!!d.querySelector('img[src]');d.querySelector('[data-close-tip]').click();const closed=!d.open;document.querySelector('[data-open-tip]').click();return JSON.stringify({opened,hasQr,closed,focusInside:d.contains(document.activeElement)});})()";returnByValue=$true}
  if($result.exceptionDetails){Write-Output ($result | ConvertTo-Json -Depth 12)}
  Write-Output $result.result.value
  $checks=$result.result.value|ConvertFrom-Json
  if(!$checks -or @($checks.PSObject.Properties | Where-Object {$_.Value -ne $true}).Count -gt 0){throw 'Tip modal browser check failed'}
 }
 if($PaymentEditorCheck) {
  $expression=@"
(() => {
const panel=document.querySelector('[data-payment-editor]');
const price=document.querySelector('#FinalPrice');
const hiddenInitially=panel.hidden;
price.value='1250';price.dispatchEvent(new Event('input'));
const visibleAfterPrice=!panel.hidden;
const file=new File([Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII='),c=>c.charCodeAt(0))],'test-qr.png',{type:'image/png'});
const data=new DataTransfer();data.items.add(file);const input=document.querySelector('#PaymentQr');input.files=data.files;input.dispatchEvent(new Event('change'));
const previewVisible=!document.querySelector('#order-qr-preview').hidden;
panel.scrollIntoView();
return JSON.stringify({hiddenInitially,visibleAfterPrice,previewVisible});
})()
"@
  $result=Cdp 'Runtime.evaluate' @{expression=$expression;returnByValue=$true}
  if($result.exceptionDetails){Write-Output ($result | ConvertTo-Json -Depth 12)}
  Write-Output $result.result.value
  $checks=$result.result.value|ConvertFrom-Json
  if(!$checks -or @($checks.PSObject.Properties | Where-Object {$_.Value -ne $true}).Count -gt 0){throw 'Payment editor browser check failed'}
 }
 if($WizardCheck) {
  $expression=@"
(() => {
const checks={};
document.querySelector('.wizard-next').click();
checks.emptyStepBlocked=!document.querySelector('[data-wizard-step="1"]').hidden;
document.querySelector('#ShopCode').value='mellow-test';
document.querySelector('#OwnerName').value='Test Owner';
document.querySelector('#ShopName').value='Mellow Studio';
const data=new DataTransfer();
data.items.add(new File([Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII='),c=>c.charCodeAt(0))],'logo.png',{type:'image/png'}));
const logo=document.querySelector('#Logo');logo.files=data.files;logo.dispatchEvent(new Event('change'));
checks.previewImmediate=!document.querySelector('#logo-preview').hidden && document.querySelector('#logo-preview').src.startsWith('blob:');
document.querySelector('.wizard-next').click();
checks.secondStepVisible=!document.querySelector('[data-wizard-step="2"]').hidden;
document.querySelector('#Password').value='Password123';
document.querySelector('#ConfirmPassword').value='different';
checks.passwordMismatchBlocked=!window.jQuery('#ConfirmPassword').valid();
document.querySelector('.wizard-back').click();
checks.backRetainsData=document.querySelector('#ShopCode').value==='mellow-test' && logo.files.length===1;
document.querySelector('.wizard-next').click();
return JSON.stringify(checks);
})()
"@
  $result=Cdp 'Runtime.evaluate' @{expression=$expression;returnByValue=$true}
  if($result.exceptionDetails){Write-Output ($result | ConvertTo-Json -Depth 12)}
  Write-Output $result.result.value
  $checks=$result.result.value|ConvertFrom-Json
  if(!$checks -or @($checks.PSObject.Properties | Where-Object {$_.Value -ne $true}).Count -gt 0){throw 'Wizard browser check failed'}
 }
 if($OptionalImageCheck) {
  $result=Cdp 'Runtime.evaluate' @{expression='JSON.stringify({imageOptional:!jQuery("#Images").rules().required,formValidWithoutImage:jQuery("form").first().valid()})';returnByValue=$true}
  if($result.exceptionDetails){Write-Output ($result | ConvertTo-Json -Depth 12)}
  Write-Output $result.result.value
  $checks=$result.result.value|ConvertFrom-Json
  if(!$checks -or @($checks.PSObject.Properties | Where-Object {$_.Value -ne $true}).Count -gt 0){throw 'Optional image check failed'}
 }
 if($ChatCheck) {
  $expression=@"
(async () => {
 const checks={};
 const input=document.querySelector('#Attachment'), draft=document.querySelector('#Text');
 draft.value='Draft stays while messages refresh';
 const data=new DataTransfer();data.items.add(new File([Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII='),c=>c.charCodeAt(0))],'preview.png',{type:'image/png'}));
 input.files=data.files;input.dispatchEvent(new Event('change'));
 checks.previewVisible=!document.querySelector('#chat-preview').hidden;
 const marker='Browser chat '+Date.now();
 const response=await fetch(document.querySelector('.chat-compose').action,{method:'POST',body:new URLSearchParams({Text:marker,__RequestVerificationToken:document.querySelector('.chat-compose input[name=__RequestVerificationToken]').value})});
 checks.sent=response.ok;
 await new Promise(resolve=>setTimeout(resolve,6000));
 checks.autoRefresh=document.querySelector('#chat-messages').textContent.includes(marker);
 checks.draftPreserved=draft.value==='Draft stays while messages refresh' && input.files.length===1;
 return JSON.stringify(checks);
})()
"@
  $result=Cdp 'Runtime.evaluate' @{expression=$expression;awaitPromise=$true;returnByValue=$true}
  if($result.exceptionDetails){Write-Output ($result | ConvertTo-Json -Depth 12)}
  Write-Output $result.result.value
  $checks=$result.result.value|ConvertFrom-Json
  if(!$checks -or @($checks.PSObject.Properties | Where-Object {$_.Value -ne $true}).Count -gt 0){throw 'Chat browser check failed'}
 }
 if($PortfolioCheck) {
  $expression=@"
(async()=>{
 const checks={},canvas=document.createElement('canvas');canvas.width=400;canvas.height=300;
 const ctx=canvas.getContext('2d');ctx.fillStyle='#e5dcff';ctx.fillRect(0,0,400,300);ctx.fillStyle='#8875bd';ctx.font='64px sans-serif';ctx.fillText('ART',120,170);
 const file=new File([await new Promise(r=>canvas.toBlob(r,'image/png'))],'art.png',{type:'image/png'});
 const input=document.getElementById('Media'),transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;input.dispatchEvent(new Event('change'));
 checks.imagePreview=!!document.querySelector('#portfolio-preview img');
 const csrf=document.querySelector('input[name=__RequestVerificationToken]').value;
 const body=new FormData();body.append('Title','Browser artwork');body.append('Media',file);body.append('__RequestVerificationToken',csrf);checks.uploadImage=(await fetch('/Portfolio/Upload',{method:'POST',body})).ok;
 const stream=canvas.captureStream(10),chunks=[];const recorder=new MediaRecorder(stream,{mimeType:'video/webm'});
 const done=new Promise(r=>recorder.onstop=r);recorder.ondataavailable=e=>chunks.push(e.data);recorder.start();const animate=setInterval(()=>{ctx.fillStyle=Date.now()%2 ? "#8875bd":"#e5dcff";ctx.fillRect(0,0,30,30);},50);await new Promise(r=>setTimeout(r,1500));clearInterval(animate);recorder.stop();await done;stream.getTracks().forEach(t=>t.stop());
 const clip=new File(chunks,'art.webm',{type:'video/webm'}),clipData=new DataTransfer();clipData.items.add(clip);input.files=clipData.files;input.dispatchEvent(new Event('change'));
 checks.videoPreview=!!document.querySelector('#portfolio-preview video');
 const videoBody=new FormData();videoBody.append('Title','Animated artwork');videoBody.append('Media',clip);videoBody.append('__RequestVerificationToken',csrf);checks.uploadVideo=(await fetch('/Portfolio/Upload',{method:'POST',body:videoBody})).ok;
 const html=await (await fetch('/Portfolio')).text(),doc=new DOMParser().parseFromString(html,'text/html');const source=doc.querySelector('video source');
 const player=document.createElement('video');player.muted=true;player.src=source.src;
 await new Promise((resolve,reject)=>{player.onloadeddata=resolve;player.onerror=()=>reject(new Error(player.error.message+" URL "+player.src));player.load();setTimeout(()=>reject(new Error('video timeout')),8000);});
 await player.play();checks.videoPlayable=player.videoWidth===400;player.pause();
 return JSON.stringify(checks);
})()
"@
  $result=Cdp 'Runtime.evaluate' @{expression=$expression;awaitPromise=$true;returnByValue=$true}
  if($result.exceptionDetails){Write-Output ($result | ConvertTo-Json -Depth 12)}
  Write-Output $result.result.value
  $checks=$result.result.value|ConvertFrom-Json
  if(!$checks -or @($checks.PSObject.Properties | Where-Object {$_.Value -ne $true}).Count -gt 0){throw 'Portfolio browser checks failed'}
  Cdp 'Page.navigate' @{url='http://localhost:5081/Portfolio'} | Out-Null
  Start-Sleep -Milliseconds 800
 }
 $metrics=Cdp 'Runtime.evaluate' @{expression='JSON.stringify({width:innerWidth,scroll:document.documentElement.scrollWidth,forms:document.forms.length,overflow:[...document.querySelectorAll("body *")].filter(e=>e.getBoundingClientRect().right>document.documentElement.clientWidth+1).map(e=>({tag:e.tagName,cls:e.className,right:e.getBoundingClientRect().right})).slice(0,15)})';returnByValue=$true}
 Write-Output $metrics.result.value
 $shot=Cdp 'Page.captureScreenshot' @{format='png';captureBeyondViewport=$true}
 [IO.File]::WriteAllBytes((Join-Path (Resolve-Path artifacts) "$Output.png"),[Convert]::FromBase64String($shot.data))
 Cdp 'Browser.close' @{} | Out-Null
} finally {if($ws){$ws.Dispose()}}









