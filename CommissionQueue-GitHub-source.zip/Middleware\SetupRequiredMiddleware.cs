﻿using CommissionQueue.Data;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Middleware;

public class SetupRequiredMiddleware(RequestDelegate next) {
    public async Task InvokeAsync(HttpContext context, AppDbContext db) {
        var route=context.GetRouteData();
        var controller=route.Values["controller"]?.ToString();
        var action=route.Values["action"]?.ToString();
        bool setup=string.Equals(controller,"Setup",StringComparison.OrdinalIgnoreCase);
        bool error=string.Equals(controller,"Home",StringComparison.OrdinalIgnoreCase) && string.Equals(action,"Error",StringComparison.OrdinalIgnoreCase);
        if(!setup && !error && !await db.ShopProfiles.AsNoTracking().AnyAsync(context.RequestAborted)) {
            context.Response.Redirect("/Setup");
            return;
        }
        await next(context);
    }
}

