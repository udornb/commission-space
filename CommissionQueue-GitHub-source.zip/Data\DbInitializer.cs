﻿using CommissionQueue.Models;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Data;

public static class DbInitializer {
    public static async Task InitializeAsync(IServiceProvider services) {
        var db=services.GetRequiredService<AppDbContext>();
        await AdoptLegacyDatabaseAsync(db);
        await db.Database.MigrateAsync();
        // Never create a shop or an admin here. First-run setup is the only creation path.
    }

    private static async Task AdoptLegacyDatabaseAsync(AppDbContext db) {
        var connection=(SqliteConnection)db.Database.GetDbConnection();
        await connection.OpenAsync();
        try {
            async Task<bool> HasTable(string name) {
                await using var command=connection.CreateCommand();
                command.CommandText="SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=$name";
                command.Parameters.AddWithValue("$name",name);
                return Convert.ToInt32(await command.ExecuteScalarAsync())>0;
            }
            if(await HasTable("__EFMigrationsHistory") || !await HasTable("CommissionOrder")) return;

            // Only adopt the known schema produced by version 1 EnsureCreated.
            var expected=new Dictionary<string,string[]> {
                ["CommissionOrder"]=["Id","OrderCode","CustomerName","Contact","WorkType","Description","Budget","FinalPrice","DueDate","ReferenceUrl","CustomerNote","AdminNote","Status","CreatedDate","EstimatedFinishDate","CompletedDate"],
                ["ShopSettings"]=["Id","ShopName","IsOpen"],
                ["AdminUsers"]=["Id","Username","PasswordHash"]
            };
            foreach(var (table,columns) in expected) {
                var actual=new HashSet<string>();
                await using var command=connection.CreateCommand();
                command.CommandText=$"PRAGMA table_info(\"{table}\")";
                await using var reader=await command.ExecuteReaderAsync();
                while(await reader.ReadAsync()) actual.Add(reader.GetString(1));
                if(!actual.SetEquals(columns)) throw new InvalidOperationException("Unknown legacy schema: "+table+". No changes made.");
            }
            await using(var check=connection.CreateCommand()) {
                check.CommandText="SELECT (SELECT COUNT(*) FROM ShopSettings) > 1 OR (SELECT COUNT(*) FROM AdminUsers) > 1 OR ((SELECT COUNT(*) FROM ShopSettings) = 1 AND (SELECT COUNT(*) FROM AdminUsers) != 1)";
                if(Convert.ToInt32(await check.ExecuteScalarAsync())!=0)
                    throw new InvalidOperationException("Legacy database must contain at most one shop with one admin. No changes made.");
            }
            // SQLite's backup API includes committed WAL data; never copy a live DB file directly.
            var backupPath=connection.DataSource+".pre-setup-"+DateTime.UtcNow.ToString("yyyyMMddHHmmssfff")+".db";
            await using(var backup=new SqliteConnection($"Data Source={backupPath}")) {
                await backup.OpenAsync();
                connection.BackupDatabase(backup);
            }
            await using var transaction=connection.BeginTransaction();
            await using var baseline=connection.CreateCommand();
            baseline.Transaction=transaction;
            baseline.CommandText="""
                CREATE TABLE "__EFMigrationsHistory" ("MigrationId" TEXT NOT NULL CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY, "ProductVersion" TEXT NOT NULL);
                INSERT INTO "__EFMigrationsHistory" ("MigrationId","ProductVersion") VALUES ('20261002042533_InitialLegacySchema','10.0.10');
                """;
            await baseline.ExecuteNonQueryAsync();
            await transaction.CommitAsync();
        } finally {await connection.CloseAsync();}
    }

    public static void AddSamples(AppDbContext db) {
        var today=DateTime.UtcNow.AddHours(7).Date;
        db.CommissionOrders.AddRange(
            new CommissionOrder {OrderCode="COM-0001",CustomerName="คุณเมฆ (ตัวอย่าง)",Contact="demo@example.com",WorkType="Character illustration",Description="ภาพตัวละครโทนพาสเทล",Budget=1800,FinalPrice=1800,DueDate=today.AddDays(7),EstimatedFinishDate=today.AddDays(5),Status=OrderStatus.InProgress,AdminNote="กำลังลงสี แล้วจะส่งภาพให้ตรวจนะคะ"},
            new CommissionOrder {OrderCode="COM-0002",CustomerName="คุณฟ้า (ตัวอย่าง)",Contact="@demo-sky",WorkType="Profile & avatar",Description="ภาพโปรไฟล์น่ารัก",Budget=800,DueDate=today.AddDays(10),Status=OrderStatus.Queued},
            new CommissionOrder {OrderCode="COM-0003",CustomerName="คุณดาว (ตัวอย่าง)",Contact="@demo-star",WorkType="Chibi & sticker",Description="สติกเกอร์ตัวละครจิ๋ว",Budget=1200,DueDate=today.AddDays(14),Status=OrderStatus.Queued});
    }
}

