﻿using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
namespace CommissionQueue.Services;

public static class AdminSession {
    public const string StampClaim="admin-credentials-stamp";
    // A derived credential fingerprint invalidates cookies after a username/password change.
    // The password hash itself is never placed in a claim or sent to a view.
    public static string CredentialStamp(ShopProfile shop) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(shop.AdminUsername+"\0"+shop.PasswordHash)));
    public static Task SignInAsync(HttpContext context, ShopProfile shop) =>
        context.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(new ClaimsIdentity([
                new Claim(ClaimTypes.NameIdentifier,shop.Id.ToString()),
                new Claim(ClaimTypes.Name,shop.AdminUsername),
                new Claim(StampClaim,CredentialStamp(shop))
            ],CookieAuthenticationDefaults.AuthenticationScheme)));
}

