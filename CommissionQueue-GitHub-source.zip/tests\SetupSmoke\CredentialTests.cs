﻿using System.Net;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;
using Microsoft.AspNetCore.Identity;
using CommissionQueue.Models;

static class CredentialTests {
 public static async Task Run(string url,string path) {
  int count=0;
  void Check(bool value,string text){if(!value)throw new Exception("FAIL: "+text);Console.WriteLine("PASS: "+text);count++;}
  HttpClient Client()=>new(new HttpClientHandler{AllowAutoRedirect=false,CookieContainer=new CookieContainer()}){BaseAddress=new Uri(url)};
  using var admin=Client();using var other=Client();using var third=Client();using var last=Client();
  async Task<string> Token(HttpClient client,string route) {
   var response=await client.GetAsync(route);response.EnsureSuccessStatusCode();
   return Regex.Match(WebUtility.HtmlDecode(await response.Content.ReadAsStringAsync()),"name=\"__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
  }
  async Task<HttpResponseMessage> Post(HttpClient client,string route,Dictionary<string,string> values,string token) {
   values=new(values){["__RequestVerificationToken"]=token};return await client.PostAsync(route,new FormUrlEncodedContent(values));
  }
  async Task<string> Sql(string sql) {
   await using var db=new SqliteConnection($"Data Source={path}");await db.OpenAsync();
   await using var cmd=db.CreateCommand();cmd.CommandText=sql;return Convert.ToString(await cmd.ExecuteScalarAsync())!;
  }
  async Task Login(HttpClient client,string username,string password) {
   var response=await Post(client,"/Admin/Login",new(){["Username"]=username,["Password"]=password},await Token(client,"/Admin/Login"));
   Check(response.StatusCode==HttpStatusCode.Redirect && (await client.GetAsync("/Admin/Shop")).IsSuccessStatusCode,"Login accepted: "+username);
  }
  async Task<bool> Invalid(HttpResponseMessage response)=>response.StatusCode==HttpStatusCode.OK && (await response.Content.ReadAsStringAsync()).Contains("validation-summary-errors");
  var setup=new Dictionary<string,string>{["ShopCode"]="ACCOUNT-TEST",["OwnerName"]="Test Owner",["ShopName"]="Mellow Studio",["AdminUsername"]="admin",["Password"]="Mellow@12345",["ConfirmPassword"]="Mellow@12345",["Email"]="owner@example.test",["Phone"]="0812345678",["IsOpen"]="true"};
  Check((await Post(admin,"/Setup",setup,await Token(admin,"/Setup"))).StatusCode==HttpStatusCode.Redirect,"Create isolated shop");
  await Login(other,"admin","Mellow@12345");
  var token=await Token(admin,"/Admin/Shop");
  var originalHash=await Sql("SELECT PasswordHash FROM ShopProfile");
  Check((await admin.GetStringAsync("/Admin/Shop")).Contains("admin-account"),"Credentials card is in shop settings");
  Check((await third.PostAsync("/Admin/Shop/Credentials",new FormUrlEncodedContent(new Dictionary<string,string>()))).StatusCode==HttpStatusCode.Redirect,"Anonymous credentials change denied");
  Check((await admin.PostAsync("/Admin/Shop/Credentials",new FormUrlEncodedContent(new Dictionary<string,string>()))).StatusCode==HttpStatusCode.BadRequest,"CSRF required");
  Check(await Invalid(await Post(admin,"/Admin/Shop/Credentials",new(),token)),"Required fields validated");
  var wrong=await Post(admin,"/Admin/Shop/Credentials",new(){["Username"]="owner",["CurrentPassword"]="Incorrect-Secret-123"},token);
  var wrongHtml=WebUtility.HtmlDecode(await wrong.Content.ReadAsStringAsync());
  Check(wrong.StatusCode==HttpStatusCode.OK && wrongHtml.Contains("รหัสผ่านปัจจุบันไม่ถูกต้อง"),"Incorrect current password rejected");
  Check(!wrongHtml.Contains("Incorrect-Secret-123"),"Current password never echoed into response");
  Check(await Invalid(await Post(admin,"/Admin/Shop/Credentials",new(){["Username"]="owner",["CurrentPassword"]="Mellow@12345",["NewPassword"]="Changed@12345",["ConfirmPassword"]="mismatch"},token)),"New password confirmation validated");
  Check(await Invalid(await Post(admin,"/Admin/Shop/Credentials",new(){["Username"]="invalid name",["CurrentPassword"]="Mellow@12345",["NewPassword"]="short",["ConfirmPassword"]="short"},token)),"Username format and password length validated");
  Check(await Sql("SELECT PasswordHash FROM ShopProfile")==originalHash && await Sql("SELECT AdminUsername FROM ShopProfile")=="admin","Invalid attempts leave credentials unchanged");
  var renamed=await Post(admin,"/Admin/Shop/Credentials",new(){["Username"]="owner",["CurrentPassword"]="Mellow@12345"},token);
  Check(renamed.StatusCode==HttpStatusCode.Redirect && renamed.Headers.Location?.ToString()=="/Admin/Login","Username-only change redirects to Login");
  Check(await Sql("SELECT AdminUsername FROM ShopProfile")=="owner" && await Sql("SELECT PasswordHash FROM ShopProfile")==originalHash,"Username-only change keeps existing password");
  Check((await admin.GetAsync("/Admin")).StatusCode==HttpStatusCode.Redirect && (await other.GetAsync("/Admin")).StatusCode==HttpStatusCode.Redirect,"Username change invalidates current and other sessions");
  await Login(admin,"owner","Mellow@12345");await Login(other,"owner","Mellow@12345");
  token=await Token(admin,"/Admin/Shop");
  var passwordChanged=await Post(admin,"/Admin/Shop/Credentials",new(){["Username"]="owner",["CurrentPassword"]="Mellow@12345",["NewPassword"]="Changed@12345",["ConfirmPassword"]="Changed@12345"},token);
  Check(passwordChanged.StatusCode==HttpStatusCode.Redirect,"Password-only change succeeds");
  var hash=await Sql("SELECT PasswordHash FROM ShopProfile");
  Check(hash!=originalHash && hash!="Changed@12345" && new PasswordHasher<ShopProfile>().VerifyHashedPassword(new ShopProfile(),hash,"Changed@12345")!=PasswordVerificationResult.Failed,"New password stored as verifiable hash");
  Check((await other.GetAsync("/Admin/Shop")).StatusCode==HttpStatusCode.Redirect,"Password-only change invalidates another browser session");
  var thirdToken=await Token(third,"/Admin/Login");
  Check(await Invalid(await Post(third,"/Admin/Login",new(){["Username"]="owner",["Password"]="Mellow@12345"},thirdToken)),"Old password cannot log in");
  await Login(third,"owner","Changed@12345");
  var changedBoth=await Post(third,"/Admin/Shop/Credentials",new(){["Username"]="owner-final",["CurrentPassword"]="Changed@12345",["NewPassword"]="FinalPass@12345",["ConfirmPassword"]="FinalPass@12345"},await Token(third,"/Admin/Shop"));
  Check(changedBoth.StatusCode==HttpStatusCode.Redirect,"Username and password can change together");
  var lastToken=await Token(last,"/Admin/Login");
  Check(await Invalid(await Post(last,"/Admin/Login",new(){["Username"]="owner",["Password"]="FinalPass@12345"},lastToken)),"Old username cannot log in");
  await Login(last,"owner-final","FinalPass@12345");
  Check(await Sql("SELECT ShopCode FROM ShopProfile")=="ACCOUNT-TEST" && await Sql("SELECT COUNT(*) FROM CommissionOrder")=="3","Shop and orders remain intact");
  Console.WriteLine($"SUCCESS: {count} credential checks passed.");
 }
}



