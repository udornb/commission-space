﻿using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Net.Http.Headers;
static class PortfolioTests {
 public static async Task Run(string url) {
  int checks=0;void Check(bool b,string name){if(!b)throw new Exception(name);Console.WriteLine("PASS: "+name);checks++;}
  HttpClient Client()=>new(new HttpClientHandler{AllowAutoRedirect=false,CookieContainer=new CookieContainer()}){BaseAddress=new Uri(url)};
  using var admin=Client();using var visitor=Client();
  async Task<string> Page(HttpClient c,string p){var r=await c.GetAsync(p);r.EnsureSuccessStatusCode();return WebUtility.HtmlDecode(await r.Content.ReadAsStringAsync());}
  async Task<string> Token(HttpClient c,string p)=>Regex.Match(await Page(c,p),"name=\"__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
  async Task<HttpResponseMessage> Post(HttpClient c,string p,Dictionary<string,string> fields,string token,byte[]? bytes=null,string filename="art.png") {
   using var body=new MultipartFormDataContent();foreach(var f in fields)body.Add(new StringContent(f.Value),f.Key);body.Add(new StringContent(token),"__RequestVerificationToken");if(bytes is not null)body.Add(new ByteArrayContent(bytes),"Media",filename);return await c.PostAsync(p,body);
  }
  Check((await Page(visitor,"/")).Contains("/Portfolio"),"Home links to portfolio");
  Check((await Page(visitor,"/Portfolio")).Contains("เรทราคา"),"Public portfolio accessible");
  Check((await visitor.GetAsync("/Portfolio/Manage")).StatusCode==HttpStatusCode.Redirect,"Management requires owner");
  Check((await Post(admin,"/Admin/Login",new(){["Username"]="admin",["Password"]="Mellow@12345"},await Token(admin,"/Admin/Login"))).StatusCode==HttpStatusCode.Redirect,"Owner login");
  var token=await Token(admin,"/Portfolio/Manage");
  Check((await Page(admin,"/Portfolio/Manage")).Contains("Headshot"),"Editable pricing template");
  Check((await Post(admin,"/Portfolio/Rates",new(){["rates"]=" "},token)).StatusCode==HttpStatusCode.OK,"Blank pricing rejected");
  Check((await admin.PostAsync("/Portfolio/Rates",new FormUrlEncodedContent(new Dictionary<string,string>{["rates"]="invalid"}))).StatusCode==HttpStatusCode.BadRequest,"CSRF required");
  Check((await Post(admin,"/Portfolio/Rates",new(){["rates"]="หัว 500 บาท\nครึ่งตัว 900 บาท\nเต็มตัว 1500 บาท\n<script>bad</script>"},token)).StatusCode==HttpStatusCode.Redirect,"Owner saves pricing");
  var html=await (await visitor.GetAsync("/Portfolio")).Content.ReadAsStringAsync();
  Check(WebUtility.HtmlDecode(html).Contains("เต็มตัว 1500 บาท") && html.Contains("&lt;script&gt;"),"Public pricing safely rendered");
  Check((await Post(visitor,"/Portfolio/Rates",new(){["rates"]="hack"},await Token(visitor,"/Commission/Track"))).StatusCode==HttpStatusCode.Redirect,"Visitor cannot edit pricing");
  Check((await Post(admin,"/Portfolio/Upload",new(){["Title"]="Missing"},token)).StatusCode==HttpStatusCode.OK,"Missing file rejected");
  Check((await Post(admin,"/Portfolio/Upload",new(){["Title"]="Fake"},token,Encoding.UTF8.GetBytes("<script/>"))).StatusCode==HttpStatusCode.OK,"Fake image rejected");
  var png=Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII=");
  Check((await Post(admin,"/Portfolio/Upload",new(){["Title"]="Portfolio image",["Description"]="Example artwork"},token,png)).StatusCode==HttpStatusCode.Redirect,"Owner uploads image");
  html=await Page(visitor,"/Portfolio");var imagePath=Regex.Match(html,"src=\"(/Portfolio/Media/[^\"]+)\"").Groups[1].Value;
  Check(imagePath.Length>0 && (await visitor.GetByteArrayAsync(imagePath)).SequenceEqual(png),"Public image preserves original bytes");
  var video=new byte[]{0,0,0,24,102,116,121,112,105,115,111,109,0,0,0,0,105,115,111,109,109,112,52,50};
  Check((await Post(admin,"/Portfolio/Upload",new(){["Title"]="Portfolio video"},token,video,"clip.mp4")).StatusCode==HttpStatusCode.Redirect,"Owner uploads MP4");
  html=await Page(visitor,"/Portfolio");var videoPath=Regex.Match(html,"<source src=\"([^\"]+)\"").Groups[1].Value;
  Check(html.Contains("<video controls")&&videoPath.Length>0,"Gallery has video player controls");
  using var request=new HttpRequestMessage(HttpMethod.Get,videoPath);request.Headers.Range=new RangeHeaderValue(0,7);var range=await visitor.SendAsync(request);
  Check(range.StatusCode==HttpStatusCode.PartialContent && (await range.Content.ReadAsByteArrayAsync()).Length==8,"Video byte ranges supported");
  var id=videoPath.Split('/').Last();
  Check((await Post(visitor,"/Portfolio/Delete/"+id,new(),await Token(visitor,"/Commission/Track"))).StatusCode==HttpStatusCode.Redirect,"Visitor cannot delete artwork");
  Check((await Post(admin,"/Portfolio/Delete/"+id,new(),token)).StatusCode==HttpStatusCode.Redirect,"Owner deletes artwork");
  Check((await visitor.GetAsync(videoPath)).StatusCode==HttpStatusCode.NotFound,"Deleted media unavailable");
  Console.WriteLine($"SUCCESS: {checks} portfolio checks passed.");
 }
}

