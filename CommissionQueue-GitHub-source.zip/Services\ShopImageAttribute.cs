﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Services;

// Validate size, extension and content signature on the server, not just the browser's MIME type.
public sealed class ShopImageAttribute : ValidationAttribute {
    public const long MaxBytes = 2 * 1024 * 1024;
    protected override ValidationResult? IsValid(object? value, ValidationContext context) {
        if(value is not IFormFile file) return ValidationResult.Success;
        if(file.Length == 0 || file.Length > MaxBytes) return new("รูปต้องมีข้อมูลและขนาดไม่เกิน 2 MB");
        var ext=Path.GetExtension(file.FileName).ToLowerInvariant();
        if(ext is not (".png" or ".jpg" or ".jpeg")) return new("รองรับเฉพาะรูป PNG หรือ JPG");
        using var stream=file.OpenReadStream();
        using var memory=new MemoryStream();
        stream.CopyTo(memory);
        var bytes=memory.ToArray();
        bool png=bytes.Length>=45 && bytes.AsSpan(0,8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10})
            && bytes.AsSpan(12,4).SequenceEqual("IHDR"u8)
            && bytes.AsSpan(bytes.Length-8,8).SequenceEqual(new byte[]{73,69,78,68,174,66,96,130});
        bool jpg=bytes.Length>=4 && bytes[0]==255 && bytes[1]==216 && bytes[2]==255 && bytes[^2]==255 && bytes[^1]==217;
        return (ext==".png" ? png : jpg) ? ValidationResult.Success : new("เนื้อหาไฟล์ไม่ใช่รูป PNG/JPG ที่ตรงกับนามสกุล");
    }
}

