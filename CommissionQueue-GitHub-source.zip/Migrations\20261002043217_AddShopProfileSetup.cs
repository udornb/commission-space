﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CommissionQueue.Migrations
{
    /// <inheritdoc />
    public partial class AddShopProfileSetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ShopProfile",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false),
                    ShopCode = table.Column<string>(type: "TEXT", maxLength: 30, nullable: false, collation: "NOCASE"),
                    OwnerName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                    ShopName = table.Column<string>(type: "TEXT", maxLength: 80, nullable: false),
                    AdminUsername = table.Column<string>(type: "TEXT", maxLength: 50, nullable: false, collation: "NOCASE"),
                    PasswordHash = table.Column<string>(type: "TEXT", nullable: false),
                    Email = table.Column<string>(type: "TEXT", maxLength: 254, nullable: false),
                    Phone = table.Column<string>(type: "TEXT", maxLength: 30, nullable: false),
                    LineContact = table.Column<string>(type: "TEXT", maxLength: 200, nullable: true),
                    FacebookContact = table.Column<string>(type: "TEXT", maxLength: 500, nullable: true),
                    InstagramContact = table.Column<string>(type: "TEXT", maxLength: 200, nullable: true),
                    Description = table.Column<string>(type: "TEXT", maxLength: 500, nullable: true),
                    LogoPath = table.Column<string>(type: "TEXT", nullable: true),
                    ProfileImagePath = table.Column<string>(type: "TEXT", nullable: true),
                    IsOpen = table.Column<bool>(type: "INTEGER", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "TEXT", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ShopProfile", x => x.Id);
                    table.CheckConstraint("CK_ShopProfile_SingleShop", "Id = 1");
                });

            migrationBuilder.CreateIndex(
                name: "IX_ShopProfile_AdminUsername",
                table: "ShopProfile",
                column: "AdminUsername",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ShopProfile_ShopCode",
                table: "ShopProfile",
                column: "ShopCode",
                unique: true);
            // Preserve the existing shop and password hash when upgrading version 1.
            migrationBuilder.Sql("""
                INSERT INTO "ShopProfile" ("Id","ShopCode","OwnerName","ShopName","AdminUsername","PasswordHash","Email","Phone","IsOpen","CreatedDate","UpdatedDate")
                SELECT 1, 'LEGACY-' || printf('%04d',s."Id"), s."ShopName", s."ShopName", a."Username", a."PasswordHash", '', '', s."IsOpen", datetime('now'), datetime('now')
                FROM "ShopSettings" s CROSS JOIN "AdminUsers" a
                ORDER BY s."Id", a."Id" LIMIT 1;
                """);
            migrationBuilder.DropTable(name: "AdminUsers");
            migrationBuilder.DropTable(name: "ShopSettings");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AdminUsers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    PasswordHash = table.Column<string>(type: "TEXT", nullable: false),
                    Username = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdminUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ShopSettings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    IsOpen = table.Column<bool>(type: "INTEGER", nullable: false),
                    ShopName = table.Column<string>(type: "TEXT", maxLength: 80, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ShopSettings", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AdminUsers_Username",
                table: "AdminUsers",
                column: "Username",
                unique: true);
            // Downgrade retains login and the basic shop fields supported by version 1.
            migrationBuilder.Sql("""
                INSERT INTO "AdminUsers" ("Id","Username","PasswordHash") SELECT 1,"AdminUsername","PasswordHash" FROM "ShopProfile";
                INSERT INTO "ShopSettings" ("Id","ShopName","IsOpen") SELECT 1,"ShopName","IsOpen" FROM "ShopProfile";
                """);
            migrationBuilder.DropTable(name: "ShopProfile");
        }
    }
}

