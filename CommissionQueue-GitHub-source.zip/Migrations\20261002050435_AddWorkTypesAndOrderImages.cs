﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CommissionQueue.Migrations
{
    /// <inheritdoc />
    public partial class AddWorkTypesAndOrderImages : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OrderImages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    CommissionOrderId = table.Column<int>(type: "INTEGER", nullable: false),
                    FileName = table.Column<string>(type: "TEXT", maxLength: 200, nullable: false),
                    ContentType = table.Column<string>(type: "TEXT", maxLength: 30, nullable: false),
                    Content = table.Column<byte[]>(type: "BLOB", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderImages", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderImages_CommissionOrder_CommissionOrderId",
                        column: x => x.CommissionOrderId,
                        principalTable: "CommissionOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WorkTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", maxLength: 80, nullable: false),
                    NormalizedName = table.Column<string>(type: "TEXT", maxLength: 160, nullable: false),
                    IsActive = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkTypes", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OrderImages_CommissionOrderId",
                table: "OrderImages",
                column: "CommissionOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_WorkTypes_NormalizedName",
                table: "WorkTypes",
                column: "NormalizedName",
                unique: true);
            migrationBuilder.InsertData(
                table: "WorkTypes",
                columns: new[] { "Id", "Name", "NormalizedName", "IsActive" },
                values: new object[,] {
                    { 1, "รูปตัวละคร", "รูปตัวละคร", true },
                    { 2, "โปรไฟล์ & อวาตาร์", "โปรไฟล์ & อวาตาร์", true },
                    { 3, "จิบิ & สติกเกอร์", "จิบิ & สติกเกอร์", true }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrderImages");

            migrationBuilder.DropTable(
                name: "WorkTypes");
        }
    }
}

