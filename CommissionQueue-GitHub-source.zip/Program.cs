﻿using CommissionQueue.Data;
using CommissionQueue.Middleware;
using CommissionQueue.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Threading.RateLimiting;

var builder=WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews(o=>o.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()));
builder.Services.AddDbContext<AppDbContext>(o=>o.UseSqlite($"Data Source={Path.Combine(builder.Environment.ContentRootPath,builder.Configuration["DatabasePath"]??"commissions.db")}"));
builder.Services.AddScoped<ShopImageStore>();
builder.Services.AddScoped<OrderFormService>();
builder.Services.AddScoped<PaymentService>();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o=>{
    o.LoginPath="/Admin/Login"; o.ExpireTimeSpan=TimeSpan.FromHours(8);
    o.Cookie.Name=".CommissionQueue.Admin.v2"; o.Cookie.HttpOnly=true; o.Cookie.SameSite=SameSiteMode.Lax;
    o.Events.OnValidatePrincipal=async context=>{
        var db=context.HttpContext.RequestServices.GetRequiredService<AppDbContext>();
        var username=context.Principal?.Identity?.Name;
        var id=context.Principal?.FindFirstValue(ClaimTypes.NameIdentifier);
        var shop=await db.ShopProfiles.AsNoTracking().SingleOrDefaultAsync(s=>s.Id==1);
        var stamp=context.Principal?.FindFirstValue(AdminSession.StampClaim);
        if(id!="1" || shop is null || shop.AdminUsername!=username || stamp!=AdminSession.CredentialStamp(shop)) {
            context.RejectPrincipal();
            await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        }
    };
});
builder.Services.AddAuthorization();
builder.Services.AddRateLimiter(o=>{
    o.RejectionStatusCode=429;
    o.AddPolicy("forms",c=>RateLimitPartition.GetFixedWindowLimiter(c.Connection.RemoteIpAddress?.ToString()??"local",
        _=>new FixedWindowRateLimiterOptions {PermitLimit=20,Window=TimeSpan.FromMinutes(1),QueueLimit=0}));
});
var app=builder.Build();
app.UseExceptionHandler("/Home/Error");
app.UseStatusCodePagesWithReExecute("/Home/Error","?statusCode={0}");
app.Use(async (context,next)=>{ context.Response.Headers["X-Content-Type-Options"]="nosniff"; await next(); });
app.UseStaticFiles();
app.UseRouting();
app.UseRateLimiter();
app.UseAuthentication();
app.UseMiddleware<SetupRequiredMiddleware>();
app.UseAuthorization();
using(var scope=app.Services.CreateScope()) await DbInitializer.InitializeAsync(scope.ServiceProvider);
app.MapControllers();
app.MapControllerRoute("default","{controller=Home}/{action=Index}/{id?}");
app.Run();

