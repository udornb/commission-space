(() => {
 const messages=document.getElementById('chat-messages'), status=document.getElementById('chat-status');
 messages.scrollTop=messages.scrollHeight;
 async function refresh() {
  if(!document.hidden) try {
   const response=await fetch(messages.dataset.url,{cache:'no-store'});
   if(!response.ok) throw new Error();
   const html=await response.text();
   const nearBottom=messages.scrollHeight-messages.scrollTop-messages.clientHeight<100;
   if(html!==messages.innerHTML) {messages.innerHTML=html;if(nearBottom) messages.scrollTop=messages.scrollHeight;}
   status.textContent='อัปเดตข้อความอัตโนมัติทุก 5 วินาที';
  } catch {status.textContent='อัปเดตข้อความไม่ได้ กำลังลองใหม่ หากยังไม่ได้ให้เปิดห้องคุยงานอีกครั้ง';}
  window.setTimeout(refresh,5000);
 }
 window.setTimeout(refresh,5000);
 const input=document.getElementById('Attachment'),preview=document.getElementById('chat-preview');let objectUrl;
 input.addEventListener('change',()=>{
  if(objectUrl) URL.revokeObjectURL(objectUrl);
  preview.hidden=true;preview.removeAttribute('src');input.setCustomValidity('');
  const file=input.files[0]; const error=file && file.size>20*1024*1024?'ไฟล์ต้องมีขนาดไม่เกิน 20 MB':'';
  document.getElementById('chat-file-error').textContent=error;input.setCustomValidity(error);
  if(file && !error && /^image\/(png|jpeg|gif|webp)$/.test(file.type)) {objectUrl=URL.createObjectURL(file);preview.src=objectUrl;preview.hidden=false;}
 });
})();
