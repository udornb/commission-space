﻿using CommissionQueue.Services;
using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Controllers;
[Authorize, ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
public class AdminController(AppDbContext db, OrderFormService forms, PaymentService payments):Controller {
 [AllowAnonymous] public IActionResult Login()=>User.Identity?.IsAuthenticated==true?RedirectToAction(nameof(Index)):View(new LoginForm());
 [AllowAnonymous,HttpPost,EnableRateLimiting("forms")] public async Task<IActionResult> Login(LoginForm f) {
  if(!ModelState.IsValid) return View(f);
  var u=await db.ShopProfiles.SingleOrDefaultAsync(x=>x.AdminUsername==f.Username.Trim());
  if(u is null || new PasswordHasher<ShopProfile>().VerifyHashedPassword(u,u.PasswordHash,f.Password)==PasswordVerificationResult.Failed) {ModelState.AddModelError("","ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"); return View(f);}
  await AdminSession.SignInAsync(HttpContext,u);
  return RedirectToAction(nameof(Index));
 }
 [HttpPost] public async Task<IActionResult> Logout() {await HttpContext.SignOutAsync(); return RedirectToAction("Index","Home");}
 public async Task<IActionResult> Index() {
  ViewBag.PaymentNotices=await db.OrderPayments.AsNoTracking().Where(p=>p.ReportedAt!=null && p.ConfirmedAt==null).OrderBy(p=>p.ReportedAt).Select(p=>new PaymentNotice(p.CommissionOrderId,p.CommissionOrder.OrderCode)).ToListAsync();
  return View(new DashboardModel(await db.ShopProfiles.SingleAsync(),await db.CommissionOrders.AsNoTracking().OrderByDescending(x=>x.Id).ToListAsync()));
 }
 public async Task<IActionResult> Details(int id) {var o=await db.CommissionOrders.Include(o=>o.Payment).SingleOrDefaultAsync(o=>o.Id==id); if(o is null) return NotFound(); ViewBag.OrderImages=await db.OrderImages.Where(i=>i.CommissionOrderId==id).OrderBy(i=>i.Id).Select(i=>new OrderImageInfo(i.Id,i.FileName)).ToListAsync(); return View(o);}
 public async Task<IActionResult> Edit(int id) {
  var o=await db.CommissionOrders.Include(o=>o.Payment).SingleOrDefaultAsync(o=>o.Id==id); if(o is null) return NotFound(); ViewBag.OrderCode=o.OrderCode;
  var form=new EditForm {Id=o.Id,CustomerName=o.CustomerName,Contact=o.Contact,WorkType=o.WorkType,Description=o.Description,Budget=o.Budget,DueDate=o.DueDate,ReferenceUrl=o.ReferenceUrl,CustomerNote=o.CustomerNote,Status=o.Status,FinalPrice=o.FinalPrice,EstimatedFinishDate=o.EstimatedFinishDate,AdminNote=o.AdminNote,PaymentRecipientName=o.Payment?.RecipientName,PaymentRevision=o.Payment?.Revision,HasPaymentQr=o.Payment is not null};
  await forms.PrepareAsync(form,o.WorkType,o.Id); return View(form);
 }
 [HttpPost, RequestSizeLimit(15*1024*1024), RequestFormLimits(MultipartBodyLengthLimit=15*1024*1024)] public async Task<IActionResult> Edit(int id,EditForm f) {
  if(id!=f.Id) return BadRequest(); var o=await db.CommissionOrders.Include(o=>o.Payment).SingleOrDefaultAsync(o=>o.Id==id); if(o is null) return NotFound();
  ViewBag.OrderCode=o.OrderCode; await forms.PrepareAsync(f,o.WorkType,o.Id); forms.Validate(f,ModelState,o.WorkType); f.HasPaymentQr=o.Payment is not null; payments.Validate(f,o.Payment,ModelState); if(!ModelState.IsValid) return View(f);
  o.CustomerName=f.CustomerName.Trim(); o.Contact=f.Contact.Trim(); o.WorkType=f.WorkType.Trim(); o.Description=f.Description.Trim(); o.Budget=f.Budget!.Value; o.DueDate=f.DueDate!.Value; o.ReferenceUrl=f.ReferenceUrl; o.CustomerNote=f.CustomerNote;
  var oldPrice=o.FinalPrice;
  o.FinalPrice=f.FinalPrice; o.EstimatedFinishDate=f.EstimatedFinishDate; o.AdminNote=f.AdminNote;
  o.CompletedDate=f.Status==OrderStatus.Completed ? o.CompletedDate??DateTime.UtcNow:null; o.Status=f.Status;
  var removed=await db.OrderImages.Where(i=>i.CommissionOrderId==id && f.RemoveImageIds.Contains(i.Id)).ToListAsync();
  db.OrderImages.RemoveRange(removed); await forms.AddImagesAsync(o,f.Images,HttpContext.RequestAborted);
  await payments.ApplyAsync(o,o.Payment,f,oldPrice,HttpContext.RequestAborted);
  try {await db.SaveChangesAsync();} catch(DbUpdateConcurrencyException) {ModelState.AddModelError("","ข้อมูลชำระเงินถูกแก้ไขแล้ว กรุณาเปิดหน้าแก้ไขใหม่"); return View(f);}
  TempData["Message"]="บันทึกข้อมูลเรียบร้อยแล้ว"; return RedirectToAction(nameof(Details),new {id});
 }
 [HttpPost] public async Task<IActionResult> Delete(int id) {
  var o=await db.CommissionOrders.Include(o=>o.Payment).SingleOrDefaultAsync(o=>o.Id==id); if(o is null) return NotFound();
  db.CommissionOrders.Remove(o); await db.SaveChangesAsync(); TempData["Message"]="ลบ Order เรียบร้อยแล้ว"; return RedirectToAction(nameof(Index));
 }
 [HttpGet] public async Task<IActionResult> OrderImage(int id) { var image=await db.OrderImages.AsNoTracking().SingleOrDefaultAsync(i=>i.Id==id); return image is null ? NotFound() : File(image.Content,image.ContentType); }
 public IActionResult Settings() => RedirectToAction("Index","Shop");
}



