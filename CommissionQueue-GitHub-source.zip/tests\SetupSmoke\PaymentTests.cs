﻿using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;

static class PaymentTests {
 public static async Task Run(string url,string path) {
  int checks=0;
  void Check(bool ok,string name){if(!ok)throw new Exception("FAIL: "+name);Console.WriteLine("PASS: "+name);checks++;}
  HttpClient Client()=>new(new HttpClientHandler{AllowAutoRedirect=false,CookieContainer=new CookieContainer()}){BaseAddress=new Uri(url)};
  using var admin=Client();using var customer=Client();
  async Task<string> Page(HttpClient c,string route){var r=await c.GetAsync(route);r.EnsureSuccessStatusCode();return WebUtility.HtmlDecode(await r.Content.ReadAsStringAsync());}
  async Task<string> Token(HttpClient c,string route)=>Regex.Match(await Page(c,route),"name=\"__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"").Groups[1].Value;
  async Task<HttpResponseMessage> Post(HttpClient c,string route,Dictionary<string,string> values,string token,byte[]? file=null,string field="PaymentQr",string fileName="bank-qr.png"){
   using var body=new MultipartFormDataContent();
   foreach(var v in values)body.Add(new StringContent(v.Value),v.Key);
   body.Add(new StringContent(token),"__RequestVerificationToken");
   if(file is not null)body.Add(new ByteArrayContent(file),field,fileName);
   return await c.PostAsync(route,body);
  }
  async Task<string> Sql(string sql){await using var db=new SqliteConnection($"Data Source={path}");await db.OpenAsync();await using var cmd=db.CreateCommand();cmd.CommandText=sql;return Convert.ToString(await cmd.ExecuteScalarAsync())!;}
  async Task<bool> Invalid(HttpResponseMessage r)=>r.StatusCode==HttpStatusCode.OK && (await r.Content.ReadAsStringAsync()).Contains("validation-summary-errors");
  var png=Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII=");
  var setup=new Dictionary<string,string>{["ShopCode"]="PAYMENT-TEST",["OwnerName"]="Test Owner",["ShopName"]="Mellow Studio",["AdminUsername"]="admin",["Password"]="Mellow@12345",["ConfirmPassword"]="Mellow@12345",["Email"]="owner@example.test",["Phone"]="0812345678",["IsOpen"]="true"};
  Check((await Post(admin,"/Setup",setup,await Token(admin,"/Setup"))).StatusCode==HttpStatusCode.Redirect,"Create test shop");
  Check(await Sql("SELECT COUNT(*) FROM __EFMigrationsHistory")=="6","Payment migration applied");
  Check(!(await Page(customer,"/")).Contains("data-open-tip"),"Tip jar hidden until configured");
  var adminToken=await Token(admin,"/Admin/Shop");
  var customerToken=await Token(customer,"/Commission/Create");
  var order=new Dictionary<string,string>{["CustomerName"]="Payment Customer",["Contact"]="private@example.test",["WorkType"]="รูปตัวละคร",["Description"]="Test payment flow",["Budget"]="1800",["DueDate"]=DateTime.UtcNow.AddDays(30).ToString("yyyy-MM-dd"),["FinalPrice"]="1"};
  Check((await Post(customer,"/Commission/Create",order,customerToken,png)).StatusCode==HttpStatusCode.Redirect,"Create request with order number");
  var success=await Page(customer,"/Commission/Success");
  Check(success.Contains("COM-0004") && success.Contains("/Payment"),"Success page links order to payment page");
  Check(await Sql("SELECT FinalPrice IS NULL FROM CommissionOrder WHERE Id=4")=="1" && await Sql("SELECT COUNT(*) FROM OrderPayments")=="0","Customer cannot set final price or payment QR");
  var paymentUrl="/Payment?orderCode=COM-0004";
  Check((await Page(customer,paymentUrl)).Contains("รอร้านแจ้งยอดและ QR"),"Payment page waits for owner setup");
  Check((await customer.PostAsync("/Admin/Edit/4",new FormUrlEncodedContent(order))).StatusCode==HttpStatusCode.Redirect,"Only owner can edit order QR");
  var edit=new Dictionary<string,string>(order){["Id"]="4",["Status"]="4",["FinalPrice"]="0",["PaymentRecipientName"]="Test Shop"};
  Check(await Invalid(await Post(admin,"/Admin/Edit/4",edit,adminToken,png)),"QR requires a positive final price");
  edit["FinalPrice"]="1500.50";
  Check(await Invalid(await Post(admin,"/Admin/Edit/4",edit,adminToken,Encoding.UTF8.GetBytes("not an image"))),"Fake QR image file rejected");
  Check(await Invalid(await Post(admin,"/Admin/Edit/4",edit,adminToken,new byte[2*1024*1024+1])),"Oversized QR rejected");
  Check((await Post(admin,"/Admin/Edit/4",edit,adminToken,png)).StatusCode==HttpStatusCode.Redirect,"Owner saves final price and QR");
  var revision=await Sql("SELECT Revision FROM OrderPayments WHERE CommissionOrderId=4");
  var payment=await Page(customer,paymentUrl);
  Check(payment.Contains("1,500.50") && payment.Contains("Test Shop") && payment.Contains("ชำระเงินแล้ว"),"Customer sees real price QR and report button");
  var qrUrl=$"/Payment/Qr?orderCode=COM-0004&revision={revision}";
  Check((await customer.GetAsync(qrUrl)).IsSuccessStatusCode,"Customer can fetch current payment QR");
  var track=await Post(customer,"/Commission/Track",new(){["orderCode"]="COM-0004"},customerToken);
  Check((await track.Content.ReadAsStringAsync()).Contains("/Payment"),"Tracking page links to payment");
  var reportToken=await Token(customer,paymentUrl);
  var noCsrf=await customer.PostAsync("/Payment/Report",new FormUrlEncodedContent(new Dictionary<string,string>{["orderCode"]="COM-0004",["revision"]=revision}));
  Check(noCsrf.StatusCode==HttpStatusCode.BadRequest,"Payment notification requires CSRF");
  edit["PaymentRevision"]=revision;edit["FinalPrice"]="1600";
  Check((await Post(admin,"/Admin/Edit/4",edit,adminToken)).StatusCode==HttpStatusCode.Redirect,"Owner changes price while keeping QR");
  var nextRevision=await Sql("SELECT Revision FROM OrderPayments WHERE CommissionOrderId=4");
  Check(nextRevision!=revision && (await customer.GetAsync(qrUrl)).StatusCode==HttpStatusCode.NotFound,"Old QR page revision invalidated after price change");
  await Post(customer,"/Payment/Report",new(){["orderCode"]="COM-0004",["revision"]=revision},reportToken);
  Check(await Sql("SELECT ReportedAt IS NULL FROM OrderPayments WHERE CommissionOrderId=4")=="1","Stale amount cannot be reported as paid");
  var reportFields=new Dictionary<string,string>{["orderCode"]="COM-0004",["revision"]=nextRevision,["ConfirmedAt"]="2026-01-01",["FinalPrice"]="1"};
  var report=await Post(customer,"/Payment/Report",reportFields,reportToken);
  Check(report.StatusCode==HttpStatusCode.Redirect && report.Headers.Location?.ToString()=="/","Paid button returns customer to Home");
  var reportedAt=await Sql("SELECT ReportedAt FROM OrderPayments WHERE CommissionOrderId=4");
  Check(reportedAt.Length>0 && await Sql("SELECT ConfirmedAt IS NULL FROM OrderPayments WHERE CommissionOrderId=4")=="1","Notification does not auto-confirm receipt");
  Check(await Sql("SELECT FinalPrice FROM CommissionOrder WHERE Id=4")=="1600.0","Customer cannot tamper with charged amount");
  await Post(customer,"/Payment/Report",reportFields,reportToken);
  Check(await Sql("SELECT ReportedAt FROM OrderPayments WHERE CommissionOrderId=4")==reportedAt,"Duplicate report does not change notification timestamp");
  Check((await Page(customer,paymentUrl)).Contains("รอร้านตรวจสอบ"),"Customer sees pending verification");
  Check((await Page(admin,"/Admin")).Contains("ออเดอร์แจ้งชำระเงิน"),"Dashboard alerts owner to payment report");
  Check((await customer.PostAsync("/Admin/Payments/Confirm/4",new FormUrlEncodedContent(reportFields))).StatusCode==HttpStatusCode.Redirect,"Customer cannot confirm money received");
  await Post(admin,"/Admin/Payments/Reject/4",new(){["revision"]=nextRevision},adminToken);
  var retryRevision=await Sql("SELECT Revision FROM OrderPayments WHERE CommissionOrderId=4");
  Check(retryRevision!=nextRevision && await Sql("SELECT ReportedAt IS NULL FROM OrderPayments WHERE CommissionOrderId=4")=="1","Owner can reject report and allow retry");
  await Post(customer,"/Payment/Report",new(){["orderCode"]="COM-0004",["revision"]=retryRevision},reportToken);
  await Post(admin,"/Admin/Payments/Confirm/4",new(){["revision"]=retryRevision},adminToken);
  Check(await Sql("SELECT ConfirmedAt IS NOT NULL FROM OrderPayments WHERE CommissionOrderId=4")=="1","Owner can confirm verified transfer");
  Check(await Sql("SELECT Status FROM CommissionOrder WHERE Id=4")=="1","Confirmed awaiting-payment order moves to queue");
  Check((await Page(customer,paymentUrl)).Contains("ยืนยันรับเงินแล้ว") && !(await Page(customer,paymentUrl)).Contains("action=\"/Payment/Report\""),"Confirmed payment no longer asks customer to pay");
  edit["PaymentRevision"]=retryRevision;edit["FinalPrice"]="1700";
  Check(await Invalid(await Post(admin,"/Admin/Edit/4",edit,adminToken)),"Stale admin edit cannot overwrite confirmed payment");
  edit["PaymentRevision"]=await Sql("SELECT Revision FROM OrderPayments WHERE CommissionOrderId=4");
  Check((await Post(admin,"/Admin/Edit/4",edit,adminToken)).StatusCode==HttpStatusCode.Redirect,"Owner can update current price after verification");
  Check(await Sql("SELECT ConfirmedAt IS NULL AND ReportedAt IS NULL FROM OrderPayments WHERE CommissionOrderId=4")=="1","New charge revision clears old report and confirmation");
  edit["PaymentRevision"]=await Sql("SELECT Revision FROM OrderPayments WHERE CommissionOrderId=4");edit["Status"]="6";
  await Post(admin,"/Admin/Edit/4",edit,adminToken);
  Check((await Page(customer,paymentUrl)).Contains("ออเดอร์นี้ยกเลิกแล้ว"),"Cancelled order cannot collect payment");
  await Post(customer,"/Payment/Report",new(){["orderCode"]="COM-0004",["revision"]=edit["PaymentRevision"]},reportToken);
  Check(await Sql("SELECT ReportedAt IS NULL FROM OrderPayments WHERE CommissionOrderId=4")=="1","Cancelled order report rejected");
  Check((await customer.PostAsync("/Admin/Shop/Tips",new FormUrlEncodedContent(new Dictionary<string,string>()))).StatusCode==HttpStatusCode.Redirect,"Tip settings are owner-only");
  Check(await Invalid(await Post(admin,"/Admin/Shop/Tips",new(){["IsEnabled"]="true"},adminToken)),"Cannot enable tip jar without QR");
  Check(await Invalid(await Post(admin,"/Admin/Shop/Tips",new(){["IsEnabled"]="true"},adminToken,Encoding.UTF8.GetBytes("bad"),"QrImage")),"Invalid tip QR rejected");
  Check((await Post(admin,"/Admin/Shop/Tips",new(){["IsEnabled"]="true",["RecipientName"]="Test Tip Recipient"},adminToken,png,"QrImage")).StatusCode==HttpStatusCode.Redirect,"Owner configures tip QR independently");
  var home=await Page(customer,"/");
  Check(home.Contains("data-open-tip") && home.Contains("Test Tip Recipient") && home.Contains("tip-dialog"),"Home has clickable tip jar and recipient");
  var tipQr=await customer.GetAsync("/Home/TipQr");
  Check(tipQr.IsSuccessStatusCode && (await tipQr.Content.ReadAsByteArrayAsync()).SequenceEqual(png),"Public tip QR served from owner configuration");
  await Post(admin,"/Admin/Shop/Tips",new(){["IsEnabled"]="false"},adminToken);
  Check(!(await Page(customer,"/")).Contains("data-open-tip") && (await customer.GetAsync("/Home/TipQr")).StatusCode==HttpStatusCode.NotFound,"Disabling tips hides jar and QR endpoint");
  await Post(admin,"/Admin/Shop/Tips",new(){["IsEnabled"]="true",["RecipientName"]="Test Tip Recipient"},adminToken);
  Check(await Sql("SELECT length(QrImage)>0 FROM TipSettings")=="1","Re-enabling tips retains previous QR");
  edit["Status"]="4";edit["PaymentRevision"]=await Sql("SELECT Revision FROM OrderPayments WHERE CommissionOrderId=4");
  await Post(admin,"/Admin/Edit/4",edit,adminToken);
  Console.WriteLine($"SUCCESS: {checks} payment and tip checks passed.");
 }
}



