﻿using System.ComponentModel.DataAnnotations;
namespace CommissionQueue.Models;

public class ShopProfile {
    public int Id { get; set; } = 1;
    [MaxLength(30)] public string ShopCode { get; set; } = "";
    [MaxLength(100)] public string OwnerName { get; set; } = "";
    [MaxLength(80)] public string ShopName { get; set; } = "";
    [MaxLength(50)] public string AdminUsername { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    [MaxLength(254)] public string Email { get; set; } = "";
    [MaxLength(30)] public string Phone { get; set; } = "";
    [MaxLength(200)] public string? LineContact { get; set; }
    [MaxLength(500)] public string? FacebookContact { get; set; }
    [MaxLength(200)] public string? InstagramContact { get; set; }
    [MaxLength(500)] public string? Description { get; set; }
    public string? LogoPath { get; set; }
    public string? ProfileImagePath { get; set; }
    public bool IsOpen { get; set; } = true;
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
}

