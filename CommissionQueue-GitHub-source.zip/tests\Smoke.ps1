﻿param([string]$BaseUrl = "http://localhost:5081")
$ErrorActionPreference = "Stop"
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$script:checks = 0
function Assert($ok, $name) {
 if (!$ok) { throw "FAIL: $name" }
 $script:checks++
 Write-Output "PASS: $name"
}
function GetPage($path) {
 $r = Invoke-WebRequest "$BaseUrl$path" -WebSession $session -UseBasicParsing
 return [System.Net.WebUtility]::HtmlDecode($r.Content)
}
function PostForm($path, $body, $formPath = $path) {
 $html = GetPage $formPath
 $token = [regex]::Match($html, 'name="__RequestVerificationToken" type="hidden" value="([^"]+)"').Groups[1].Value
 if (!$token) { throw "No antiforgery token on $formPath" }
 $body["__RequestVerificationToken"] = $token
 $r = Invoke-WebRequest "$BaseUrl$path" -WebSession $session -UseBasicParsing -Method Post -Body $body
 return [System.Net.WebUtility]::HtmlDecode($r.Content)
}
$firstPage = GetPage "/"
if($firstPage.Contains('id="setup-form"')) {
 $configured = PostForm "/Setup" @{ShopCode="ORDER-TEST";OwnerName="Test Owner";ShopName="Mellow Studio";AdminUsername="admin";Password="Mellow@12345";ConfirmPassword="Mellow@12345";Email="owner@example.test";Phone="0812345678";IsOpen="true"}
 Assert ($configured.Contains("ตั้งค่าร้านเรียบร้อยแล้ว")) "Configure fresh shop"
 $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
}
$homePage = GetPage "/"
Assert ($homePage.Contains("Mellow Studio")) "Home renders shop"
$queue = GetPage "/Home/Queue"
Assert (([regex]::Matches($queue,'<strong>COM-')).Count -eq 3) "Three seeded orders"
Assert (!$queue.Contains("demo@example.com") -and !$queue.Contains("คุณเมฆ")) "Public queue excludes customer data"
$guard = GetPage "/Admin"
Assert ($guard.Contains('action="/Admin/Login"')) "Admin requires login"
$create = PostForm "/Commission/Create" @{CustomerName=" ";Contact="";WorkType="";Description="";Budget="-1";DueDate="2020-01-01"}
Assert ($create.Contains("validation-summary-errors")) "Invalid and empty request rejected"
$due = (Get-Date).AddDays(30).ToString("yyyy-MM-dd")
$fields = @{CustomerName="Smoke Customer";Contact="private@example.test";WorkType="รูปตัวละคร";Description="<script>alert(1)</script>";Budget="1700";DueDate=$due;ReferenceUrl="javascript:alert(1)"}
$invalidUrl = PostForm "/Commission/Create" $fields.Clone()
Assert ($invalidUrl.Contains("validation-summary-errors")) "Unsafe reference URL rejected"
$fields.ReferenceUrl="https://example.com/reference"
$created = PostForm "/Commission/Create" $fields.Clone()
$code = [regex]::Match($created, 'id="order-code">(COM-\d+)</strong>').Groups[1].Value
Assert ($code -eq "COM-0004") "Request saved with sequential order code"
$tracked = PostForm "/Commission/Track" @{orderCode=$code}
Assert ($tracked.Contains("Smoke Customer") -and $tracked.Contains("รออนุมัติ")) "Customer can track pending order"
Assert (!$tracked.Contains("private@example.test")) "Tracking hides contact details"
$missing = PostForm "/Commission/Track" @{orderCode="COM-999999"}
Assert ($missing.Contains("ไม่พบเลข Order")) "Unknown order gives readable error"
$badLogin = PostForm "/Admin/Login" @{Username="admin";Password="wrong"}
Assert ($badLogin.Contains("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง")) "Wrong password rejected"
$dash = PostForm "/Admin/Login" @{Username="admin";Password="Mellow@12345"}
Assert ($dash.Contains("รายการ Order ทั้งหมด") -and $dash.Contains($code)) "Admin login and dashboard"
$details = GetPage "/Admin/Details/4"
# Raw response must encode user content, not emit a script element.
$raw = (Invoke-WebRequest "$BaseUrl/Admin/Details/4" -WebSession $session -UseBasicParsing).Content
Assert ($raw.Contains("&lt;script&gt;alert(1)&lt;/script&gt;") -and !$raw.Contains("<script>alert(1)</script>")) "Stored customer text HTML-escaped"
$edit = $fields.Clone()
$edit.Id="4"; $edit.Status="5"; $edit.FinalPrice="1500.50"; $edit.EstimatedFinishDate=$due; $edit.AdminNote="Finished with love"
$saved = PostForm "/Admin/Edit/4" $edit
Assert ($saved.Contains("เสร็จแล้ว") -and $saved.Contains("1,500.50")) "Admin updates status, price and notes"
$dash = GetPage "/Admin"
Assert ($dash.Contains("฿1,500.50")) "Revenue counts completed final prices"
$queue = GetPage "/Home/Queue"
Assert (!$queue.Contains($code)) "Completed order leaves active queue"
$tracked = PostForm "/Commission/Track" @{orderCode=$code}
Assert ($tracked.Contains("Finished with love") -and $tracked.Contains($due.Substring(0,4))) "Tracking reflects admin update"
$closed = PostForm "/Admin/Shop" @{OwnerName="Test Owner";ShopName="Mellow Studio";Email="owner@example.test";Phone="0812345678";IsOpen="false"} "/Admin/Shop"
$blocked = PostForm "/Commission/Create" $fields.Clone()
Assert ($blocked.Contains("ขณะนี้ร้านปิดรับคิว")) "Closed shop rejects requests server-side"
$opened = PostForm "/Admin/Shop" @{OwnerName="Test Owner";ShopName="Mellow Studio";Email="owner@example.test";Phone="0812345678";IsOpen="true"} "/Admin/Shop"
try {
 Invoke-WebRequest "$BaseUrl/Admin/Delete/4" -WebSession $session -UseBasicParsing -Method Post | Out-Null
 throw "Missing CSRF was accepted"
} catch {
 Assert ($_.Exception.Response.StatusCode.value__ -eq 400) "CSRF required for deletion"
}
$deleted = PostForm "/Admin/Delete/4" @{} "/Admin/Details/4"
Assert (!$deleted.Contains($code)) "Admin deletes order"
$logout = PostForm "/Admin/Logout" @{} "/Admin"
$guard = GetPage "/Admin"
Assert ($guard.Contains('action="/Admin/Login"')) "Logout revokes admin access"
try { GetPage "/not-a-real-page" | Out-Null; throw "404 expected" }
catch { Assert ($_.Exception.Response.StatusCode.value__ -eq 404) "Missing page returns HTTP 404" }
Write-Output "SUCCESS: $script:checks HTTP checks passed."




