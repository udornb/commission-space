﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
namespace CommissionQueue.Controllers;

[ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
public class PaymentController(AppDbContext db):Controller {
    private static string? Normalize(string? code)=>code is not null && code.Length<=30 ? code.Trim().ToUpperInvariant() : null;

    [HttpGet] public async Task<IActionResult> Index(string? orderCode) {
        var code=Normalize(orderCode);
        var order=await db.CommissionOrders.AsNoTracking().Include(o=>o.Payment).SingleOrDefaultAsync(o=>o.OrderCode==code);
        if(order is null) return NotFound();
        return View(new PaymentPageModel(order.OrderCode,order.FinalPrice,order.Status,order.Payment));
    }
    [HttpGet] public async Task<IActionResult> Qr(string? orderCode,string? revision) {
        var code=Normalize(orderCode);
        var payment=await db.OrderPayments.AsNoTracking().SingleOrDefaultAsync(p=>p.CommissionOrder.OrderCode==code && p.Revision==revision
            && p.CommissionOrder.FinalPrice>0 && p.CommissionOrder.Status!=OrderStatus.Cancelled && p.ReportedAt==null && p.ConfirmedAt==null);
        return payment is null ? NotFound() : File(payment.QrImage,payment.ContentType);
    }
    [HttpPost, EnableRateLimiting("forms")] public async Task<IActionResult> Report(string? orderCode,string? revision) {
        var code=Normalize(orderCode);
        var updated=await db.OrderPayments.Where(p=>p.CommissionOrder.OrderCode==code && p.Revision==revision
            && p.CommissionOrder.FinalPrice>0 && p.CommissionOrder.Status!=OrderStatus.Cancelled && p.ReportedAt==null && p.ConfirmedAt==null)
            .ExecuteUpdateAsync(set=>set.SetProperty(p=>p.ReportedAt,DateTime.UtcNow));
        if(updated==0) {
            TempData["PaymentMessage"]="ข้อมูลอาจเปลี่ยนแปลง หรือแจ้งชำระเงินไปแล้ว กรุณาตรวจสอบสถานะล่าสุด";
            return RedirectToAction(nameof(Index),new {orderCode=code});
        }
        TempData["Message"]="รับแจ้งชำระเงินแล้ว เจ้าของร้านจะตรวจสอบยอดโอนและยืนยันอีกครั้ง ขอบคุณค่ะ ♡";
        return RedirectToAction("Index","Home");
    }
}

