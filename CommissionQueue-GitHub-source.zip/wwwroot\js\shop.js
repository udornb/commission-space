﻿(() => {
    document.querySelectorAll('[data-image-preview]').forEach(input => {
        const preview=document.getElementById(input.dataset.imagePreview);
        const placeholder=document.querySelector('[data-placeholder="'+preview.id+'"]');
        const original=preview.getAttribute('src');
        let objectUrl=null;
        input.addEventListener('change', () => {
            if(objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl=null; }
            const file=input.files[0];
            const message=input.closest('.upload-field').querySelector('.upload-message');
            message.textContent='';
            input.setCustomValidity('');
            if(file && (file.size > 2*1024*1024 || !/\.(png|jpe?g)$/i.test(file.name) || !['image/png','image/jpeg'].includes(file.type))) {
                message.textContent='กรุณาเลือกรูป PNG / JPG ขนาดไม่เกิน 2 MB';
                input.value='';
            }
            const validFile=input.files[0];
            if(validFile) { objectUrl=URL.createObjectURL(validFile); preview.src=objectUrl; preview.hidden=false; placeholder.hidden=true; }
            else { preview.src=original || ''; preview.hidden=!original; placeholder.hidden=!!original; }
        });
    });

    const form=document.getElementById('setup-form');
    if(!form) return;
    const steps=[...form.querySelectorAll('[data-wizard-step]')];
    const next=form.querySelector('.wizard-next'), back=form.querySelector('.wizard-back');
    if(window.jQuery?.validator?.unobtrusive) window.jQuery.validator.unobtrusive.parse(form);
    const validator=window.jQuery ? window.jQuery(form).data('validator') : null;
    let current=1;
    function showStep(step,focus=false) {
        current=step;
        steps.forEach((section,i)=>section.hidden=i!==step-1);
        document.querySelector('#step-label').textContent='ขั้นตอน '+step+' จาก 2';
        document.querySelectorAll('[data-step-indicator]').forEach(item=>{
            item.classList.toggle('current',Number(item.dataset.stepIndicator)===step);
            if(Number(item.dataset.stepIndicator)===step) item.setAttribute('aria-current','step');
            else item.removeAttribute('aria-current');
        });
        if(focus) steps[step-1].querySelector('h2').focus();
    }
    next.hidden=false; back.hidden=false;
    const serverInvalid=form.querySelector('.input-validation-error');
    showStep(serverInvalid?.closest('[data-wizard-step]')?.dataset.wizardStep==='2' ? 2 : 1);
    function validStep(section) {
        let valid=true;
        section.querySelectorAll('input:not([type=hidden]),textarea,select').forEach(input=>{
            if(validator && !window.jQuery(input).valid()) valid=false;
            if(!input.checkValidity()) valid=false;
        });
        return valid;
    }
    next.addEventListener('click',()=>{if(validStep(steps[0])) showStep(2,true);});
    back.addEventListener('click',()=>showStep(1,true));
    // Validate both steps before saving, including controls hidden by the wizard.
    form.addEventListener('submit',event=>{
        if(current===1) {event.preventDefault(); next.click(); return;}
        if(validator) {
            validator.settings.ignore=':disabled';
            const valid=validator.form();
            validator.settings.ignore=':hidden';
            if(!valid) {
                event.preventDefault();
                const first=validator.errorList[0]?.element;
                showStep(Number(first?.closest('[data-wizard-step]')?.dataset.wizardStep || 2));
                first?.focus();
            }
        }
    },true);
})();

