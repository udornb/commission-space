﻿namespace CommissionQueue.Services;

public class ShopImageStore(IWebHostEnvironment environment, ILogger<ShopImageStore> logger) {
    private readonly string root=Path.Combine(environment.WebRootPath, "uploads", "shops");
    public async Task<string?> SaveAsync(IFormFile? file, CancellationToken token) {
        if(file is null) return null;
        Directory.CreateDirectory(root);
        var name=Guid.NewGuid().ToString("N") + (Path.GetExtension(file.FileName).Equals(".png",StringComparison.OrdinalIgnoreCase) ? ".png" : ".jpg");
        var path=Path.Combine(root,name);
        try {
            await using var stream=new FileStream(path, FileMode.CreateNew);
            await file.CopyToAsync(stream,token);
            return "/uploads/shops/"+name;
        } catch {
            Delete("/uploads/shops/"+name);
            throw;
        }
    }
    public void Delete(string? publicPath) {
        if(publicPath is null || !publicPath.StartsWith("/uploads/shops/",StringComparison.Ordinal)) return;
        var name=publicPath["/uploads/shops/".Length..];
        if(name!=Path.GetFileName(name)) return;
        try {File.Delete(Path.Combine(root,name));}
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException) {logger.LogWarning(ex,"Unable to clean up shop image");}
    }
}

