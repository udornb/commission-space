﻿using CommissionQueue.Data;
using CommissionQueue.Models;
using CommissionQueue.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace CommissionQueue.Controllers;

[AllowAnonymous, ResponseCache(NoStore=true,Location=ResponseCacheLocation.None)]
public class SetupController(AppDbContext db, ShopImageStore images, ILogger<SetupController> logger) : Controller {
    private static readonly SemaphoreSlim SetupLock=new(1,1);
    private IActionResult AlreadyConfigured() => User.Identity?.IsAuthenticated==true
        ? RedirectToAction("Index","Admin") : RedirectToAction("Login","Admin");

    [HttpGet] public async Task<IActionResult> Index() =>
        await db.ShopProfiles.AnyAsync() ? AlreadyConfigured() : View(new SetupForm());

    [HttpPost, EnableRateLimiting("forms"), RequestSizeLimit(6*1024*1024), RequestFormLimits(MultipartBodyLengthLimit=6*1024*1024)]
    public async Task<IActionResult> Index(SetupForm form) {
        // Serialize first-run submissions; the DB also enforces a single row (Id=1) and a unique code.
        await SetupLock.WaitAsync(HttpContext.RequestAborted);
        string? logo=null, profile=null;
        try {
            if(await db.ShopProfiles.AnyAsync()) return AlreadyConfigured();
            if(!ModelState.IsValid) return View(form);
            form.ShopCode=form.ShopCode.Trim().ToUpperInvariant();
            if(await db.ShopProfiles.AnyAsync(s=>s.ShopCode==form.ShopCode))
                ModelState.AddModelError(nameof(form.ShopCode),"รหัสร้านนี้มีอยู่แล้ว");
            if(!ModelState.IsValid) return View(form);
            var shop=new ShopProfile { ShopCode=form.ShopCode, AdminUsername=form.AdminUsername.Trim() };
            form.ApplyTo(shop);
            shop.PasswordHash=new PasswordHasher<ShopProfile>().HashPassword(shop,form.Password);
            logo=await images.SaveAsync(form.Logo,HttpContext.RequestAborted);
            profile=await images.SaveAsync(form.ProfileImage,HttpContext.RequestAborted);
            shop.LogoPath=logo; shop.ProfileImagePath=profile;
            await using(var transaction=await db.Database.BeginTransactionAsync()) {
                db.ShopProfiles.Add(shop);
                if(!await db.CommissionOrders.AnyAsync()) DbInitializer.AddSamples(db);
                await db.SaveChangesAsync();
                await transaction.CommitAsync();
            }
            // Images belong to the committed profile; a subsequent cookie failure must not remove them.
            logo=null; profile=null;
            await AdminSession.SignInAsync(HttpContext,shop);
            TempData["SetupComplete"]=true;
            return RedirectToAction(nameof(Success));
        } catch(DbUpdateException ex) {
            logger.LogWarning(ex,"Concurrent or invalid shop setup");
            db.ChangeTracker.Clear();
            if(await db.ShopProfiles.AnyAsync()) return AlreadyConfigured();
            ModelState.AddModelError("","ไม่สามารถบันทึกร้านได้ กรุณาตรวจสอบรหัสร้านแล้วลองใหม่");
            return View(form);
        } catch(Exception ex) when(ex is IOException or UnauthorizedAccessException) {
            logger.LogError(ex,"Unable to save shop images");
            ModelState.AddModelError("","บันทึกรูปไม่สำเร็จ กรุณาเลือกไฟล์อีกครั้งแล้วลองใหม่");
            return View(form);
        } finally {
            images.Delete(logo); images.Delete(profile);
            SetupLock.Release();
        }
    }

    [HttpGet] public async Task<IActionResult> Success() {
        if(!await db.ShopProfiles.AnyAsync()) return RedirectToAction(nameof(Index));
        if(User.Identity?.IsAuthenticated!=true || TempData["SetupComplete"] is null) return AlreadyConfigured();
        return View();
    }
}

