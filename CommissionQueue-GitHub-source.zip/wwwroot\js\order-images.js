﻿document.querySelectorAll('[data-order-images]').forEach(input => {
    const field=input.closest('.order-image-field');
    const preview=field.querySelector('.image-selection-preview');
    const message=field.querySelector('.image-selection-message');
    let selected=[], urls=[];
    const existingCount=()=>field.querySelectorAll('.order-existing .attachment-card').length
        - field.querySelectorAll('input[name="RemoveImageIds"]:checked').length;
    function render() {
        urls.forEach(url=>URL.revokeObjectURL(url)); urls=[];
        preview.replaceChildren();
        const transfer=new DataTransfer();
        selected.forEach((file,index)=>{
            transfer.items.add(file);
            const card=document.createElement('div');card.className='attachment-card';
            const img=document.createElement('img'); const url=URL.createObjectURL(file);urls.push(url);img.src=url;img.alt=file.name;
            const caption=document.createElement('span');caption.className='attachment-name';caption.textContent=file.name;
            const remove=document.createElement('button');remove.type='button';remove.className='text-link';remove.textContent='นำรูปออก';
            remove.addEventListener('click',()=>{selected.splice(index,1);message.textContent='';render();});
            card.append(img,caption,remove);preview.append(card);
        });
        input.files=transfer.files;
        const tooMany=existingCount()+selected.length>5;
        input.setCustomValidity(tooMany?'รวมรูปเดิมและรูปใหม่ได้ไม่เกิน 5 รูป':'');
        if(tooMany) message.textContent='รวมรูปเดิมและรูปใหม่ได้ไม่เกิน 5 รูป กรุณานำรูปออกบางรูป';
    }
    input.addEventListener('change',()=>{
        const added=[...input.files]; message.textContent='';
        if(added.some(f=>f.size===0 || f.size>2*1024*1024 || !/\.(png|jpe?g)$/i.test(f.name) || !['image/png','image/jpeg'].includes(f.type))) {
            message.textContent='กรุณาเลือกรูป PNG / JPG ที่มีข้อมูลและขนาดไม่เกิน 2 MB ต่อรูป';
        } else if(existingCount()+selected.length+added.length>5) {
            message.textContent='แนบรูปได้รวมไม่เกิน 5 รูป กรุณานำรูปออกบางรูปก่อน';
        } else selected.push(...added);
        render();
    });
    field.querySelectorAll('input[name="RemoveImageIds"]').forEach(box=>box.addEventListener('change',()=>{message.textContent='';render();}));
});

